import * as THREE from 'three';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import { 
  CharacterDef, 
  CharacterCustomization, 
  GameStatus, 
  RunStats, 
  ActivePowerUp, 
  PowerUpType, 
  TrickEvent,
  WeatherInfo,
  WeatherType,
  MapTheme
} from '../types/game';
import { CharacterRig, createCharacterMesh } from './characterMesh';
import { MountainTrack } from './mountain';
import { ParticleSystem } from './particles';
import { WeatherSystem } from './weather';
import { SkiTracksSystem } from './skiTracks';
import { sound } from './audio';
import { updateDailyChallengeProgress } from './dailyChallenges';

// Pre-allocated math objects to avoid garbage collection
const _vec3A = new THREE.Vector3();
const _vec3B = new THREE.Vector3();

export interface GameEngineCallbacks {
  onStatsUpdate: (stats: RunStats) => void;
  onPowerUpsUpdate: (powerUps: ActivePowerUp[]) => void;
  onTrick: (trick: TrickEvent) => void;
  onWeatherUpdate: (weather: WeatherInfo) => void;
  onGameOver: (finalStats: RunStats) => void;
  onNearMiss: () => void;
  onGatePassed: () => void;
  onShieldLost: () => void;
}

export class GameEngine {
  public scene: THREE.Scene;
  public camera: THREE.PerspectiveCamera;
  public renderer: THREE.WebGLRenderer;
  public isSoftwareGl: boolean;

  private container: HTMLElement;
  private animFrameId: number = 0;
  private isDestroyed: boolean = false;
  private callbacks: GameEngineCallbacks;

  // Subsystems
  public track: MountainTrack;
  public particles: ParticleSystem;
  public weather: WeatherSystem;
  public skiTracks: SkiTracksSystem;
  public playerRig: CharacterRig | null = null;

  // Game Status
  public status: GameStatus = 'title';
  private characterDef: CharacterDef;
  private customization: CharacterCustomization;

  // Physics & Kinematics
  private playerPos = new THREE.Vector3(0, 0, 0);
  private forwardSpeed = 0; // m/s
  private lateralSpeed = 0; // m/s
  private verticalSpeed = 0; // m/s
  private carveAngle = 0; // -1 to +1
  private isAirborne = false;
  private airtimeTimer = 0;
  private coyoteTimer = 0;
  private jumpBuffered = false;

  // Tricks & Rotations in Air
  private airRotation = { pitch: 0, yaw: 0, roll: 0 };
  private totalRotations = { pitch: 0, yaw: 0, roll: 0 };
  private currentTrickName: string | null = null;

  // PowerUps & Abilities
  private activePowerUps: Map<PowerUpType, { duration: number; maxDuration: number }> = new Map();
  private armorCharges = 0;
  private boostEnergy = 100; // 0 to 100
  private isBoosting = false;

  // Hitstop & Camera Shake
  private hitstopTimer = 0;
  private cameraShake = 0;

  // Stats
  private stats: RunStats = {
    distance: 0,
    speed: 0,
    topSpeed: 0,
    score: 0,
    multiplier: 1,
    coinsCollected: 0,
    gemsCollected: 0,
    gatesPassed: 0,
    tricksLanded: 0,
    airtimeTotal: 0,
    nearMisses: 0,
  };

  // Input states
  private keysHeld: Record<string, boolean> = {};
  public mapTheme: MapTheme = 'snow';
  public invertSteering: boolean = false;
  private had10Points = false;

  public setInvertSteering(invert: boolean) {
    this.invertSteering = invert;
  }

  constructor(
    container: HTMLElement,
    characterDef: CharacterDef,
    customization: CharacterCustomization,
    callbacks: GameEngineCallbacks,
    initialTheme: MapTheme = 'snow'
  ) {
    this.container = container;
    this.characterDef = characterDef;
    this.customization = customization;
    this.callbacks = callbacks;
    this.mapTheme = initialTheme;

    // Detect software WebGL
    this.isSoftwareGl = (() => {
      const gl = document.createElement('canvas').getContext('webgl2');
      if (!gl) return true;
      const ext = gl.getExtension('WEBGL_debug_renderer_info');
      const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
      const gpu = String(gl.getParameter(param));
      gl.getExtension('WEBGL_lose_context')?.loseContext();
      return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
    })();

    // 1. Scene & Atmosphere
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0xa5d8ff); // Crisp alpine morning sky
    this.scene.fog = new THREE.FogExp2(0xa5d8ff, 0.006);

    // 2. Camera
    const aspect = container.clientWidth / container.clientHeight;
    this.camera = new THREE.PerspectiveCamera(60, aspect, 0.1, 800);
    this.camera.position.set(0, 2.5, -5.8);

    // 3. Renderer
    this.renderer = new THREE.WebGLRenderer({
      antialias: !this.isSoftwareGl,
      powerPreference: 'high-performance',
      precision: 'mediump',
    });
    this.renderer.setSize(container.clientWidth, container.clientHeight);
    // Cap DPR at 1.25 on high-DPI screens to prevent massive fill-rate lag while preserving crispness
    this.renderer.setPixelRatio(this.isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 1.25));
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.15;
    this.renderer.shadowMap.enabled = !this.isSoftwareGl;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    container.appendChild(this.renderer.domElement);

    // 4. Studio Environment Reflections
    const pmremGenerator = new THREE.PMREMGenerator(this.renderer);
    this.scene.environment = pmremGenerator.fromScene(new RoomEnvironment(), 0.04).texture;
    pmremGenerator.dispose();

    // 5. Lighting Rig (Key, Fill, Rim) - Optimized shadow bounds & 512x512 map for zero lag
    const sunLight = new THREE.DirectionalLight(0xffedd5, 1.8);
    sunLight.position.set(25, 45, 20);
    sunLight.castShadow = !this.isSoftwareGl;
    sunLight.shadow.mapSize.width = 512;
    sunLight.shadow.mapSize.height = 512;
    sunLight.shadow.camera.near = 1;
    sunLight.shadow.camera.far = 90;
    sunLight.shadow.camera.left = -20;
    sunLight.shadow.camera.right = 20;
    sunLight.shadow.camera.top = 20;
    sunLight.shadow.camera.bottom = -20;
    sunLight.shadow.bias = -0.0005;
    sunLight.shadow.normalBias = 0.02;
    this.scene.add(sunLight);

    const hemiLight = new THREE.HemisphereLight(0xdbeafe, 0x1e293b, 1.1);
    this.scene.add(hemiLight);

    // 6. Subsystems initialized with theme
    this.track = new MountainTrack(this.mapTheme);
    this.scene.add(this.track.root);

    this.particles = new ParticleSystem();
    this.particles.setTheme(this.mapTheme);
    this.scene.add(this.particles.root);

    this.skiTracks = new SkiTracksSystem();
    this.skiTracks.setTheme(this.mapTheme);
    this.scene.add(this.skiTracks.root);

    this.weather = new WeatherSystem(this.scene, sunLight, hemiLight, this.scene.fog as THREE.FogExp2);
    this.weather.setTheme(this.mapTheme);

    // 7. Load Player Character Mesh dressed for map
    this.loadCharacter(characterDef, customization, this.mapTheme);

    // 8. Bind Events
    this.bindInputs();
    window.addEventListener('resize', this.handleResize);

    // Start simulation loop
    this.lastTime = performance.now();
    this.startLoop();
  }

  public setMapTheme(theme: MapTheme) {
    this.mapTheme = theme;
    this.track.setMapTheme(theme);
    this.particles.setTheme(theme);
    this.skiTracks.setTheme(theme);
    this.weather.setTheme(theme);
    if (this.playerRig) {
      this.playerRig.setMapTheme(theme);
    }
  }

  public loadCharacter(def: CharacterDef, custom: CharacterCustomization, theme?: MapTheme) {
    if (this.playerRig) {
      this.scene.remove(this.playerRig.root);
      this.playerRig.dispose();
    }
    this.characterDef = def;
    this.customization = custom;
    const activeTheme = theme || this.mapTheme;
    this.playerRig = createCharacterMesh(def, custom, activeTheme);
    this.scene.add(this.playerRig.root);

    // Special ability traits
    if (def.id === 'glacier_guardian') {
      this.armorCharges = 1;
    } else {
      this.armorCharges = 0;
    }
  }

  public updateCustomization(custom: CharacterCustomization) {
    this.customization = custom;
    if (this.playerRig) {
      this.playerRig.updateCustomization(custom);
    }
  }

  private bindInputs() {
    window.addEventListener('keydown', (e) => {
      this.keysHeld[e.code] = true;
      if (e.key) this.keysHeld[e.key.toLowerCase()] = true;
      if (e.code === 'Space' || e.key === ' ') {
        this.jumpBuffered = true;
      }
    });

    window.addEventListener('keyup', (e) => {
      this.keysHeld[e.code] = false;
      if (e.key) this.keysHeld[e.key.toLowerCase()] = false;
    });

    window.addEventListener('blur', () => {
      this.keysHeld = {};
    });
  }

  // Virtual Controls for Mobile / Touch
  public setVirtualSteer(val: number) {
    // -1 = full left, +1 = full right, 0 = neutral
    this.virtualSteer = val;
  }
  public triggerVirtualJump() {
    this.jumpBuffered = true;
  }
  public setVirtualBoost(active: boolean) {
    this.virtualBoost = active;
  }
  private virtualSteer = 0;
  private virtualBoost = false;

  private handleResize = () => {
    if (!this.container || !this.renderer || !this.camera) return;
    const w = this.container.clientWidth;
    const h = this.container.clientHeight;
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(w, h);
  };

  public startGame() {
    this.status = 'playing';
    this.resetState();
    sound.startAtmosphericMusic();
  }

  public pauseGame() {
    if (this.status === 'playing') {
      this.status = 'paused';
    }
  }

  public resumeGame() {
    if (this.status === 'paused') {
      this.status = 'playing';
      this.lastTime = performance.now();
    }
  }

  public setStatus(newStatus: GameStatus) {
    this.status = newStatus;
    if (newStatus === 'customize' || newStatus === 'title') {
      this.resetState();
    }
  }

  private resetState() {
    const startY = this.track.getTerrainHeight(0, 0) + 0.05;
    this.playerPos.set(0, startY, 0);
    if (this.playerRig) {
      this.playerRig.root.rotation.set(0, 0, 0);
      this.playerRig.root.position.copy(this.playerPos);
    }
    this.camera.position.set(0, startY + 2.5, -5.8);
    this.camera.lookAt(0, startY + 0.3, 10.0);
    this.forwardSpeed = 8;
    this.lateralSpeed = 0;
    this.verticalSpeed = 0;
    this.carveAngle = 0;
    this.isAirborne = false;
    this.airtimeTimer = 0;
    this.airRotation = { pitch: 0, yaw: 0, roll: 0 };
    this.totalRotations = { pitch: 0, yaw: 0, roll: 0 };
    this.currentTrickName = null;
    this.activePowerUps.clear();
    this.boostEnergy = 100;
    this.isBoosting = false;
    this.cameraShake = 0;
    this.hitstopTimer = 0;

    if (this.characterDef.id === 'glacier_guardian') {
      this.armorCharges = 1;
    } else {
      this.armorCharges = 0;
    }

    this.had10Points = false;

    this.stats = {
      distance: 0,
      speed: 0,
      topSpeed: 0,
      score: 0,
      multiplier: 1,
      coinsCollected: 0,
      gemsCollected: 0,
      gatesPassed: 0,
      tricksLanded: 0,
      airtimeTotal: 0,
      nearMisses: 0,
      isDoubleCoinsActive: false,
    };

    this.track.reset();
    this.skiTracks.reset();
  }

  private lastTime = 0;

  private startLoop() {
    const tick = () => {
      if (this.isDestroyed) return;

      const now = performance.now();
      const rawDt = (now - this.lastTime) / 1000;
      this.lastTime = now;
      const dt = Math.min(rawDt, 0.05); // clamp frame delta time

      if (this.status === 'playing') {
        this.updateSimulation(dt);
      } else if (this.status === 'title' || this.status === 'customize') {
        this.updatePreviewMode(dt);
      }

      this.renderer.render(this.scene, this.camera);

      if (this.isSoftwareGl) {
        this.afterDraw(tick);
      } else {
        this.animFrameId = requestAnimationFrame(tick);
      }
    };

    this.animFrameId = requestAnimationFrame(tick);
  }

  private afterDraw(cb: () => void) {
    const gl = this.renderer.getContext() as WebGL2RenderingContext;
    const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
    gl.flush();
    const poll = () => {
      const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
      if (state === gl.UNSIGNALED) {
        this.animFrameId = window.setTimeout(poll, 5);
      } else {
        gl.deleteSync(sync);
        this.animFrameId = window.setTimeout(cb, 60);
      }
    };
    this.animFrameId = window.setTimeout(poll, 5);
  }

  // --- Title & Customizer Turntable Preview ---
  private previewTime = 0;
  private updatePreviewMode(dt: number) {
    this.previewTime += dt;
    if (this.playerRig) {
      if (this.status === 'customize') {
        // Slow rotating turntable view centered on racer
        this.playerRig.root.position.set(0, 0, 0);
        this.playerRig.root.rotation.y = this.previewTime * 0.7;

        this.camera.position.set(
          Math.sin(this.previewTime * 0.25) * 3.5,
          1.4,
          Math.cos(this.previewTime * 0.25) * 3.5
        );
        this.camera.lookAt(0, 0.7, 0);
      } else {
        // Title Screen: Epic cinematic live camera pan on peak
        this.playerRig.root.position.set(0, 0, 0);
        this.playerRig.root.rotation.y = 0.2;

        const camRadius = 5.5;
        this.camera.position.set(
          Math.sin(this.previewTime * 0.35) * camRadius,
          2.6 + Math.sin(this.previewTime * 0.5) * 0.6,
          Math.cos(this.previewTime * 0.35) * camRadius
        );
        this.camera.lookAt(0, 0.8, 0);
      }

      this.playerRig.animate(
        this.previewTime,
        15,
        0,
        false,
        { pitch: 0, yaw: 0, roll: 0 },
        false,
        false,
        false
      );
    }

    // Update dynamic weather & mountain vista in preview
    this.weather.update(dt, this.camera.position);
    this.particles.update(
      dt, 
      this.camera.position, 
      0, 
      false, 
      this.weather.currentConfig.windSpeed, 
      this.weather.currentConfig.snowDensity
    );
  }

  // --- 60fps Active Racing Simulation ---
  private updateSimulation(dt: number) {
    // Hitstop freeze for visceral impact feel
    if (this.hitstopTimer > 0) {
      this.hitstopTimer -= dt;
      return;
    }

    const simTime = performance.now() * 0.001;

    // 1. Process Active Power-Ups
    let isFrozen = false;
    let scoreMultiplier = 1;
    let hasShield = false;
    let hasMagnet = false;
    let hasStar = false;

    this.activePowerUps.forEach((pu, type) => {
      pu.duration -= dt;
      if (pu.duration <= 0) {
        this.activePowerUps.delete(type);
      } else {
        if (type === 'freeze') isFrozen = true;
        if (type === 'multiplier') scoreMultiplier = 2.5;
        if (type === 'shield') hasShield = true;
        if (type === 'magnet') hasMagnet = true;
        if (type === 'star') {
          hasStar = true;
          hasMagnet = true;
        }
      }
    });

    // Notify UI of active powerup states
    const activeList: ActivePowerUp[] = Array.from(this.activePowerUps.entries()).map(([t, p]) => ({
      type: t,
      duration: p.duration,
      maxDuration: p.maxDuration,
    }));
    this.callbacks.onPowerUpsUpdate(activeList);

    // 2. Input Handling (A = left, D = right, W = speed boost, Space = jump)
    const steerLeft = this.keysHeld['KeyA'] || this.keysHeld['a'] || this.keysHeld['ArrowLeft'] || this.virtualSteer < -0.2;
    const steerRight = this.keysHeld['KeyD'] || this.keysHeld['d'] || this.keysHeld['ArrowRight'] || this.virtualSteer > 0.2;
    const boostKey = this.keysHeld['ShiftLeft'] || this.keysHeld['KeyW'] || this.keysHeld['w'] || this.keysHeld['ArrowUp'] || this.virtualBoost;
    const jumpKey = this.keysHeld['Space'] || this.keysHeld[' '] || this.jumpBuffered;
    this.jumpBuffered = false;

    // Boost Logic
    this.isBoosting = false;
    if (boostKey && this.boostEnergy > 2) {
      this.isBoosting = true;
      this.boostEnergy = Math.max(0, this.boostEnergy - 22 * dt);
      sound.playBoost();
    } else {
      // Faster boost regen for high-action gameplay
      this.boostEnergy = Math.min(100, this.boostEnergy + (this.characterDef.stats.boost * 3.2) * dt);
    }

    // Top Speed & Forward Acceleration (Holding W gives active speed push even if boost is recharging)
    const baseTopSpeed = 24 + this.characterDef.stats.speed * 2.4; // ~38 to 48 m/s (up to 170 km/h)
    const boostBonus = this.isBoosting ? 20 : (boostKey ? 9 : 0);
    const nitroBonus = this.activePowerUps.has('nitro') ? 22 : 0;
    const slipstreamBonus = this.characterDef.id === 'alpine_blitz' ? 4 : 0;
    const maxForward = baseTopSpeed + boostBonus + nitroBonus + slipstreamBonus;

    const accelRate = (12 + this.characterDef.stats.speed * 1.5) * (boostKey ? 1.6 : 1.0);
    if (this.forwardSpeed < maxForward) {
      this.forwardSpeed += accelRate * dt;
    } else {
      this.forwardSpeed = THREE.MathUtils.damp(this.forwardSpeed, maxForward, 4, dt);
    }

    // 3. Lateral Steering & Carving (A steers Left, D steers Right; supports invert option)
    const handling = 1.0 + (this.characterDef.stats.carving - 5) * 0.12;
    let targetCarve = 0;
    if (this.invertSteering) {
      if (steerLeft) targetCarve = -1.0;
      if (steerRight) targetCarve = 1.0;
      if (this.virtualSteer !== 0) targetCarve = this.virtualSteer;
    } else {
      if (steerLeft) targetCarve = 1.0;
      if (steerRight) targetCarve = -1.0;
      if (this.virtualSteer !== 0) targetCarve = -this.virtualSteer;
    }

    this.carveAngle = THREE.MathUtils.damp(this.carveAngle, targetCarve, 14 * handling, dt);
    this.lateralSpeed = this.carveAngle * (24 * handling);

    // 4. Ground Collision & Jump Mechanics
    const currentGroundY = this.track.getTerrainHeight(this.playerPos.x, this.playerPos.z);

    if (this.isAirborne) {
      this.airtimeTimer += dt;
      this.stats.airtimeTotal += dt;
      this.verticalSpeed -= 26 * dt; // gravity
      this.playerPos.y += this.verticalSpeed * dt;

      // Air tricks rotation
      const rotSpeed = 4.2 * (this.characterDef.id === 'frost_maverick' ? 1.5 : 1.0);
      if (this.keysHeld['KeyA'] || this.keysHeld['ArrowLeft']) {
        this.airRotation.yaw += rotSpeed * dt;
        this.totalRotations.yaw += rotSpeed * dt;
      }
      if (this.keysHeld['KeyD'] || this.keysHeld['ArrowRight']) {
        this.airRotation.yaw -= rotSpeed * dt;
        this.totalRotations.yaw -= rotSpeed * dt;
      }
      if (this.keysHeld['KeyW'] || this.keysHeld['ArrowUp']) {
        this.airRotation.pitch += rotSpeed * dt;
        this.totalRotations.pitch += rotSpeed * dt;
      }
      if (this.keysHeld['KeyS'] || this.keysHeld['ArrowDown']) {
        this.airRotation.pitch -= rotSpeed * dt;
        this.totalRotations.pitch -= rotSpeed * dt;
      }

      // Check trick detection
      const totalTurns = Math.floor(Math.abs(this.totalRotations.yaw) / (Math.PI * 2));
      const totalFlips = Math.floor(Math.abs(this.totalRotations.pitch) / (Math.PI * 2));

      if (totalTurns > 0 || totalFlips > 0) {
        let trickTitle = '';
        if (totalFlips > 0) trickTitle = totalFlips === 1 ? 'Backflip' : 'Double Backflip';
        if (totalTurns > 0) {
          const deg = totalTurns * 360;
          trickTitle = trickTitle ? `${trickTitle} + ${deg}° Rodeo` : `${deg}° Spin`;
        }
        if (trickTitle !== this.currentTrickName) {
          this.currentTrickName = trickTitle;
          const trickPts = (totalTurns * 250 + totalFlips * 400) * (this.characterDef.id === 'frost_maverick' ? 2 : 1);
          sound.playTrick(this.stats.multiplier);
          this.callbacks.onTrick({
            name: trickTitle,
            points: trickPts,
            timestamp: Date.now(),
          });
          this.stats.score += trickPts * scoreMultiplier;
          this.stats.multiplier = Math.min(10, this.stats.multiplier + 0.5);
          // Skill reward: Huge coin bonuses on stunts!
          const bonusCoins = (totalTurns * 15 + totalFlips * 25) * (this.activePowerUps.has('multiplier') ? 2 : 1);
          this.stats.coinsCollected += bonusCoins;
          this.particles.emitSparkles(this.playerPos, 0xfbbf24, 15);
        }
      }

      // Touchdown Check
      if (this.playerPos.y <= currentGroundY) {
        this.playerPos.y = currentGroundY;
        this.isAirborne = false;
        sound.playLand(Math.min(1.5, Math.abs(this.verticalSpeed) / 12));

        // Landing angle check: pitch/yaw within ±45 deg of normal
        const pitchErr = Math.abs(this.airRotation.pitch % (Math.PI * 2));
        const isCleanLanding = pitchErr < 0.6 || pitchErr > (Math.PI * 2 - 0.6);

        if (isCleanLanding && this.airtimeTimer > 0.4) {
          this.stats.tricksLanded++;
          updateDailyChallengeProgress('tricks', 1, true);
          // Perfect landing boost & bonus coins!
          this.boostEnergy = Math.min(100, this.boostEnergy + 30);
          this.stats.coinsCollected += 10;
          this.particles.emitSparkles(this.playerPos, 0x38bdf8, 20);
        } else if (!isCleanLanding && this.airtimeTimer > 0.6) {
          // Hard wipeout on crooked landing!
          this.triggerCrash('Bad landing angle');
          return;
        }

        // Reset air state
        this.airRotation = { pitch: 0, yaw: 0, roll: 0 };
        this.totalRotations = { pitch: 0, yaw: 0, roll: 0 };
        this.currentTrickName = null;
        this.airtimeTimer = 0;
      }
    } else {
      // Grounded
      this.playerPos.y = currentGroundY;
      this.coyoteTimer = 0.15; // 150ms coyote time window

      // Launch off ramp or jump key
      let hitRamp = false;
      for (const ramp of this.track.ramps) {
        const dx = Math.abs(this.playerPos.x - ramp.position.x);
        const dz = this.playerPos.z - ramp.position.z;
        if (dx < ramp.width * 0.5 && dz >= 0 && dz < ramp.length) {
          hitRamp = true;
          this.verticalSpeed = 16 + this.characterDef.stats.airtime * 1.2;
          this.isAirborne = true;
          sound.playJump();
          this.particles.emitSnowSpray(this.playerPos, 1.0, this.forwardSpeed, 10);
          break;
        }
      }

      if (!hitRamp && jumpKey) {
        const jumpPower = 11 + this.characterDef.stats.airtime * 0.8;
        this.verticalSpeed = jumpPower;
        this.isAirborne = true;
        sound.playJump();
        this.particles.emitSnowSpray(this.playerPos, this.carveAngle, this.forwardSpeed, 6);
      }
    }

    // 5. Update Position (with weather wind deflection)
    const lateralWindPush = this.weather.currentConfig.windSpeed * 0.35;
    this.playerPos.x += (this.lateralSpeed + lateralWindPush) * dt;
    this.playerPos.z += this.forwardSpeed * dt;

    // Clamp lateral bounds so racer stays within mountain valley
    this.playerPos.x = THREE.MathUtils.clamp(this.playerPos.x, -21, 21);

    // 6. Update Character Mesh Position & Orientation
    if (this.playerRig) {
      this.playerRig.root.position.copy(this.playerPos);

      // Skis carve snow spray
      if (!this.isAirborne && (Math.abs(this.carveAngle) > 0.15 || this.isBoosting)) {
        this.particles.emitSnowSpray(
          this.playerPos,
          this.carveAngle,
          this.forwardSpeed,
          this.isBoosting ? 5 : 2
        );
      }

      const speedKmh = this.forwardSpeed * 3.6;
      this.playerRig.animate(
        simTime,
        speedKmh,
        this.carveAngle,
        this.isAirborne,
        this.airRotation,
        !this.isAirborne && this.forwardSpeed > 30,
        hasShield || this.armorCharges > 0,
        this.isBoosting || this.activePowerUps.has('nitro')
      );

      // Sound update
      sound.updateMotion(speedKmh, this.isAirborne, this.carveAngle, this.isBoosting);
    }

    // 7. Track & Collectibles Collision Detection
    this.checkCollisions(dt, scoreMultiplier, hasShield, hasMagnet);

    // 8. Update Dynamic Weather, Track Chunks, Ski Tracks & Storm Particles
    this.weather.update(dt, this.playerPos);
    this.track.update(dt, this.playerPos.z, isFrozen);

    // Realistic carved tracks in snow or white water wake in beach mode
    this.skiTracks.addTrackPoint(
      this.playerPos,
      this.carveAngle,
      this.isAirborne,
      this.mapTheme === 'beach' ? 'snowboard' : this.characterDef.vehicleType,
      currentGroundY
    );
    this.skiTracks.update(this.playerPos.z);

    this.particles.update(
      dt,
      this.playerPos,
      this.forwardSpeed * 3.6,
      this.isBoosting || this.activePowerUps.has('nitro'),
      this.weather.currentConfig.windSpeed,
      this.weather.currentConfig.snowDensity
    );

    // Notify UI of weather status
    this.callbacks.onWeatherUpdate({
      type: this.weather.currentConfig.type,
      name: this.weather.currentConfig.name,
      icon: this.weather.currentConfig.icon,
      frostVignette: this.weather.currentConfig.frostVignette,
      windSpeed: this.weather.currentConfig.windSpeed,
    });

    // 9. Update Stats
    this.stats.distance = Math.floor(this.playerPos.z);
    this.stats.speed = Math.floor(this.forwardSpeed * 3.6);
    this.stats.topSpeed = Math.max(this.stats.topSpeed, this.stats.speed);
    this.stats.score += Math.floor(this.forwardSpeed * dt * 2.5 * scoreMultiplier * this.stats.multiplier);

    // Double Coins activation check (user requested: I WILL GET DOUBLE COINS WHEN I HIT 10 POINTS)
    if (this.stats.score >= 10) {
      if (!this.had10Points) {
        this.had10Points = true;
        sound.playDoubleCoins();
        this.particles.emitSparkles(this.playerPos, 0xfacc15, 30);
      }
      this.stats.isDoubleCoinsActive = true;
    } else {
      this.stats.isDoubleCoinsActive = false;
    }

    updateDailyChallengeProgress('distance', this.stats.distance, false);
    updateDailyChallengeProgress('score', this.stats.score, false);

    this.callbacks.onStatsUpdate(this.stats);

    // 10. Normal Static Chase Camera (Rock-solid, upright, centered directly behind the player)
    this.camera.position.x = this.playerPos.x;
    this.camera.position.y = this.playerPos.y + 2.5;
    this.camera.position.z = this.playerPos.z - 5.8;

    this.camera.up.set(0, 1, 0);
    const lookTarget = _vec3A.set(
      this.playerPos.x,
      this.playerPos.y + 0.35,
      this.playerPos.z + 10.0
    );
    this.camera.lookAt(lookTarget);
    this.camera.fov = 60;
    this.camera.updateProjectionMatrix();
  }

  // --- Collision Detection ---
  private checkCollisions(
    dt: number,
    scoreMultiplier: number,
    hasShield: boolean,
    hasMagnet: boolean
  ) {
    const pX = this.playerPos.x;
    const pY = this.playerPos.y;
    const pZ = this.playerPos.z;

    // 1. Collectibles (Shining Star Super Magnet & Coin Farming)
    const hasStar = this.activePowerUps.has('star');
    // When Shining Star is active: EVERY coin within 250m accelerates towards player
    const magnetRadius = hasStar ? 250.0 : (hasMagnet ? 42.0 : 9.0);
    const suctionSpeed = hasStar ? 38.0 : (hasMagnet ? 24.0 : 16.0);
    const scoreDoubleBonus = this.stats.score >= 10 ? 2 : 1;
    const coinMultiplier = (this.activePowerUps.has('multiplier') ? 2 : 1) * 
      (this.characterDef.id === 'frost_maverick' ? 2 : 1) * 
      scoreDoubleBonus;

    if (hasStar && Math.random() < 0.25) {
      this.particles.emitSparkles(this.playerPos, 0xfde047, 4);
    }

    const collectibles = this.track.collectibles;
    const colCount = collectibles.length;
    for (let i = 0; i < colCount; i++) {
      const col = collectibles[i];
      if (col.isCollected) continue;

      const dz = pZ - col.position.z;
      // Fast bounding box reject: if Z distance alone exceeds magnet radius, skip
      if (Math.abs(dz) > magnetRadius) continue;

      const dx = pX - col.position.x;
      const dy = pY - col.position.y;
      const distSq = dx * dx + dy * dy + dz * dz;
      const magnetRadiusSq = magnetRadius * magnetRadius;

      // Vacuum suction pull effect directly into player (every coin comes to you when star active!)
      if (distSq < magnetRadiusSq) {
        col.position.x += (pX - col.position.x) * suctionSpeed * dt;
        col.position.y += (pY - col.position.y) * suctionSpeed * dt;
        col.position.z += (pZ - col.position.z) * suctionSpeed * dt;
      }

      const touchRadius = col.radius + 1.8;
      if (distSq < touchRadius * touchRadius) {
        col.isCollected = true;
        col.mesh.visible = false;

        if (col.type === 'coin') {
          sound.playCoin();
          const earned = 1 * coinMultiplier;
          this.stats.coinsCollected += earned;
          this.stats.score += 50 * scoreMultiplier;
          this.particles.emitSparkles(col.position, hasStar ? 0xfef08a : 0xfbbf24, 12);
          updateDailyChallengeProgress('coins', earned, true);
        } else if (col.type === 'gem') {
          sound.playGem();
          this.stats.gemsCollected++;
          const gemCoins = 5 * coinMultiplier;
          this.stats.coinsCollected += gemCoins; // Gems grant bonus coins directly!
          this.stats.score += 300 * scoreMultiplier;
          this.particles.emitSparkles(col.position, 0x06b6d4, 20);
          updateDailyChallengeProgress('coins', gemCoins, true);
        } else if (col.type === 'powerup' && col.powerUpType) {
          if (col.powerUpType === 'star') {
            sound.playStarChime();
            const duration = 12;
            this.activePowerUps.set('star', { duration, maxDuration: duration });
            this.stats.coinsCollected += (10 * coinMultiplier);
            this.particles.emitSparkles(col.position, 0xfde047, 45);
            updateDailyChallengeProgress('star', 1, true);
          } else {
            sound.playPowerUp();
            const duration = col.powerUpType === 'freeze' ? 7 : 10;
            this.activePowerUps.set(col.powerUpType, { duration, maxDuration: duration });
            this.stats.coinsCollected += (3 * coinMultiplier);
            this.particles.emitSparkles(col.position, 0xec4899, 25);
          }
        }
      }
    }

    // 2. Obstacles (Trees, Rocks, Snowmen, Slalom Gates, Dynamic Hazards)
    for (const obs of this.track.obstacles) {
      if (!obs.isActive) continue;

      const dx = Math.abs(pX - obs.position.x);
      const dz = pZ - obs.position.z;
      const dy = Math.abs(pY - obs.position.y);

      // A. Slalom Gates Check (Awards bonus coins + boost!)
      if (obs.type === 'slalom_gate') {
        if (!obs.dynamic?.isPassed && Math.abs(dz) < 1.2 && dx < 2.5 && dy < 3.2) {
          obs.dynamic!.isPassed = true;
          sound.playGate();
          this.stats.gatesPassed++;
          updateDailyChallengeProgress('gates', 1, true);
          this.stats.coinsCollected += 15 * scoreDoubleBonus; // +15 coins (or 30 if double coins active!)
          this.stats.score += 150 * scoreMultiplier;
          this.stats.multiplier = Math.min(10, this.stats.multiplier + 0.5);
          this.boostEnergy = Math.min(100, this.boostEnergy + 25);
          this.callbacks.onGatePassed();
          this.particles.emitSparkles(obs.position, 0x0284c7, 16);
        }
        continue;
      }

      // B. Thin Ice Patch (low friction drift)
      if (obs.type === 'thin_ice') {
        if (dx < (obs.collider.halfWidth || 3.0) && Math.abs(dz) < (obs.collider.halfLength || 4.0)) {
          // Steer carve reduced friction
          this.lateralSpeed *= 1.08;
          this.particles.emitSnowSpray(this.playerPos, 0.8, this.forwardSpeed, 4);
        }
        continue;
      }

      // C. Near-Miss Detection (giving adrenaline points and bonus coins!)
      const dangerDist = Math.sqrt(dx * dx + dz * dz);
      if (dangerDist > obs.collider.radius && dangerDist < obs.collider.radius + 1.8 && Math.abs(dz) < 1.5) {
        if (!obs.dynamic?.hasTriggered) {
          obs.dynamic = { ...(obs.dynamic || {}), hasTriggered: true };
          this.stats.nearMisses++;
          this.stats.coinsCollected += 5; // +5 bonus coins on close brush!
          this.stats.score += 100 * scoreMultiplier;
          if (this.characterDef.id === 'vortex_valkyrie') {
            this.boostEnergy = Math.min(100, this.boostEnergy + 15);
          }
          this.callbacks.onNearMiss();
        }
      }

      // D. Direct Collision
      const isHit = dx < obs.collider.radius && Math.abs(dz) < 1.0 && dy < obs.collider.height;

      if (isHit) {
        // Can Yeti smash small rocks?
        if (this.characterDef.id === 'yeti_rider' && obs.type === 'rock') {
          obs.isActive = false;
          obs.mesh.visible = false;
          sound.playCrash();
          this.particles.emitExplosion(obs.position, 30);
          this.stats.coinsCollected += 20;
          this.stats.score += 500;
          this.cameraShake = 0.4;
          continue;
        }

        // Snowmen explode delightfully and reward coins!
        if (obs.type === 'snowman') {
          obs.isActive = false;
          obs.mesh.visible = false;
          sound.playLand(1.8);
          this.particles.emitExplosion(obs.position, 35);
          this.stats.coinsCollected += 20;
          this.stats.score += 200;
          this.cameraShake = 0.25;
          continue;
        }

        // Grind on fallen log rail
        if (obs.type === 'log_rail') {
          if (this.isAirborne && this.verticalSpeed <= 0) {
            // Rail grind success!
            this.isAirborne = false;
            this.playerPos.y = obs.position.y + 0.35;
            this.stats.coinsCollected += 25;
            this.stats.score += 350 * scoreMultiplier;
            this.particles.emitSparkles(this.playerPos, 0xffffff, 8);
            continue;
          }
        }

        // Nitro blast through obstacle
        if (this.activePowerUps.has('nitro')) {
          obs.isActive = false;
          obs.mesh.visible = false;
          sound.playCrash();
          this.particles.emitExplosion(obs.position, 40);
          this.cameraShake = 0.5;
          continue;
        }

        // Shield protection
        if (hasShield) {
          this.activePowerUps.delete('shield');
          obs.isActive = false;
          obs.mesh.visible = false;
          this.hitstopTimer = 0.05; // 50ms hitstop
          this.cameraShake = 0.4;
          sound.playCrash();
          this.particles.emitExplosion(this.playerPos, 25);
          this.callbacks.onShieldLost();
          continue;
        }

        // Glacier Guardian Armor charge
        if (this.armorCharges > 0) {
          this.armorCharges--;
          obs.isActive = false;
          obs.mesh.visible = false;
          this.hitstopTimer = 0.06;
          this.cameraShake = 0.45;
          sound.playCrash();
          this.particles.emitExplosion(this.playerPos, 25);
          this.callbacks.onShieldLost();
          continue;
        }

        // Catastrophic Crash / Wipeout!
        this.triggerCrash(`Hit ${obs.type}`);
        return;
      }
    }
  }

  private triggerCrash(reason: string) {
    this.status = 'gameover';
    this.hitstopTimer = 0.08; // 80ms hitstop
    this.cameraShake = 0.8;
    sound.playCrash();
    sound.stopAtmosphericMusic();

    this.particles.emitExplosion(this.playerPos, 60);

    // Call game over
    this.callbacks.onGameOver(this.stats);
  }

  public cycleWeather() {
    this.weather.nextWeather();
  }

  public setWeather(type: WeatherType) {
    this.weather.setWeather(type);
  }

  public dispose() {
    this.isDestroyed = true;
    window.removeEventListener('resize', this.handleResize);
    cancelAnimationFrame(this.animFrameId);
    clearTimeout(this.animFrameId);

    sound.stopAtmosphericMusic();

    if (this.playerRig) this.playerRig.dispose();
    this.skiTracks.dispose();
    this.weather.dispose();
    this.track.dispose();
    this.particles.dispose();
    this.renderer.dispose();
  }
}
