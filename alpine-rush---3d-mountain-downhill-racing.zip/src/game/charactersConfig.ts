import { CharacterDef, CharacterId, CharacterCustomization, PlayerProgress } from '../types/game';

export const CHARACTERS: CharacterDef[] = [
  {
    id: 'alpine_blitz',
    name: 'Alpine Blitz',
    title: 'Downhill Speed Skier',
    vehicleType: 'skis',
    description: 'Olympic-caliber downhill racer built for breakneck speed and razor-sharp carve arcs.',
    specialAbility: 'Slipstream: +15% maximum top speed and aerodynamic pole tucking.',
    stats: {
      speed: 9,
      carving: 7,
      airtime: 6,
      boost: 7,
      resilience: 6,
    },
    unlockCost: 0,
    defaultCustomization: {
      jacketColor: '#0284c7',   // Ocean Blue
      jacketPattern: 'stripes',
      pantsColor: '#0f172a',    // Dark Navy
      helmetColor: '#e0f2fe',   // Ice White
      visorColor: '#f59e0b',    // Gold Amber
      boardColor: '#0ea5e9',    // Electric Sky
      accentColor: '#38bdf8',
    },
  },
  {
    id: 'frost_maverick',
    name: 'Frost Maverick',
    title: 'Freestyle Snowboarder',
    vehicleType: 'snowboard',
    description: 'Slopestyle gold medalist who thrives off kickers, cliff drops, and inverted spins.',
    specialAbility: 'Trick Maestro: +50% airtime hanging and double trick combo multipliers.',
    stats: {
      speed: 7,
      carving: 8,
      airtime: 10,
      boost: 7,
      resilience: 5,
    },
    unlockCost: 0,
    defaultCustomization: {
      jacketColor: '#8b5cf6',   // Purple
      jacketPattern: 'camo',
      pantsColor: '#18181b',    // Black
      helmetColor: '#ec4899',   // Neon Pink
      visorColor: '#06b6d4',    // Cyan Visor
      boardColor: '#a855f7',    // Vibrant Violet
      accentColor: '#f43f5e',
    },
  },
  {
    id: 'glacier_guardian',
    name: 'Glacier Guardian',
    title: 'Heavy Mountain Patrol',
    vehicleType: 'snowboard',
    description: 'Rugged alpine rescuer equipped with reinforced kinetic shock absorbers.',
    specialAbility: 'Ice Armor: Absorbs 1 heavy tree or rock impact without wiping out.',
    stats: {
      speed: 6,
      carving: 6,
      airtime: 5,
      boost: 6,
      resilience: 10,
    },
    unlockCost: 250,
    unlockRequirement: 'Collect 250 Snow Coins',
    defaultCustomization: {
      jacketColor: '#ea580c',   // Safety Blaze Orange
      jacketPattern: 'solid',
      pantsColor: '#334155',    // Slate Grey
      helmetColor: '#f97316',   // High-Vis Orange
      visorColor: '#10b981',    // Emerald Green
      boardColor: '#c2410c',    // Burnt Orange
      accentColor: '#fbbf24',
    },
  },
  {
    id: 'vortex_valkyrie',
    name: 'Vortex Valkyrie',
    title: 'Experimental Rocket Skier',
    vehicleType: 'skis',
    description: 'Cyber-mountain test pilot with dual mini-thrusters mounted on carbon skis.',
    specialAbility: 'Nitro Surge: Boost recharges 2x faster from slalom gates and obstacle near-misses.',
    stats: {
      speed: 8,
      carving: 9,
      airtime: 7,
      boost: 10,
      resilience: 6,
    },
    unlockCost: 600,
    unlockRequirement: 'Collect 600 Snow Coins',
    defaultCustomization: {
      jacketColor: '#10b981',   // Cyber Emerald
      jacketPattern: 'cyber',
      pantsColor: '#09090b',    // Midnight Carbon
      helmetColor: '#059669',   // Deep Emerald
      visorColor: '#a855f7',    // Neon Violet
      boardColor: '#34d399',    // Mint Green
      accentColor: '#10b981',
    },
  },
  {
    id: 'yeti_rider',
    name: 'Yeti Rider',
    title: 'Mythic Beast of the Peak',
    vehicleType: 'yeti_stride',
    description: 'Ancient mountain beast surfing on a giant carved frozen cedar slab.',
    specialAbility: 'Avalanche Stride: Smashes through small snow rocks to trigger bonus score.',
    stats: {
      speed: 10,
      carving: 5,
      airtime: 8,
      boost: 8,
      resilience: 9,
    },
    unlockCost: 1200,
    unlockRequirement: 'Collect 1,200 Snow Coins',
    defaultCustomization: {
      jacketColor: '#f8fafc',   // Polar Fur White
      jacketPattern: 'chevron',
      pantsColor: '#64748b',    // Slate Trousers
      helmetColor: '#3b82f6',   // Frost Horn Crown
      visorColor: '#38bdf8',    // Ice Blue
      boardColor: '#78350f',    // Mountain Cedar
      accentColor: '#60a5fa',
    },
  },
];

export const PALETTES = [
  { name: 'Alpine Cyan', hex: '#0284c7' },
  { name: 'Aurora Neon', hex: '#10b981' },
  { name: 'Blaze Orange', hex: '#ea580c' },
  { name: 'Cyber Violet', hex: '#8b5cf6' },
  { name: 'Crimson Peak', hex: '#e11d48' },
  { name: 'Glacier White', hex: '#f8fafc' },
  { name: 'Solar Gold', hex: '#f59e0b' },
  { name: 'Stealth Onyx', hex: '#18181b' },
];

export const PATTERNS: { id: CharacterCustomization['jacketPattern']; label: string; desc: string }[] = [
  { id: 'solid', label: 'Solid Matte', desc: 'Minimalist clean mountain finish' },
  { id: 'stripes', label: 'Alpine Racing Stripes', desc: 'Dual aerodynamic speed bands' },
  { id: 'camo', label: 'Snow Camouflage', desc: 'Subtle fragmented winter camo' },
  { id: 'cyber', label: 'Cyber Grid', desc: 'Hexagonal futuristic circuit pattern' },
  { id: 'chevron', label: 'Retro Chevron', desc: 'Classic 80s ski championship arrows' },
];

export const STORAGE_KEY = 'alpine_rush_save_v1';

export function getInitialProgress(): PlayerProgress {
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      const parsed = JSON.parse(saved);
      return {
        coins: parsed.coins ?? 100, // Give some starting coins to try out customizer
        gems: parsed.gems ?? 5,
        highScore: parsed.highScore ?? 0,
        maxDistance: parsed.maxDistance ?? 0,
        unlockedCharacters: parsed.unlockedCharacters || ['alpine_blitz', 'frost_maverick'],
        selectedCharacter: parsed.selectedCharacter || 'alpine_blitz',
        selectedMap: (parsed.selectedMap === 'beach' ? 'beach' : 'snow'),
        customizations: {
          ...Object.fromEntries(CHARACTERS.map(c => [c.id, c.defaultCustomization])),
          ...(parsed.customizations || {})
        },
        soundEnabled: parsed.soundEnabled ?? true,
        musicEnabled: parsed.musicEnabled ?? true,
      };
    }
  } catch (e) {
    console.error('Failed to load saved progress:', e);
  }

  return {
    coins: 100,
    gems: 5,
    highScore: 0,
    maxDistance: 0,
    unlockedCharacters: ['alpine_blitz', 'frost_maverick'],
    selectedCharacter: 'alpine_blitz',
    selectedMap: 'snow',
    customizations: Object.fromEntries(CHARACTERS.map(c => [c.id, c.defaultCustomization])) as Record<CharacterId, CharacterCustomization>,
    soundEnabled: true,
    musicEnabled: true,
  };
}

export function saveProgress(progress: PlayerProgress) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(progress));
  } catch (e) {
    console.error('Failed to save progress:', e);
  }
}
