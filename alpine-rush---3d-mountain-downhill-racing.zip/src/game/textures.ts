import * as THREE from 'three';
import { JacketPattern, VehicleType } from '../types/game';

/**
 * Creates a procedural canvas texture for the racer jacket outfit with custom patterns
 */
export function createJacketTexture(
  baseColorHex: string,
  pattern: JacketPattern,
  accentColorHex: string
): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 512;
  const ctx = canvas.getContext('2d')!;

  // Base background
  ctx.fillStyle = baseColorHex;
  ctx.fillRect(0, 0, 512, 512);

  if (pattern === 'solid') {
    // Subtle fabric weave texture
    ctx.fillStyle = 'rgba(255, 255, 255, 0.08)';
    for (let y = 0; y < 512; y += 4) {
      ctx.fillRect(0, y, 512, 1.5);
    }
    // Subtle shoulder accents
    ctx.fillStyle = accentColorHex;
    ctx.fillRect(0, 0, 512, 32);
    ctx.fillRect(240, 32, 32, 480); // zipper
  } else if (pattern === 'stripes') {
    // Bold diagonal racing stripes
    ctx.save();
    ctx.translate(256, 256);
    ctx.rotate(-Math.PI / 4);
    ctx.fillStyle = accentColorHex;
    ctx.fillRect(-300, -50, 600, 40);
    ctx.fillRect(-300, 10, 600, 20);
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(-300, 40, 600, 8);
    ctx.restore();

    // Center seam & collar
    ctx.fillStyle = '#111827';
    ctx.fillRect(250, 0, 12, 512);
  } else if (pattern === 'camo') {
    // Winter fractured camouflage
    const colors = [
      accentColorHex,
      '#ffffff',
      'rgba(0, 0, 0, 0.35)',
      'rgba(255, 255, 255, 0.4)',
    ];

    for (let i = 0; i < 48; i++) {
      ctx.fillStyle = colors[i % colors.length];
      ctx.beginPath();
      const x = (i * 137) % 512;
      const y = (i * 89) % 512;
      const size = 30 + (i % 5) * 15;
      ctx.moveTo(x, y);
      ctx.lineTo(x + size, y + size * 0.4);
      ctx.lineTo(x + size * 0.8, y + size * 1.2);
      ctx.lineTo(x - size * 0.3, y + size);
      ctx.closePath();
      ctx.fill();
    }
    // Zipper
    ctx.fillStyle = '#0f172a';
    ctx.fillRect(250, 0, 12, 512);
  } else if (pattern === 'cyber') {
    // Hexagonal circuit grid
    ctx.strokeStyle = accentColorHex;
    ctx.lineWidth = 3;
    const size = 32;
    for (let x = 0; x < 512; x += size * 1.5) {
      for (let y = 0; y < 512; y += size * Math.sqrt(3)) {
        ctx.beginPath();
        for (let a = 0; a < 6; a++) {
          const angle = (a * Math.PI) / 3;
          const hx = x + size * Math.cos(angle);
          const hy = y + size * Math.sin(angle);
          if (a === 0) ctx.moveTo(hx, hy);
          else ctx.lineTo(hx, hy);
        }
        ctx.closePath();
        ctx.stroke();
      }
    }
    // Glowing center conduits
    ctx.strokeStyle = '#ffffff';
    ctx.lineWidth = 6;
    ctx.beginPath();
    ctx.moveTo(256, 0);
    ctx.lineTo(256, 512);
    ctx.stroke();
  } else if (pattern === 'chevron') {
    // Retro 80s V-stripes
    ctx.fillStyle = accentColorHex;
    for (let y = 40; y < 512; y += 110) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(256, y + 80);
      ctx.lineTo(512, y);
      ctx.lineTo(512, y + 45);
      ctx.lineTo(256, y + 125);
      ctx.lineTo(0, y + 45);
      ctx.closePath();
      ctx.fill();
    }
    // White border line
    ctx.fillStyle = '#ffffff';
    for (let y = 40; y < 512; y += 110) {
      ctx.beginPath();
      ctx.moveTo(0, y + 45);
      ctx.lineTo(256, y + 125);
      ctx.lineTo(512, y + 45);
      ctx.lineTo(512, y + 55);
      ctx.lineTo(256, y + 135);
      ctx.lineTo(0, y + 55);
      ctx.closePath();
      ctx.fill();
    }
  }

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.needsUpdate = true;
  return texture;
}

/**
 * Creates board / ski top-sheet graphics
 */
export function createBoardTexture(
  boardColorHex: string,
  accentColorHex: string,
  vehicleType: VehicleType
): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 256;
  canvas.height = 1024;
  const ctx = canvas.getContext('2d')!;

  // Base background
  ctx.fillStyle = boardColorHex;
  ctx.fillRect(0, 0, 256, 1024);

  // Carbon fiber weave background effect
  ctx.fillStyle = 'rgba(0, 0, 0, 0.2)';
  for (let y = 0; y < 1024; y += 8) {
    ctx.fillRect(0, y, 256, 4);
  }

  // Graphic accents
  ctx.fillStyle = accentColorHex;
  ctx.beginPath();
  ctx.moveTo(0, 200);
  ctx.lineTo(256, 350);
  ctx.lineTo(256, 420);
  ctx.lineTo(0, 270);
  ctx.closePath();
  ctx.fill();

  ctx.beginPath();
  ctx.moveTo(0, 750);
  ctx.lineTo(256, 600);
  ctx.lineTo(256, 670);
  ctx.lineTo(0, 820);
  ctx.closePath();
  ctx.fill();

  // Sport logo text
  ctx.save();
  ctx.translate(128, 512);
  ctx.rotate(-Math.PI / 2);
  ctx.fillStyle = '#ffffff';
  ctx.font = 'bold 36px "Chakra Petch", sans-serif';
  ctx.textAlign = 'center';
  ctx.fillText(vehicleType === 'skis' ? 'ALPINE // CARVE' : 'PRO RUSH // 162', 0, 12);
  ctx.restore();

  // Steel edges indicator
  ctx.fillStyle = '#e2e8f0';
  ctx.fillRect(0, 0, 8, 1024);
  ctx.fillRect(248, 0, 8, 1024);

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.needsUpdate = true;
  return texture;
}

/**
 * Creates a procedural normal map for crisp snow sparkle and micro moguls
 */
export function createSnowNormalTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 512;
  const ctx = canvas.getContext('2d')!;
  const imgData = ctx.createImageData(512, 512);
  const data = imgData.data;

  for (let y = 0; y < 512; y++) {
    for (let x = 0; x < 512; x++) {
      const idx = (y * 512 + x) * 4;
      // Wavy windblown snow sastrugi wave
      const wave = Math.sin(x * 0.05 + Math.cos(y * 0.02) * 2.0) * 12;
      // High-frequency crystalline snow facet glint
      const sparkle = (Math.random() - 0.5) * 28;

      data[idx] = Math.min(255, Math.max(0, 128 + wave + sparkle));     // nx
      data[idx + 1] = Math.min(255, Math.max(0, 128 + sparkle * 0.8)); // ny
      data[idx + 2] = 240;                                             // nz (mostly upward)
      data[idx + 3] = 255;
    }
  }
  ctx.putImageData(imgData, 0, 0);

  const texture = new THREE.CanvasTexture(canvas);
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.RepeatWrapping;
  texture.repeat.set(12, 48);
  texture.needsUpdate = true;
  return texture;
}

/**
 * Procedural snow ground diffuse texture with wind ripples and crystalline glint
 */
export function createSnowDiffuseTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 512;
  const ctx = canvas.getContext('2d')!;

  // Pristine alpine snow gradient with subtle blue ambient sky bounce
  const grad = ctx.createLinearGradient(0, 0, 0, 512);
  grad.addColorStop(0, '#ffffff');
  grad.addColorStop(0.4, '#f8fafc');
  grad.addColorStop(0.8, '#f1f5f9');
  grad.addColorStop(1, '#e2e8f0');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, 512, 512);

  // Soft windblown sastrugi drifts
  ctx.fillStyle = 'rgba(219, 234, 254, 0.35)'; // Sky blue tint in drifts
  for (let y = 0; y < 512; y += 24) {
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.bezierCurveTo(150, y + 14, 320, y - 12, 512, y + 4);
    ctx.lineTo(512, y + 10);
    ctx.bezierCurveTo(320, y - 2, 150, y + 22, 0, y + 8);
    ctx.closePath();
    ctx.fill();
  }

  // Micro crystalline powder glints
  ctx.fillStyle = '#ffffff';
  for (let i = 0; i < 400; i++) {
    const rx = Math.random() * 512;
    const ry = Math.random() * 512;
    const r = Math.random() * 1.5;
    ctx.beginPath();
    ctx.arc(rx, ry, r, 0, Math.PI * 2);
    ctx.fill();
  }

  const texture = new THREE.CanvasTexture(canvas);
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.RepeatWrapping;
  texture.repeat.set(8, 32);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.needsUpdate = true;
  return texture;
}

/**
 * Soft radial alpha texture for realistic billowing powder puffs
 */
export function createPowderPuffTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 128;
  canvas.height = 128;
  const ctx = canvas.getContext('2d')!;

  const grad = ctx.createRadialGradient(64, 64, 0, 64, 64, 64);
  grad.addColorStop(0, 'rgba(255, 255, 255, 0.9)');
  grad.addColorStop(0.3, 'rgba(241, 245, 249, 0.6)');
  grad.addColorStop(0.7, 'rgba(224, 242, 254, 0.2)');
  grad.addColorStop(1, 'rgba(255, 255, 255, 0.0)');

  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, 128, 128);

  const texture = new THREE.CanvasTexture(canvas);
  texture.needsUpdate = true;
  return texture;
}

/**
 * Procedural coastal sand diffuse texture with warm golden tone, dune ridges, and mineral sparkle
 */
export function createSandDiffuseTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 512;
  const ctx = canvas.getContext('2d')!;

  // Warm golden sun-drenched coastal sand gradient
  const grad = ctx.createLinearGradient(0, 0, 0, 512);
  grad.addColorStop(0, '#fef08a');   // Bright sunlit crest
  grad.addColorStop(0.3, '#fde047'); // Warm beach gold
  grad.addColorStop(0.7, '#eab308'); // Amber dune tone
  grad.addColorStop(1, '#ca8a04');   // Deeper warm sand trough
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, 512, 512);

  // Windblown dune ripple ridges
  ctx.fillStyle = 'rgba(180, 83, 9, 0.22)';
  for (let y = 0; y < 512; y += 18) {
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.bezierCurveTo(140, y + 8, 340, y - 10, 512, y + 4);
    ctx.lineTo(512, y + 7);
    ctx.bezierCurveTo(340, y - 3, 140, y + 15, 0, y + 7);
    ctx.closePath();
    ctx.fill();
  }

  // Sparkling golden quartz/mica crystals
  ctx.fillStyle = '#ffffff';
  for (let i = 0; i < 350; i++) {
    const rx = Math.random() * 512;
    const ry = Math.random() * 512;
    const r = Math.random() * 1.4;
    ctx.beginPath();
    ctx.arc(rx, ry, r, 0, Math.PI * 2);
    ctx.fill();
  }

  // Crushed seashell flecks (coral pink & pearl white)
  const shellColors = ['rgba(254, 205, 211, 0.6)', 'rgba(255, 255, 255, 0.8)', 'rgba(253, 224, 71, 0.5)'];
  for (let i = 0; i < 180; i++) {
    ctx.fillStyle = shellColors[i % shellColors.length];
    const rx = Math.random() * 512;
    const ry = Math.random() * 512;
    ctx.fillRect(rx, ry, 2, 2);
  }

  const texture = new THREE.CanvasTexture(canvas);
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.RepeatWrapping;
  texture.repeat.set(8, 32);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.needsUpdate = true;
  return texture;
}

/**
 * Procedural normal map for coastal sand dune ripples
 */
export function createSandNormalTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 512;
  const ctx = canvas.getContext('2d')!;
  const imgData = ctx.createImageData(512, 512);
  const data = imgData.data;

  for (let y = 0; y < 512; y++) {
    for (let x = 0; x < 512; x++) {
      const idx = (y * 512 + x) * 4;
      // Wavy windblown sand dune ridges
      const ripple = Math.sin(y * 0.15 + Math.cos(x * 0.04) * 3.0) * 22;
      const microGrain = (Math.random() - 0.5) * 16;

      data[idx] = Math.min(255, Math.max(0, 128 + microGrain));
      data[idx + 1] = Math.min(255, Math.max(0, 128 + ripple + microGrain * 0.5));
      data[idx + 2] = 230; // Strong upward normal
      data[idx + 3] = 255;
    }
  }
  ctx.putImageData(imgData, 0, 0);

  const texture = new THREE.CanvasTexture(canvas);
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.RepeatWrapping;
  texture.repeat.set(12, 48);
  texture.needsUpdate = true;
  return texture;
}

/**
 * Tropical Hawaiian floral beach shirt & rashguard texture
 */
export function createBeachShirtTexture(
  baseColorHex: string,
  accentColorHex: string
): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 512;
  const ctx = canvas.getContext('2d')!;

  // Base tropical fabric
  ctx.fillStyle = baseColorHex;
  ctx.fillRect(0, 0, 512, 512);

  // Tropical palm leaves & hibiscus flowers pattern
  const petalColors = ['#ffffff', accentColorHex, '#fef08a', '#f43f5e'];
  for (let row = 0; row < 5; row++) {
    for (let col = 0; col < 5; col++) {
      const cx = col * 110 + (row % 2) * 55 + 25;
      const cy = row * 110 + 25;

      // 5-petal tropical flower
      for (let p = 0; p < 5; p++) {
        const ang = (p * Math.PI * 2) / 5;
        const px = cx + Math.cos(ang) * 18;
        const py = cy + Math.sin(ang) * 18;

        ctx.fillStyle = petalColors[(row + col + p) % petalColors.length];
        ctx.beginPath();
        ctx.arc(px, py, 11, 0, Math.PI * 2);
        ctx.fill();
      }

      // Yellow flower center
      ctx.fillStyle = '#facc15';
      ctx.beginPath();
      ctx.arc(cx, cy, 7, 0, Math.PI * 2);
      ctx.fill();

      // Curved tropical palm frond
      ctx.strokeStyle = '#15803d';
      ctx.lineWidth = 4;
      ctx.beginPath();
      ctx.moveTo(cx - 25, cy - 20);
      ctx.quadraticCurveTo(cx - 40, cy - 35, cx - 60, cy - 25);
      ctx.stroke();
    }
  }

  // Zipper / open collar center accent
  ctx.fillStyle = 'rgba(0, 0, 0, 0.25)';
  ctx.fillRect(250, 0, 12, 512);

  const texture = new THREE.CanvasTexture(canvas);
  texture.needsUpdate = true;
  return texture;
}

/**
 * High-gloss resin tropical surfboard & sandboard texture
 */
export function createSurfboardTexture(
  baseColorHex: string,
  accentColorHex: string
): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 512;
  const ctx = canvas.getContext('2d')!;

  // Vibrant gradient resin deck
  const grad = ctx.createLinearGradient(0, 0, 512, 512);
  grad.addColorStop(0, '#ffffff');
  grad.addColorStop(0.2, baseColorHex);
  grad.addColorStop(0.8, accentColorHex);
  grad.addColorStop(1, '#0284c7');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, 512, 512);

  // Dynamic ocean breaker wave crest decal
  ctx.fillStyle = '#ffffff';
  ctx.beginPath();
  ctx.moveTo(0, 200);
  ctx.bezierCurveTo(150, 160, 300, 340, 512, 180);
  ctx.lineTo(512, 230);
  ctx.bezierCurveTo(300, 390, 150, 210, 0, 250);
  ctx.closePath();
  ctx.fill();

  // Tropical sunburst logo
  ctx.fillStyle = '#fbbf24';
  ctx.beginPath();
  ctx.arc(256, 120, 32, 0, Math.PI * 2);
  ctx.fill();

  // Carbon fiber / balsa wood stringer centerline
  ctx.fillStyle = '#1e293b';
  ctx.fillRect(252, 0, 8, 512);

  // Deck traction pad at the tail
  ctx.fillStyle = '#0f172a';
  ctx.fillRect(180, 420, 152, 70);

  const texture = new THREE.CanvasTexture(canvas);
  texture.needsUpdate = true;
  return texture;
}
