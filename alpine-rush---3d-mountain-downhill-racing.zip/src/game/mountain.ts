import * as THREE from 'three';
import { PowerUpType, MapTheme } from '../types/game';
import { 
  createSnowDiffuseTexture, 
  createSnowNormalTexture,
  createSandDiffuseTexture,
  createSandNormalTexture
} from './textures';

export interface ObstacleInstance {
  id: number;
  type: 'tree' | 'rock' | 'snowman' | 'log_rail' | 'slalom_gate' | 'icicle' | 'rolling_snowball' | 'thin_ice' | 'tiki' | 'sandcastle' | 'coconut';
  mesh: THREE.Group;
  collider: {
    type: 'box' | 'cylinder' | 'sphere';
    radius: number;
    halfWidth?: number;
    halfLength?: number;
    height: number;
  };
  position: THREE.Vector3;
  isActive: boolean;
  // Dynamic hazard properties
  dynamic?: {
    vy?: number;
    vx?: number;
    vz?: number;
    timer?: number;
    warningCircle?: THREE.Mesh;
    hasTriggered?: boolean;
    isPassed?: boolean;
  };
}

export interface CollectibleInstance {
  id: number;
  type: 'coin' | 'gem' | 'powerup';
  powerUpType?: PowerUpType;
  mesh: THREE.Group;
  position: THREE.Vector3;
  baseY: number;
  isCollected: boolean;
  radius: number;
}

export interface JumpRamp {
  position: THREE.Vector3;
  width: number;
  length: number;
  height: number;
  mesh: THREE.Mesh;
}

export class MountainTrack {
  public root: THREE.Group;
  public obstacles: ObstacleInstance[] = [];
  public collectibles: CollectibleInstance[] = [];
  public ramps: JumpRamp[] = [];
  public mapTheme: MapTheme = 'snow';

  private terrainChunks: { mesh: THREE.Mesh; oceanLeft?: THREE.Mesh; oceanRight?: THREE.Mesh; zStart: number; zEnd: number }[] = [];
  private chunkLength = 120;
  private chunkWidth = 60;
  private activeChunkCount = 4;
  private nextObstacleId = 1;
  private nextCollectibleId = 1;

  // Snow Materials
  private snowMaterial: THREE.MeshPhysicalMaterial;
  private icePatchMaterial: THREE.MeshStandardMaterial;
  private woodMaterial: THREE.MeshStandardMaterial;
  private pineFoliageMaterial: THREE.MeshStandardMaterial;
  private pineSnowMaterial: THREE.MeshStandardMaterial;
  private rockMaterial: THREE.MeshStandardMaterial;

  // Beach Materials (Insane high-fidelity coastal graphics)
  private sandMaterial: THREE.MeshPhysicalMaterial;
  private oceanMaterial: THREE.MeshStandardMaterial;
  private palmBarkMaterial: THREE.MeshStandardMaterial;
  private palmFrondMaterial: THREE.MeshStandardMaterial;
  private coconutMaterial: THREE.MeshStandardMaterial;
  private beachRockMaterial: THREE.MeshStandardMaterial;
  private sandcastleMaterial: THREE.MeshStandardMaterial;
  private tikiWoodMaterial: THREE.MeshStandardMaterial;
  private tidePoolMaterial: THREE.MeshStandardMaterial;

  // Collectible Materials
  private coinMaterial: THREE.MeshStandardMaterial;
  private gemMaterial: THREE.MeshStandardMaterial;
  private powerUpMaterials: Record<PowerUpType, THREE.MeshStandardMaterial>;
  private warningMaterial: THREE.MeshBasicMaterial;

  constructor(initialTheme: MapTheme = 'snow') {
    this.mapTheme = initialTheme;
    this.root = new THREE.Group();
    this.root.name = 'mountain_track';

    // 1. Snow Materials
    const snowDiffuse = createSnowDiffuseTexture();
    const snowNormal = createSnowNormalTexture();

    this.snowMaterial = new THREE.MeshPhysicalMaterial({
      map: snowDiffuse,
      normalMap: snowNormal,
      normalScale: new THREE.Vector2(0.8, 0.8),
      roughness: 0.78,
      metalness: 0.04,
      clearcoat: 0.22,
      clearcoatRoughness: 0.4,
    });

    this.icePatchMaterial = new THREE.MeshStandardMaterial({
      color: 0xbae6fd,
      roughness: 0.08,
      metalness: 0.35,
      transparent: true,
      opacity: 0.85,
    });

    this.woodMaterial = new THREE.MeshStandardMaterial({
      color: 0x5c3d2e,
      roughness: 0.85,
      metalness: 0.05,
    });

    this.pineFoliageMaterial = new THREE.MeshStandardMaterial({
      color: 0x164e3b, // Deep forest green
      roughness: 0.8,
      metalness: 0.1,
    });

    this.pineSnowMaterial = new THREE.MeshStandardMaterial({
      color: 0xf8fafc,
      roughness: 0.9,
      metalness: 0.05,
    });

    this.rockMaterial = new THREE.MeshStandardMaterial({
      color: 0x475569,
      roughness: 0.95,
      metalness: 0.15,
      flatShading: true,
    });

    // 2. Beach Materials (High-Performance Sparkling Tropical Ocean & Reefs)
    const sandDiffuse = createSandDiffuseTexture();
    const sandNormal = createSandNormalTexture();

    this.sandMaterial = new THREE.MeshPhysicalMaterial({
      map: sandDiffuse,
      normalMap: sandNormal,
      normalScale: new THREE.Vector2(0.85, 0.85),
      roughness: 0.82,
      metalness: 0.02,
      clearcoat: 0.18,
      clearcoatRoughness: 0.35,
    });

    // Ultra fast, radiant turquoise tropical ocean water (no laggy transmission passes)
    this.oceanMaterial = new THREE.MeshStandardMaterial({
      color: 0x0284c7, // Tropical azure ocean water
      roughness: 0.06,
      metalness: 0.2,
      transparent: true,
      opacity: 0.92,
    });

    this.palmBarkMaterial = new THREE.MeshStandardMaterial({
      color: 0x78350f, // Segmented tropical palm bark
      roughness: 0.88,
      metalness: 0.05,
    });

    this.palmFrondMaterial = new THREE.MeshStandardMaterial({
      color: 0x16a34a, // Vibrant tropical green
      roughness: 0.7,
      metalness: 0.1,
      side: THREE.DoubleSide,
    });

    this.coconutMaterial = new THREE.MeshStandardMaterial({
      color: 0x451a03,
      roughness: 0.85,
      metalness: 0.1,
    });

    this.beachRockMaterial = new THREE.MeshStandardMaterial({
      color: 0x0f766e, // Deep turquoise coral reef spire
      roughness: 0.75,
      metalness: 0.15,
      flatShading: true,
    });

    this.sandcastleMaterial = new THREE.MeshStandardMaterial({
      color: 0xfde047,
      roughness: 0.8,
      metalness: 0.1,
    });

    this.tikiWoodMaterial = new THREE.MeshStandardMaterial({
      color: 0x3f2314, // Dark Polynesian carved wood
      roughness: 0.85,
      metalness: 0.05,
    });

    this.tidePoolMaterial = new THREE.MeshStandardMaterial({
      color: 0x38bdf8,
      roughness: 0.05,
      metalness: 0.2,
      transparent: true,
      opacity: 0.75,
    });

    // 3. Collectible & FX Materials (Fast Standard PBR)
    this.coinMaterial = new THREE.MeshStandardMaterial({
      color: 0xfbbf24, // Gold
      metalness: 0.85,
      roughness: 0.25,
    });

    this.gemMaterial = new THREE.MeshStandardMaterial({
      color: 0x06b6d4, // Cyan diamond
      opacity: 0.9,
      transparent: true,
      roughness: 0.08,
      metalness: 0.4,
    });

    this.powerUpMaterials = {
      nitro: new THREE.MeshStandardMaterial({ color: 0xef4444, metalness: 0.7, roughness: 0.3 }),
      shield: new THREE.MeshStandardMaterial({ color: 0x38bdf8, metalness: 0.5, roughness: 0.2 }),
      multiplier: new THREE.MeshStandardMaterial({ color: 0xeab308, metalness: 0.8, roughness: 0.2 }),
      magnet: new THREE.MeshStandardMaterial({ color: 0xec4899, metalness: 0.7, roughness: 0.3 }),
      freeze: new THREE.MeshStandardMaterial({ color: 0x67e8f9, metalness: 0.6, roughness: 0.2 }),
      star: new THREE.MeshStandardMaterial({
        color: 0xfde047,
        emissive: 0xf59e0b,
        emissiveIntensity: 0.85,
        metalness: 0.9,
        roughness: 0.1,
      }),
    };

    this.warningMaterial = new THREE.MeshBasicMaterial({
      color: 0xff0000,
      transparent: true,
      opacity: 0.5,
      wireframe: true,
    });

    // Initialize 4 starting chunks (-60m to ~420m)
    for (let i = -1; i < this.activeChunkCount - 1; i++) {
      this.spawnChunk(i * this.chunkLength);
    }
  }

  public setMapTheme(theme: MapTheme) {
    if (this.mapTheme === theme) return;
    this.mapTheme = theme;
    this.reset();
  }

  /**
   * Terrain height calculation with natural slope, ocean wave swells, and lateral borders
   */
  public getTerrainHeight(x: number, z: number): number {
    // Constant 14% downhill slope
    const baseSlope = -z * 0.14;

    if (this.mapTheme === 'beach') {
      // In beach mode, whole surface is rolling tropical ocean water waves & swells
      const swells = Math.sin(z * 0.065) * 0.85 + Math.cos(x * 0.11) * 0.55 + Math.sin(z * 0.14 + x * 0.07) * 0.22;
      const playHalfWidth = 22;
      let atollBank = 0;
      const absX = Math.abs(x);
      if (absX > playHalfWidth) {
        const over = absX - playHalfWidth;
        atollBank = Math.pow(over, 1.7) * 0.42;
      }
      return baseSlope + swells + atollBank;
    }

    // Snow terrain: rolling moguls
    const moguls = Math.sin(z * 0.04) * 1.2 + Math.sin(x * 0.08) * 0.8;
    const playHalfWidth = 20;
    let cliffHeight = 0;
    const absX = Math.abs(x);
    if (absX > playHalfWidth) {
      const over = absX - playHalfWidth;
      cliffHeight = Math.pow(over, 1.8) * 0.45;
    }

    return baseSlope + moguls + cliffHeight;
  }

  /**
   * Builds and attaches a mountain slope chunk
   */
  private spawnChunk(zStart: number) {
    const zEnd = zStart + this.chunkLength;
    // Optimized 26x26 segment grid gives 676 vertices instead of 1600 (57% reduction in CPU deformation for 60 FPS)
    const xSegments = 26;
    const zSegments = 26;

    const geo = new THREE.PlaneGeometry(
      this.chunkWidth,
      this.chunkLength,
      xSegments,
      zSegments
    );
    geo.rotateX(-Math.PI / 2); // align horizontally

    // Deform vertices to match getTerrainHeight
    const pos = geo.attributes.position;
    for (let i = 0; i < pos.count; i++) {
      const vx = pos.getX(i);
      const vz = pos.getZ(i) + zStart + this.chunkLength * 0.5;
      const vy = this.getTerrainHeight(vx, vz);
      pos.setY(i, vy);
      pos.setZ(i, vz);
    }
    geo.computeVertexNormals();

    const isBeach = this.mapTheme === 'beach';
    // In Beach Mode: the entire main track IS the open ocean water channel!
    const mesh = new THREE.Mesh(geo, isBeach ? this.oceanMaterial : this.snowMaterial);
    mesh.receiveShadow = true;
    mesh.castShadow = false;
    this.root.add(mesh);

    let oceanLeft: THREE.Mesh | undefined;
    let oceanRight: THREE.Mesh | undefined;

    if (isBeach) {
      // Lush tropical sandy atolls & beaches flanking the flowing ocean waterway
      const islandWidth = 75;
      const midZ = zStart + this.chunkLength * 0.5;
      const baseSeaY = -midZ * 0.14 - 0.3;

      const seaGeoL = new THREE.PlaneGeometry(islandWidth, this.chunkLength, 6, 6);
      seaGeoL.rotateX(-Math.PI / 2);
      oceanLeft = new THREE.Mesh(seaGeoL, this.sandMaterial);
      oceanLeft.position.set(-(this.chunkWidth * 0.5 + islandWidth * 0.5 - 2), baseSeaY, midZ);
      oceanLeft.receiveShadow = true;
      this.root.add(oceanLeft);

      const seaGeoR = new THREE.PlaneGeometry(islandWidth, this.chunkLength, 6, 6);
      seaGeoR.rotateX(-Math.PI / 2);
      oceanRight = new THREE.Mesh(seaGeoR, this.sandMaterial);
      oceanRight.position.set(this.chunkWidth * 0.5 + islandWidth * 0.5 - 2, baseSeaY, midZ);
      oceanRight.receiveShadow = true;
      this.root.add(oceanRight);
    }

    this.terrainChunks.push({ mesh, oceanLeft, oceanRight, zStart, zEnd });

    // Spawn features for this chunk (if not initial spawn pad behind starting line)
    if (zStart >= 0) {
      this.populateChunkFeatures(zStart, zEnd);
    }
  }

  /**
   * Spawns obstacles, gates, kickers, and powerups in a slope chunk
   * In Beach mode, everything is positioned on water or flanking island atolls
   */
  private populateChunkFeatures(zStart: number, zEnd: number) {
    const isEarly = zStart < 150;
    const isBeach = this.mapTheme === 'beach';

    // 1. Natural Snowy Pines vs Lush Island Palm Trees (Palms border the ocean channel banks)
    const treeCount = isEarly ? 10 : 16;
    for (let i = 0; i < treeCount; i++) {
      let x: number;
      if (isBeach) {
        // Place palm trees along the island banks flanking the surf waterway
        const side = Math.random() > 0.5 ? 1 : -1;
        x = side * (14 + Math.random() * 14);
      } else {
        x = (Math.random() - 0.5) * 36;
      }
      const z = zStart + 10 + Math.random() * (this.chunkLength - 20);
      const y = this.getTerrainHeight(x, z);

      const tree = isBeach ? this.buildPalmTree() : this.buildPineTree();
      tree.position.set(x, y, z);
      this.root.add(tree);

      this.obstacles.push({
        id: this.nextObstacleId++,
        type: 'tree',
        mesh: tree,
        collider: { type: 'cylinder', radius: isBeach ? 0.75 : 0.9, height: 4.5 },
        position: tree.position,
        isActive: true,
      });
    }

    // 2. Glacial Boulders vs Protruding Ocean Coral Reef Spires in the water
    const rockCount = isEarly ? 4 : 7;
    for (let i = 0; i < rockCount; i++) {
      const x = (Math.random() - 0.5) * 26;
      const z = zStart + 15 + Math.random() * (this.chunkLength - 30);
      const y = this.getTerrainHeight(x, z);

      const rock = isBeach ? this.buildBeachRock() : this.buildRock();
      rock.position.set(x, y, z);
      this.root.add(rock);

      this.obstacles.push({
        id: this.nextObstacleId++,
        type: 'rock',
        mesh: rock,
        collider: { type: 'sphere', radius: 1.1, height: 1.8 },
        position: rock.position,
        isActive: true,
      });
    }

    // 3. Snowmen vs Floating Tiki Buoys & Sandbar Castles on water
    const snowmanCount = 3;
    for (let i = 0; i < snowmanCount; i++) {
      const x = (Math.random() - 0.5) * 24;
      const z = zStart + 10 + Math.random() * (this.chunkLength - 20);
      const y = this.getTerrainHeight(x, z);

      const isTiki = Math.random() > 0.4;
      const sm = isBeach ? (isTiki ? this.buildTikiTotem() : this.buildSandcastle()) : this.buildSnowman();
      sm.position.set(x, y, z);
      this.root.add(sm);

      this.obstacles.push({
        id: this.nextObstacleId++,
        type: isBeach ? (isTiki ? 'tiki' : 'sandcastle') : 'snowman',
        mesh: sm,
        collider: { type: 'sphere', radius: 0.95, height: 1.8 },
        position: sm.position,
        isActive: true,
      });
    }

    // 4. Fallen Snow Log vs Floating Driftwood Rails on water
    const railCount = Math.random() > 0.4 ? 2 : 1;
    for (let i = 0; i < railCount; i++) {
      const x = (Math.random() - 0.5) * 18;
      const z = zStart + 25 + Math.random() * (this.chunkLength - 50);
      const y = this.getTerrainHeight(x, z) + 0.25;

      const log = isBeach ? this.buildDriftwoodRail() : this.buildLogRail();
      log.position.set(x, y, z);
      this.root.add(log);

      this.obstacles.push({
        id: this.nextObstacleId++,
        type: 'log_rail',
        mesh: log,
        collider: { type: 'box', radius: 0.5, halfWidth: 0.4, halfLength: 4.0, height: 0.8 },
        position: log.position,
        isActive: true,
      });
    }

    // 5. Slalom Checkpoint Gates (Winter Gates vs Floating Ocean Channel Marker Buoys)
    const gateCount = 2;
    for (let i = 0; i < gateCount; i++) {
      const x = (Math.random() - 0.5) * 16;
      const z = zStart + 20 + i * 50;
      const y = this.getTerrainHeight(x, z);

      const isBlue = i % 2 === 0;
      const gate = isBeach ? this.buildBeachSlalomGate(isBlue) : this.buildSlalomGate(isBlue);
      gate.position.set(x, y, z);
      this.root.add(gate);

      this.obstacles.push({
        id: this.nextObstacleId++,
        type: 'slalom_gate',
        mesh: gate,
        collider: { type: 'box', radius: 2.5, halfWidth: 2.8, halfLength: 0.4, height: 2.5 },
        position: gate.position,
        isActive: true,
        dynamic: { isPassed: false },
      });
    }

    // 6. Natural Ski Jump Ramp vs Floating Wooden Surf Kicker on water
    if (Math.random() > 0.3) {
      const rx = (Math.random() - 0.5) * 16;
      const rz = zStart + 40 + Math.random() * 40;
      const ry = this.getTerrainHeight(rx, rz);
      if (isBeach) {
        this.spawnBeachJumpRamp(rx, ry, rz);
      } else {
        this.spawnJumpRamp(rx, ry, rz);
      }
    }

    // 7. Dynamic Hazard: Falling Icicles vs Falling Heavy Coconuts
    if (!isEarly && Math.random() > 0.35) {
      const ix = (Math.random() - 0.5) * 22;
      const iz = zStart + 45;
      const iy = this.getTerrainHeight(ix, iz);

      const hazardGroup = isBeach ? this.buildFallingCoconut() : this.buildFallingIcicle();
      hazardGroup.position.set(ix, iy + 16, iz); // Suspended high above
      this.root.add(hazardGroup);

      // Warning circle on ground
      const circleGeo = new THREE.RingGeometry(0.8, 1.4, 16);
      circleGeo.rotateX(-Math.PI / 2);
      const warnCircle = new THREE.Mesh(circleGeo, this.warningMaterial);
      warnCircle.position.set(ix, iy + 0.05, iz);
      this.root.add(warnCircle);

      this.obstacles.push({
        id: this.nextObstacleId++,
        type: isBeach ? 'coconut' : 'icicle',
        mesh: hazardGroup,
        collider: { type: 'cylinder', radius: 0.75, height: 2.5 },
        position: hazardGroup.position,
        isActive: true,
        dynamic: {
          vy: 0,
          warningCircle: warnCircle,
          hasTriggered: false,
        },
      });
    }

    // 8. Dynamic Hazard: Rolling Snowball vs Rolling Coconut/Barrel
    if (!isEarly && Math.random() > 0.4) {
      const side = Math.random() > 0.5 ? 1 : -1;
      const sx = side * 18;
      const sz = zStart + 60;
      const sy = this.getTerrainHeight(sx, sz) + 1.2;

      const ballMesh = isBeach ? this.buildRollingBarrel() : this.buildRollingSnowball();
      ballMesh.position.set(sx, sy, sz);
      this.root.add(ballMesh);

      this.obstacles.push({
        id: this.nextObstacleId++,
        type: 'rolling_snowball',
        mesh: ballMesh,
        collider: { type: 'sphere', radius: 1.4, height: 2.8 },
        position: ballMesh.position,
        isActive: true,
        dynamic: {
          vx: -side * (6 + Math.random() * 4), // rolls across track
          vz: 8, // rolls downhill
          hasTriggered: false,
        },
      });
    }

    // 9. Patches of Thin Ice vs Slippery Tide Pools
    if (Math.random() > 0.45) {
      const px = (Math.random() - 0.5) * 16;
      const pz = zStart + 70;
      const py = this.getTerrainHeight(px, pz) + 0.03;

      const patchMesh = isBeach ? this.buildTidePool() : this.buildIcePatch();
      patchMesh.position.set(px, py, pz);
      this.root.add(patchMesh);

      this.obstacles.push({
        id: this.nextObstacleId++,
        type: 'thin_ice',
        mesh: patchMesh,
        collider: { type: 'box', radius: 2.5, halfWidth: 3.5, halfLength: 5.0, height: 0.5 },
        position: patchMesh.position,
        isActive: true,
      });
    }

    // 10. Collectibles: Rich Snow Coin Runs & Mountain Gems (Easy and lucrative to farm!)
    const lineCount = 4;
    for (let l = 0; l < lineCount; l++) {
      const coinRunCount = 14;
      const startX = (Math.random() - 0.5) * 18;
      const zOffset = zStart + 6 + l * 28;
      for (let c = 0; c < coinRunCount; c++) {
        const cz = zOffset + c * 2.5;
        const cx = startX + Math.sin(c * 0.45) * 3.5;
        const cy = this.getTerrainHeight(cx, cz) + 0.85;

        const isGem = Math.random() < 0.35;
        const colMesh = isGem ? this.buildGemMesh() : this.buildCoinMesh();
        colMesh.position.set(cx, cy, cz);
        this.root.add(colMesh);

        this.collectibles.push({
          id: this.nextCollectibleId++,
          type: isGem ? 'gem' : 'coin',
          mesh: colMesh,
          position: colMesh.position,
          baseY: cy,
          isCollected: false,
          radius: isGem ? 1.6 : 1.3,
        });
      }
    }

    // 11. Power-ups (Nitro, Shield, Multiplier, Magnet, Freeze - frequent spawns!)
    if (Math.random() > 0.08) {
      // Prioritize shining star and magnet for coin farming fun
      const types: PowerUpType[] = ['star', 'magnet', 'star', 'multiplier', 'nitro', 'shield', 'multiplier', 'freeze'];
      const puType = types[Math.floor(Math.random() * types.length)];
      const pux = (Math.random() - 0.5) * 16;
      const puz = zStart + 20 + Math.random() * 70;
      const puy = this.getTerrainHeight(pux, puz) + 1.2;

      const puMesh = this.buildPowerUpMesh(puType);
      puMesh.position.set(pux, puy, puz);
      this.root.add(puMesh);

      this.collectibles.push({
        id: this.nextCollectibleId++,
        type: 'powerup',
        powerUpType: puType,
        mesh: puMesh,
        position: puMesh.position,
        baseY: puy,
        isCollected: false,
        radius: 1.5,
      });
    }
  }

  // --- Procedural Geometry Builders ---

  private buildPineTree(): THREE.Group {
    const group = new THREE.Group();

    // Trunk
    const trunkGeo = new THREE.CylinderGeometry(0.2, 0.32, 1.8, 6);
    const trunk = new THREE.Mesh(trunkGeo, this.woodMaterial);
    trunk.position.y = 0.9;
    trunk.castShadow = true;
    group.add(trunk);

    // 3 Tiers of Conical Foliage with Snow Caps
    const tiers = [
      { r: 1.4, h: 1.8, y: 2.2, snowR: 1.45 },
      { r: 1.1, h: 1.6, y: 3.2, snowR: 1.15 },
      { r: 0.75, h: 1.4, y: 4.1, snowR: 0.8 },
    ];

    tiers.forEach((tier) => {
      const coneGeo = new THREE.ConeGeometry(tier.r, tier.h, 7);
      const cone = new THREE.Mesh(coneGeo, this.pineFoliageMaterial);
      cone.position.y = tier.y;
      cone.castShadow = true;
      group.add(cone);

      // Snow on branches
      const snowGeo = new THREE.ConeGeometry(tier.snowR, 0.45, 7);
      const snow = new THREE.Mesh(snowGeo, this.pineSnowMaterial);
      snow.position.y = tier.y - tier.h * 0.28;
      snow.castShadow = true;
      group.add(snow);
    });

    return group;
  }

  private buildRock(): THREE.Group {
    const group = new THREE.Group();
    const rockGeo = new THREE.DodecahedronGeometry(1.0, 1);
    const rockMesh = new THREE.Mesh(rockGeo, this.rockMaterial);
    rockMesh.scale.set(1.1, 0.85, 1.2);
    rockMesh.position.y = 0.7;
    rockMesh.castShadow = true;
    rockMesh.receiveShadow = true;
    group.add(rockMesh);

    // Snow cap on top
    const capGeo = new THREE.ConeGeometry(0.85, 0.4, 6);
    const cap = new THREE.Mesh(capGeo, this.pineSnowMaterial);
    cap.position.y = 1.35;
    group.add(cap);

    return group;
  }

  private buildSnowman(): THREE.Group {
    const group = new THREE.Group();

    // Base, Torso, Head
    const base = new THREE.Mesh(new THREE.SphereGeometry(0.55, 8, 8), this.pineSnowMaterial);
    base.position.y = 0.55;
    base.castShadow = true;
    group.add(base);

    const torso = new THREE.Mesh(new THREE.SphereGeometry(0.4, 8, 8), this.pineSnowMaterial);
    torso.position.y = 1.25;
    torso.castShadow = true;
    group.add(torso);

    const head = new THREE.Mesh(new THREE.SphereGeometry(0.28, 8, 8), this.pineSnowMaterial);
    head.position.y = 1.78;
    head.castShadow = true;
    group.add(head);

    // Carrot Nose
    const carrotGeo = new THREE.ConeGeometry(0.06, 0.25, 5);
    carrotGeo.rotateX(Math.PI / 2);
    const carrotMat = new THREE.MeshStandardMaterial({ color: 0xf97316 });
    const nose = new THREE.Mesh(carrotGeo, carrotMat);
    nose.position.set(0, 1.78, 0.32);
    group.add(nose);

    // Coal Top Hat
    const hatGeo = new THREE.CylinderGeometry(0.2, 0.2, 0.28, 8);
    const hatMat = new THREE.MeshStandardMaterial({ color: 0x18181b });
    const hat = new THREE.Mesh(hatGeo, hatMat);
    hat.position.set(0, 2.1, 0);
    group.add(hat);

    const brimGeo = new THREE.CylinderGeometry(0.32, 0.32, 0.04, 8);
    const brim = new THREE.Mesh(brimGeo, hatMat);
    brim.position.set(0, 1.98, 0);
    group.add(brim);

    return group;
  }

  private buildLogRail(): THREE.Group {
    const group = new THREE.Group();

    // Fallen tree log
    const logGeo = new THREE.CylinderGeometry(0.22, 0.24, 7.5, 7);
    logGeo.rotateX(Math.PI / 2);
    const log = new THREE.Mesh(logGeo, this.woodMaterial);
    log.position.y = 0.4;
    log.castShadow = true;
    group.add(log);

    // Snow grind cap on top
    const capGeo = new THREE.BoxGeometry(0.25, 0.08, 7.3);
    const cap = new THREE.Mesh(capGeo, this.pineSnowMaterial);
    cap.position.y = 0.62;
    group.add(cap);

    return group;
  }

  private buildSlalomGate(isBlue: boolean): THREE.Group {
    const group = new THREE.Group();
    const gateColor = isBlue ? 0x0284c7 : 0xe11d48;
    const gateMat = new THREE.MeshStandardMaterial({ color: gateColor, metalness: 0.5, roughness: 0.3 });

    // Left and Right Flexible Poles
    const poleGeo = new THREE.CylinderGeometry(0.05, 0.05, 2.4, 6);
    const pL = new THREE.Mesh(poleGeo, gateMat);
    pL.position.set(-2.0, 1.2, 0);
    pL.castShadow = true;
    group.add(pL);

    const pR = new THREE.Mesh(poleGeo, gateMat);
    pR.position.set(2.0, 1.2, 0);
    pR.castShadow = true;
    group.add(pR);

    // Cloth Flag Banner
    const bannerGeo = new THREE.PlaneGeometry(3.9, 0.6);
    const bannerMat = new THREE.MeshStandardMaterial({
      color: gateColor,
      side: THREE.DoubleSide,
      roughness: 0.7,
    });
    const banner = new THREE.Mesh(bannerGeo, bannerMat);
    banner.position.set(0, 1.8, 0);
    group.add(banner);

    return group;
  }

  private spawnJumpRamp(x: number, y: number, z: number) {
    const width = 6.0;
    const length = 7.0;
    const height = 1.6;

    // Wedge ramp
    const shape = new THREE.Shape();
    shape.moveTo(-length / 2, 0);
    shape.lineTo(length / 2, height);
    shape.lineTo(length / 2, 0);
    shape.closePath();

    const extrudeSettings = { depth: width, bevelEnabled: false };
    const rampGeo = new THREE.ExtrudeGeometry(shape, extrudeSettings);
    rampGeo.rotateY(Math.PI / 2);
    rampGeo.translate(-width / 2, 0, 0);

    const rampMesh = new THREE.Mesh(rampGeo, this.pineSnowMaterial);
    rampMesh.position.set(x, y, z);
    rampMesh.castShadow = true;
    rampMesh.receiveShadow = true;
    this.root.add(rampMesh);

    this.ramps.push({ position: rampMesh.position, width, length, height, mesh: rampMesh });

    // Aerial arc of coins launched off ramp
    for (let i = 0; i < 5; i++) {
      const acz = z + length * 0.5 + i * 5.0;
      const acx = x;
      const acy = this.getTerrainHeight(acx, acz) + height + 2.2 + Math.sin((i / 4) * Math.PI) * 2.8;
      const isGem = i === 2; // Diamond Gem at the apex
      const mesh = isGem ? this.buildGemMesh() : this.buildCoinMesh();
      mesh.position.set(acx, acy, acz);
      this.root.add(mesh);
      this.collectibles.push({
        id: this.nextCollectibleId++,
        type: isGem ? 'gem' : 'coin',
        mesh,
        position: mesh.position,
        baseY: acy,
        isCollected: false,
        radius: 1.6,
      });
    }
  }

  private buildFallingIcicle(): THREE.Group {
    const group = new THREE.Group();
    const icicleGeo = new THREE.ConeGeometry(0.35, 2.4, 6);
    icicleGeo.rotateX(Math.PI); // tip points down
    const icicleMat = new THREE.MeshStandardMaterial({
      color: 0xe0f2fe,
      opacity: 0.85,
      transparent: true,
      roughness: 0.1,
      metalness: 0.3,
    });
    const mesh = new THREE.Mesh(icicleGeo, icicleMat);
    mesh.castShadow = true;
    group.add(mesh);
    return group;
  }

  private buildRollingSnowball(): THREE.Group {
    const group = new THREE.Group();
    const ballGeo = new THREE.DodecahedronGeometry(1.3, 1);
    const ballMesh = new THREE.Mesh(ballGeo, this.pineSnowMaterial);
    ballMesh.castShadow = true;
    group.add(ballMesh);
    return group;
  }

  private buildIcePatch(): THREE.Group {
    const group = new THREE.Group();
    const patchGeo = new THREE.PlaneGeometry(6.5, 9.0);
    patchGeo.rotateX(-Math.PI / 2);
    const patch = new THREE.Mesh(patchGeo, this.icePatchMaterial);
    patch.receiveShadow = true;
    group.add(patch);
    return group;
  }

  private buildCoinMesh(): THREE.Group {
    const group = new THREE.Group();
    const coinGeo = new THREE.CylinderGeometry(0.35, 0.35, 0.08, 8);
    coinGeo.rotateX(Math.PI / 2);
    const coin = new THREE.Mesh(coinGeo, this.coinMaterial);
    coin.castShadow = true;
    group.add(coin);
    return group;
  }

  private buildGemMesh(): THREE.Group {
    const group = new THREE.Group();
    const gemGeo = new THREE.OctahedronGeometry(0.4, 0);
    const gem = new THREE.Mesh(gemGeo, this.gemMaterial);
    gem.castShadow = true;
    group.add(gem);
    return group;
  }

  private buildPowerUpMesh(type: PowerUpType): THREE.Group {
    const group = new THREE.Group();
    const mat = this.powerUpMaterials[type];

    if (type === 'star') {
      // 3D 5-pointed extruded star with glowing halo
      const starShape = new THREE.Shape();
      const points = 5;
      const outerR = 0.58;
      const innerR = 0.25;
      for (let i = 0; i < points * 2; i++) {
        const r = i % 2 === 0 ? outerR : innerR;
        const a = (i * Math.PI) / points - Math.PI / 2;
        const x = Math.cos(a) * r;
        const y = Math.sin(a) * r;
        if (i === 0) starShape.moveTo(x, y);
        else starShape.lineTo(x, y);
      }
      starShape.closePath();

      const starGeo = new THREE.ExtrudeGeometry(starShape, {
        depth: 0.18,
        bevelEnabled: true,
        bevelThickness: 0.06,
        bevelSize: 0.04,
        bevelSegments: 2,
      });
      starGeo.center();

      const starMesh = new THREE.Mesh(starGeo, mat);
      starMesh.castShadow = true;
      group.add(starMesh);

      // Glowing golden starlight core
      const coreLight = new THREE.Mesh(
        new THREE.OctahedronGeometry(0.2, 0),
        new THREE.MeshBasicMaterial({ color: 0xffffff })
      );
      group.add(coreLight);

      // Dual rotating starlight rings
      const ringGeo = new THREE.TorusGeometry(0.72, 0.035, 6, 24);
      const ringMat = new THREE.MeshBasicMaterial({ color: 0xfef08a });
      const ring1 = new THREE.Mesh(ringGeo, ringMat);
      ring1.rotation.x = Math.PI / 3;
      group.add(ring1);

      const ring2 = new THREE.Mesh(ringGeo, ringMat);
      ring2.rotation.y = Math.PI / 3;
      group.add(ring2);

      return group;
    }

    // Floating crystal icon
    const coreGeo = new THREE.IcosahedronGeometry(0.45, 0);
    const core = new THREE.Mesh(coreGeo, mat);
    core.castShadow = true;
    group.add(core);

    // Surrounding orbit ring
    const ringGeo = new THREE.TorusGeometry(0.65, 0.04, 6, 16);
    const ringMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
    const ring = new THREE.Mesh(ringGeo, ringMat);
    group.add(ring);
    return group;
  }

  // --- Beach Procedural Builders ---

  private buildPalmTree(): THREE.Group {
    const group = new THREE.Group();

    // Curved tropical trunk in 3 stacked segments
    const seg1 = new THREE.Mesh(new THREE.CylinderGeometry(0.24, 0.32, 1.6, 7), this.palmBarkMaterial);
    seg1.position.y = 0.8;
    seg1.rotation.z = 0.05;
    seg1.castShadow = true;
    group.add(seg1);

    const seg2 = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.24, 1.5, 7), this.palmBarkMaterial);
    seg2.position.set(0.08, 2.2, 0);
    seg2.rotation.z = 0.12;
    seg2.castShadow = true;
    group.add(seg2);

    const seg3 = new THREE.Mesh(new THREE.CylinderGeometry(0.16, 0.2, 1.4, 7), this.palmBarkMaterial);
    seg3.position.set(0.22, 3.5, 0);
    seg3.rotation.z = 0.18;
    seg3.castShadow = true;
    group.add(seg3);

    // Crown of cascading green palm fronds
    const crown = new THREE.Group();
    crown.position.set(0.32, 4.2, 0);

    const frondCount = 8;
    for (let i = 0; i < frondCount; i++) {
      const angle = (i * Math.PI * 2) / frondCount;
      const frondGeo = new THREE.ConeGeometry(0.65, 2.6, 5);
      frondGeo.rotateX(Math.PI / 2.3);
      const frond = new THREE.Mesh(frondGeo, this.palmFrondMaterial);
      frond.rotation.y = angle;
      frond.rotation.z = 0.45;
      frond.castShadow = true;
      crown.add(frond);
    }

    // Clustered coconuts
    for (let c = 0; c < 4; c++) {
      const ca = (c * Math.PI * 2) / 4 + 0.3;
      const nut = new THREE.Mesh(new THREE.SphereGeometry(0.16, 6, 6), this.coconutMaterial);
      nut.position.set(Math.cos(ca) * 0.25, -0.15, Math.sin(ca) * 0.25);
      crown.add(nut);
    }

    group.add(crown);
    return group;
  }

  private buildBeachRock(): THREE.Group {
    const group = new THREE.Group();
    const rockGeo = new THREE.DodecahedronGeometry(1.05, 1);
    const rockMesh = new THREE.Mesh(rockGeo, this.beachRockMaterial);
    rockMesh.scale.set(1.2, 0.8, 1.3);
    rockMesh.position.y = 0.65;
    rockMesh.castShadow = true;
    rockMesh.receiveShadow = true;
    group.add(rockMesh);
    return group;
  }

  private buildSandcastle(): THREE.Group {
    const group = new THREE.Group();
    // Central keep
    const base = new THREE.Mesh(new THREE.BoxGeometry(1.2, 0.7, 1.2), this.sandcastleMaterial);
    base.position.y = 0.35;
    base.castShadow = true;
    group.add(base);

    // 4 Corner Turrets
    const turretGeo = new THREE.CylinderGeometry(0.18, 0.22, 1.1, 8);
    const coneGeo = new THREE.ConeGeometry(0.22, 0.45, 8);
    const offsets = [
      [-0.5, -0.5],
      [0.5, -0.5],
      [-0.5, 0.5],
      [0.5, 0.5],
    ];
    offsets.forEach(([ox, oz]) => {
      const turret = new THREE.Mesh(turretGeo, this.sandcastleMaterial);
      turret.position.set(ox, 0.55, oz);
      turret.castShadow = true;
      group.add(turret);

      const roof = new THREE.Mesh(coneGeo, this.sandcastleMaterial);
      roof.position.set(ox, 1.25, oz);
      group.add(roof);
    });

    // Beach flag on top
    const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.02, 0.7, 4), this.woodMaterial);
    pole.position.set(0, 1.05, 0);
    group.add(pole);

    const flag = new THREE.Mesh(new THREE.PlaneGeometry(0.3, 0.18), new THREE.MeshStandardMaterial({ color: 0xef4444, side: THREE.DoubleSide }));
    flag.position.set(0.15, 1.3, 0);
    group.add(flag);

    return group;
  }

  private buildTikiTotem(): THREE.Group {
    const group = new THREE.Group();

    // Buoyant bamboo / driftwood float raft
    const raftGeo = new THREE.BoxGeometry(1.6, 0.25, 1.6);
    const raft = new THREE.Mesh(raftGeo, this.woodMaterial);
    raft.position.y = 0.12;
    raft.castShadow = true;
    group.add(raft);

    // Tiki idol pole
    const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.35, 0.4, 2.0, 8), this.tikiWoodMaterial);
    pole.position.y = 1.15;
    pole.castShadow = true;
    group.add(pole);

    // Carved facial brow and teeth
    const brow = new THREE.Mesh(new THREE.BoxGeometry(0.7, 0.16, 0.3), this.tikiWoodMaterial);
    brow.position.set(0, 1.7, 0.25);
    group.add(brow);

    const teeth = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.14, 0.28), new THREE.MeshStandardMaterial({ color: 0xfef08a }));
    teeth.position.set(0, 1.3, 0.25);
    group.add(teeth);

    // Glowing tiki torch flame atop
    const flameGeo = new THREE.ConeGeometry(0.18, 0.5, 6);
    const flameMat = new THREE.MeshStandardMaterial({ color: 0xf97316, emissive: 0xf97316, emissiveIntensity: 0.9 });
    const flame = new THREE.Mesh(flameGeo, flameMat);
    flame.position.set(0, 2.35, 0);
    group.add(flame);

    return group;
  }

  private buildDriftwoodRail(): THREE.Group {
    const group = new THREE.Group();
    // Floating timber boom log floating on the water
    const logGeo = new THREE.CylinderGeometry(0.24, 0.26, 7.5, 7);
    logGeo.rotateX(Math.PI / 2);
    const log = new THREE.Mesh(logGeo, this.woodMaterial);
    log.position.y = 0.25;
    log.castShadow = true;
    group.add(log);

    // Water foam collar around floating log
    const foamGeo = new THREE.PlaneGeometry(0.7, 7.5);
    foamGeo.rotateX(-Math.PI / 2);
    const foamMat = new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.55 });
    const foam = new THREE.Mesh(foamGeo, foamMat);
    foam.position.y = 0.05;
    group.add(foam);

    return group;
  }

  private buildBeachSlalomGate(isBlue: boolean): THREE.Group {
    const group = new THREE.Group();
    const buoyColor = isBlue ? 0x0284c7 : 0xef4444; // Channel navigation port/starboard colors
    const buoyMat = new THREE.MeshStandardMaterial({ color: buoyColor, metalness: 0.5, roughness: 0.25 });
    const whiteMat = new THREE.MeshStandardMaterial({ color: 0xf8fafc, roughness: 0.4 });

    const buildBuoy = (offsetX: number) => {
      const bGroup = new THREE.Group();
      bGroup.position.set(offsetX, 0, 0);

      // Marine floating buoy drum
      const floatGeo = new THREE.CylinderGeometry(0.5, 0.4, 0.8, 10);
      const floatMesh = new THREE.Mesh(floatGeo, buoyMat);
      floatMesh.position.y = 0.4;
      floatMesh.castShadow = true;
      bGroup.add(floatMesh);

      // White reflective center band
      const bandGeo = new THREE.CylinderGeometry(0.51, 0.51, 0.22, 10);
      const bandMesh = new THREE.Mesh(bandGeo, whiteMat);
      bandMesh.position.y = 0.4;
      bGroup.add(bandMesh);

      // Flexible marker antenna mast
      const mastGeo = new THREE.CylinderGeometry(0.04, 0.04, 2.2, 6);
      const mastMesh = new THREE.Mesh(mastGeo, whiteMat);
      mastMesh.position.y = 1.5;
      bGroup.add(mastMesh);

      // Top flashing LED beacon light
      const beaconGeo = new THREE.SphereGeometry(0.12, 6, 6);
      const beaconMat = new THREE.MeshBasicMaterial({ color: isBlue ? 0x38bdf8 : 0xfca5a5 });
      const beacon = new THREE.Mesh(beaconGeo, beaconMat);
      beacon.position.y = 2.6;
      bGroup.add(beacon);

      // Water splash foam ring around the buoy base
      const ringGeo = new THREE.RingGeometry(0.5, 0.85, 12);
      ringGeo.rotateX(-Math.PI / 2);
      const splash = new THREE.Mesh(ringGeo, new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.6 }));
      splash.position.y = 0.05;
      bGroup.add(splash);

      return bGroup;
    };

    const bL = buildBuoy(-2.2);
    const bR = buildBuoy(2.2);
    group.add(bL);
    group.add(bR);

    // Floating nautical pennant flag between buoys
    const flagGeo = new THREE.PlaneGeometry(4.0, 0.45);
    const flagMat = new THREE.MeshStandardMaterial({ color: buoyColor, side: THREE.DoubleSide, metalness: 0.3 });
    const flagMesh = new THREE.Mesh(flagGeo, flagMat);
    flagMesh.position.set(0, 1.9, 0);
    group.add(flagMesh);

    return group;
  }

  private buildFallingCoconut(): THREE.Group {
    const group = new THREE.Group();
    const nut = new THREE.Mesh(new THREE.SphereGeometry(0.42, 8, 8), this.coconutMaterial);
    nut.castShadow = true;
    group.add(nut);
    return group;
  }

  private buildRollingBarrel(): THREE.Group {
    const group = new THREE.Group();
    // Floating cargo barrel bobbing down the water rapids
    const barrelGeo = new THREE.CylinderGeometry(0.85, 0.85, 1.6, 10);
    barrelGeo.rotateZ(Math.PI / 2);
    const barrel = new THREE.Mesh(barrelGeo, this.woodMaterial);
    barrel.castShadow = true;
    group.add(barrel);

    // Metal hoop rings
    const hoopGeo = new THREE.TorusGeometry(0.86, 0.04, 4, 12);
    hoopGeo.rotateY(Math.PI / 2);
    const hoopMat = new THREE.MeshStandardMaterial({ color: 0x475569, metalness: 0.8 });
    const h1 = new THREE.Mesh(hoopGeo, hoopMat);
    h1.position.x = -0.5;
    barrel.add(h1);
    const h2 = new THREE.Mesh(hoopGeo, hoopMat);
    h2.position.x = 0.5;
    barrel.add(h2);

    return group;
  }

  private buildTidePool(): THREE.Group {
    const group = new THREE.Group();
    const geo = new THREE.PlaneGeometry(7.0, 10.0, 6, 6);
    geo.rotateX(-Math.PI / 2);
    const mesh = new THREE.Mesh(geo, this.tidePoolMaterial);
    mesh.receiveShadow = true;
    group.add(mesh);
    return group;
  }

  private spawnBeachJumpRamp(x: number, y: number, z: number) {
    const width = 6.0;
    const length = 7.0;
    const height = 1.6;

    // Floating wooden surf kicker on water
    const shape = new THREE.Shape();
    shape.moveTo(-length / 2, 0);
    shape.lineTo(length / 2, height);
    shape.lineTo(length / 2, 0);
    shape.closePath();

    const extrudeSettings = { depth: width, bevelEnabled: false };
    const rampGeo = new THREE.ExtrudeGeometry(shape, extrudeSettings);
    rampGeo.rotateY(Math.PI / 2);
    rampGeo.translate(-width / 2, 0, 0);

    const rampMesh = new THREE.Mesh(rampGeo, this.woodMaterial);
    rampMesh.position.set(x, y, z);
    rampMesh.castShadow = true;
    rampMesh.receiveShadow = true;
    this.root.add(rampMesh);

    // Dual yellow maritime float pontoons supporting the floating kicker
    const floatMat = new THREE.MeshStandardMaterial({ color: 0xfacc15, roughness: 0.3, metalness: 0.2 });
    const floatGeo = new THREE.CylinderGeometry(0.55, 0.55, length * 0.9, 8);
    floatGeo.rotateX(Math.PI / 2);

    const fLeft = new THREE.Mesh(floatGeo, floatMat);
    fLeft.position.set(-width * 0.4, -0.2, 0);
    rampMesh.add(fLeft);

    const fRight = new THREE.Mesh(floatGeo, floatMat);
    fRight.position.set(width * 0.4, -0.2, 0);
    rampMesh.add(fRight);

    this.ramps.push({ position: rampMesh.position, width, length, height, mesh: rampMesh });

    for (let i = 0; i < 5; i++) {
      const acz = z + length * 0.5 + i * 5.0;
      const acx = x;
      const acy = this.getTerrainHeight(acx, acz) + height + 2.2 + Math.sin((i / 4) * Math.PI) * 2.8;
      const isGem = i === 2;
      const mesh = isGem ? this.buildGemMesh() : this.buildCoinMesh();
      mesh.position.set(acx, acy, acz);
      this.root.add(mesh);
      this.collectibles.push({
        id: this.nextCollectibleId++,
        type: isGem ? 'gem' : 'coin',
        mesh,
        position: mesh.position,
        baseY: acy,
        isCollected: false,
        radius: isGem ? 1.6 : 1.3,
      });
    }
  }

  /**
   * Updates dynamic hazards, spins collectibles, and recycles distant chunks behind player
   */
  public update(dt: number, playerZ: number, isFrozen: boolean) {
    const simDt = isFrozen ? dt * 0.4 : dt;

    // 1. Recycle terrain chunks
    const recycleThreshold = playerZ - 80;
    for (let i = this.terrainChunks.length - 1; i >= 0; i--) {
      const chunk = this.terrainChunks[i];
      if (chunk.zEnd < recycleThreshold) {
        this.root.remove(chunk.mesh);
        chunk.mesh.geometry.dispose();
        if (chunk.oceanLeft) {
          this.root.remove(chunk.oceanLeft);
          chunk.oceanLeft.geometry.dispose();
        }
        if (chunk.oceanRight) {
          this.root.remove(chunk.oceanRight);
          chunk.oceanRight.geometry.dispose();
        }
        this.terrainChunks.splice(i, 1);

        // Spawn new chunk ahead
        const lastChunk = this.terrainChunks[this.terrainChunks.length - 1];
        const nextZ = lastChunk ? lastChunk.zEnd : playerZ;
        this.spawnChunk(nextZ);
      }
    }

    // 2. Clean up behind obstacles & collectibles
    this.obstacles = this.obstacles.filter((obs) => {
      if (obs.position.z < recycleThreshold) {
        this.root.remove(obs.mesh);
        if (obs.dynamic?.warningCircle) {
          this.root.remove(obs.dynamic.warningCircle);
        }
        return false;
      }
      return true;
    });

    this.collectibles = this.collectibles.filter((col) => {
      if (col.position.z < recycleThreshold) {
        this.root.remove(col.mesh);
        return false;
      }
      return true;
    });

    // 3. Update Dynamic Hazards
    this.obstacles.forEach((obs) => {
      if (!obs.isActive) return;

      if ((obs.type === 'icicle' || obs.type === 'coconut') && obs.dynamic) {
        const distZ = obs.position.z - playerZ;
        // Trigger fall when player approaches within 45 meters
        if (distZ < 45 && !obs.dynamic.hasTriggered) {
          obs.dynamic.hasTriggered = true;
        }
        if (obs.dynamic.hasTriggered) {
          obs.dynamic.vy = (obs.dynamic.vy || 0) - 24 * simDt;
          obs.position.y += obs.dynamic.vy * simDt;

          const groundY = this.getTerrainHeight(obs.position.x, obs.position.z);
          if (obs.position.y <= groundY) {
            obs.position.y = groundY;
            obs.isActive = false;
            obs.mesh.visible = false;
            if (obs.dynamic.warningCircle) {
              obs.dynamic.warningCircle.visible = false;
            }
          }
        }
      } else if (obs.type === 'rolling_snowball' && obs.dynamic) {
        const distZ = obs.position.z - playerZ;
        if (distZ < 70) {
          obs.position.x += (obs.dynamic.vx || 0) * simDt;
          obs.position.z += (obs.dynamic.vz || 0) * simDt;
          obs.position.y = this.getTerrainHeight(obs.position.x, obs.position.z) + 1.2;
          obs.mesh.rotation.x += 4 * simDt;
          obs.mesh.rotation.z += 3 * simDt;
        }
      }
    });

    // 4. Spin Collectibles (Optimized: only animate items within active camera range)
    const now = performance.now() * 0.003;
    const colCount = this.collectibles.length;
    for (let i = 0; i < colCount; i++) {
      const col = this.collectibles[i];
      if (!col.isCollected && Math.abs(col.position.z - playerZ) < 80) {
        col.mesh.rotation.y += 3.0 * dt;
        col.position.y = col.baseY + Math.sin(now + col.id) * 0.18;
      }
    }
  }

  public reset() {
    // Clear all objects and reset to origin
    this.obstacles.forEach((o) => {
      this.root.remove(o.mesh);
      if (o.dynamic?.warningCircle) this.root.remove(o.dynamic.warningCircle);
    });
    this.obstacles = [];

    this.collectibles.forEach((c) => this.root.remove(c.mesh));
    this.collectibles = [];

    this.ramps.forEach((r) => this.root.remove(r.mesh));
    this.ramps = [];

    this.terrainChunks.forEach((c) => {
      this.root.remove(c.mesh);
      c.mesh.geometry.dispose();
      if (c.oceanLeft) {
        this.root.remove(c.oceanLeft);
        c.oceanLeft.geometry.dispose();
      }
      if (c.oceanRight) {
        this.root.remove(c.oceanRight);
        c.oceanRight.geometry.dispose();
      }
    });
    this.terrainChunks = [];

    for (let i = -1; i < this.activeChunkCount - 1; i++) {
      this.spawnChunk(i * this.chunkLength);
    }
  }

  public dispose() {
    this.reset();
    this.snowMaterial.dispose();
    this.icePatchMaterial.dispose();
    this.woodMaterial.dispose();
    this.pineFoliageMaterial.dispose();
    this.pineSnowMaterial.dispose();
    this.rockMaterial.dispose();
    this.coinMaterial.dispose();
    this.gemMaterial.dispose();
    this.warningMaterial.dispose();
    this.sandMaterial.dispose();
    this.oceanMaterial.dispose();
    this.palmBarkMaterial.dispose();
    this.palmFrondMaterial.dispose();
    this.coconutMaterial.dispose();
    this.beachRockMaterial.dispose();
    this.sandcastleMaterial.dispose();
    this.tikiWoodMaterial.dispose();
    this.tidePoolMaterial.dispose();
    Object.values(this.powerUpMaterials).forEach((m) => m.dispose());
  }
}
