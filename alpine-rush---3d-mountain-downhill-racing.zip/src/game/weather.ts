import * as THREE from 'three';
import { MapTheme } from '../types/game';

export type WeatherType = 'clear_day' | 'sunset_glow' | 'heavy_blizzard' | 'aurora_night';

export interface WeatherConfig {
  type: WeatherType;
  name: string;
  icon: string;
  skyColor: number;
  fogColor: number;
  fogDensity: number;
  sunColor: number;
  sunIntensity: number;
  hemiSkyColor: number;
  hemiGroundColor: number;
  hemiIntensity: number;
  sunPosition: THREE.Vector3;
  snowDensity: number; // 0 to 1
  windSpeed: number;    // lateral wind push
  frostVignette: number;// 0 to 1 for HUD
  auroraOpacity: number;
  starsOpacity: number;
}

export const WEATHER_CONFIGS: Record<WeatherType, WeatherConfig> = {
  clear_day: {
    type: 'clear_day',
    name: 'Clear Alpine Peak',
    icon: '☀️',
    skyColor: 0x7ec8f8,
    fogColor: 0xa5dbfb,
    fogDensity: 0.0055,
    sunColor: 0xfffbeb,
    sunIntensity: 2.1,
    hemiSkyColor: 0xe0f2fe,
    hemiGroundColor: 0x1e293b,
    hemiIntensity: 1.25,
    sunPosition: new THREE.Vector3(30, 50, 25),
    snowDensity: 0.25,
    windSpeed: 0.0,
    frostVignette: 0.0,
    auroraOpacity: 0.0,
    starsOpacity: 0.0,
  },
  sunset_glow: {
    type: 'sunset_glow',
    name: 'Sunset Glacier Ridge',
    icon: '🌅',
    skyColor: 0xb91c1c, // Crimson amber
    fogColor: 0xd97706, // Golden fog
    fogDensity: 0.007,
    sunColor: 0xfdba74, // Warm gold
    sunIntensity: 2.3,
    hemiSkyColor: 0xf43f5e,
    hemiGroundColor: 0x312e81,
    hemiIntensity: 1.05,
    sunPosition: new THREE.Vector3(50, 18, 40), // Low grazing sun
    snowDensity: 0.35,
    windSpeed: 1.5,
    frostVignette: 0.0,
    auroraOpacity: 0.0,
    starsOpacity: 0.1,
  },
  heavy_blizzard: {
    type: 'heavy_blizzard',
    name: 'Arctic Blizzard Gale',
    icon: '❄️',
    skyColor: 0x334155,
    fogColor: 0x64748b,
    fogDensity: 0.016, // Low visibility whiteout
    sunColor: 0x94a3b8,
    sunIntensity: 0.8,
    hemiSkyColor: 0x94a3b8,
    hemiGroundColor: 0x0f172a,
    hemiIntensity: 0.85,
    sunPosition: new THREE.Vector3(15, 30, 15),
    snowDensity: 1.0,
    windSpeed: 5.5,
    frostVignette: 0.85,
    auroraOpacity: 0.0,
    starsOpacity: 0.0,
  },
  aurora_night: {
    type: 'aurora_night',
    name: 'Aurora Borealis Night',
    icon: '🌌',
    skyColor: 0x050816,
    fogColor: 0x0b1329,
    fogDensity: 0.0075,
    sunColor: 0x7dd3fc, // Cool moonlight
    sunIntensity: 1.15,
    hemiSkyColor: 0x059669, // Emerald aurora glow
    hemiGroundColor: 0x020617,
    hemiIntensity: 0.75,
    sunPosition: new THREE.Vector3(-25, 45, -20),
    snowDensity: 0.35,
    windSpeed: 0.8,
    frostVignette: 0.15,
    auroraOpacity: 0.9,
    starsOpacity: 1.0,
  },
};

export const BEACH_WEATHER_CONFIGS: Record<WeatherType, WeatherConfig> = {
  clear_day: {
    type: 'clear_day',
    name: 'Tropical Coastal Sun',
    icon: '☀️',
    skyColor: 0x38bdf8, // Caribbean bright cyan
    fogColor: 0xbae6fd, // Soft warm ocean mist
    fogDensity: 0.004,
    sunColor: 0xffedd5, // Radiant tropical sunshine
    sunIntensity: 2.7,
    hemiSkyColor: 0x7dd3fc,
    hemiGroundColor: 0xca8a04,
    hemiIntensity: 1.35,
    sunPosition: new THREE.Vector3(35, 55, 30),
    snowDensity: 0.0,
    windSpeed: 0.0,
    frostVignette: 0.0,
    auroraOpacity: 0.0,
    starsOpacity: 0.0,
  },
  sunset_glow: {
    type: 'sunset_glow',
    name: 'Coral Reef Sunset',
    icon: '🌅',
    skyColor: 0xe11d48, // Vibrant coral pink
    fogColor: 0xf97316, // Golden amber glow
    fogDensity: 0.0055,
    sunColor: 0xfde047, // Golden sun orb
    sunIntensity: 2.9,
    hemiSkyColor: 0xf43f5e,
    hemiGroundColor: 0x431407,
    hemiIntensity: 1.15,
    sunPosition: new THREE.Vector3(55, 16, 45),
    snowDensity: 0.0,
    windSpeed: 1.0,
    frostVignette: 0.0,
    auroraOpacity: 0.0,
    starsOpacity: 0.15,
  },
  heavy_blizzard: {
    type: 'heavy_blizzard',
    name: 'Monsoon Wind Squall',
    icon: '🌧️',
    skyColor: 0x334155, // Storm front
    fogColor: 0x64748b,
    fogDensity: 0.012,
    sunColor: 0xcbd5e1,
    sunIntensity: 1.1,
    hemiSkyColor: 0x64748b,
    hemiGroundColor: 0x0f172a,
    hemiIntensity: 0.9,
    sunPosition: new THREE.Vector3(20, 35, 20),
    snowDensity: 0.0, // warm rain motes
    windSpeed: 4.8,
    frostVignette: 0.2, // sea spray on lens
    auroraOpacity: 0.0,
    starsOpacity: 0.0,
  },
  aurora_night: {
    type: 'aurora_night',
    name: 'Bioluminescent Lagoon',
    icon: '✨',
    skyColor: 0x030712,
    fogColor: 0x0b1329,
    fogDensity: 0.0055,
    sunColor: 0xa5f3fc,
    sunIntensity: 1.25,
    hemiSkyColor: 0x059669, // Glowing turquoise bioluminescence
    hemiGroundColor: 0x022c22,
    hemiIntensity: 0.85,
    sunPosition: new THREE.Vector3(-25, 45, -20),
    snowDensity: 0.0,
    windSpeed: 0.6,
    frostVignette: 0.0,
    auroraOpacity: 0.75,
    starsOpacity: 1.0,
  },
};

export class WeatherSystem {
  public root: THREE.Group;
  public currentWeather: WeatherType = 'clear_day';
  public targetWeather: WeatherType = 'clear_day';
  public transitionProgress: number = 1.0; // 0 to 1
  public mapTheme: MapTheme = 'snow';

  // Scene references
  private scene: THREE.Scene;
  private sunLight: THREE.DirectionalLight;
  private hemiLight: THREE.HemisphereLight;
  private fog: THREE.FogExp2;

  // Sky & Mountain Vista Assets
  private backdropGroup: THREE.Group;
  private celestialMesh: THREE.Mesh;
  private celestialMat: THREE.MeshBasicMaterial;
  private starsPoints: THREE.Points;
  private starsMat: THREE.PointsMaterial;
  private auroraMesh: THREE.Mesh;
  private auroraMat: THREE.MeshBasicMaterial;

  // Current interpolated values
  public currentConfig: WeatherConfig;
  private weatherSequence: WeatherType[] = ['clear_day', 'sunset_glow', 'heavy_blizzard', 'aurora_night'];
  private weatherSequenceIdx = 0;
  private cycleTimer = 0;
  private cycleDuration = 35; // changes weather every 35s or ~1200m

  public getConfigs(): Record<WeatherType, WeatherConfig> {
    return this.mapTheme === 'beach' ? BEACH_WEATHER_CONFIGS : WEATHER_CONFIGS;
  }

  public setTheme(theme: MapTheme) {
    this.mapTheme = theme;
    this.transitionProgress = 0;
    this.currentConfig = this.getConfigs()[this.currentWeather];
  }

  constructor(
    scene: THREE.Scene,
    sunLight: THREE.DirectionalLight,
    hemiLight: THREE.HemisphereLight,
    fog: THREE.FogExp2
  ) {
    this.scene = scene;
    this.sunLight = sunLight;
    this.hemiLight = hemiLight;
    this.fog = fog;
    this.currentConfig = { ...WEATHER_CONFIGS.clear_day };

    this.root = new THREE.Group();
    this.root.name = 'weather_system';

    // 1. Distant Mountain Backdrop Ring
    this.backdropGroup = new THREE.Group();
    this.buildMountainVista();
    this.root.add(this.backdropGroup);

    // 2. Celestial Body (Sun / Moon)
    const sunGeo = new THREE.SphereGeometry(14, 16, 16);
    this.celestialMat = new THREE.MeshBasicMaterial({ color: 0xfffbeb, fog: false });
    this.celestialMesh = new THREE.Mesh(sunGeo, this.celestialMat);
    this.celestialMesh.position.set(120, 160, 280);
    this.backdropGroup.add(this.celestialMesh);

    // 3. Cosmic Stars Dome
    const starCount = 700;
    const starGeo = new THREE.BufferGeometry();
    const starPos = new Float32Array(starCount * 3);
    for (let i = 0; i < starCount; i++) {
      const u = Math.random();
      const v = Math.random();
      const theta = u * 2.0 * Math.PI;
      const phi = Math.acos(2.0 * v - 1.0);
      const r = 380 + Math.random() * 40;
      starPos[i * 3] = r * Math.sin(phi) * Math.cos(theta);
      starPos[i * 3 + 1] = Math.abs(r * Math.cos(phi)) + 30; // hemisphere above
      starPos[i * 3 + 2] = r * Math.sin(phi) * Math.sin(theta);
    }
    starGeo.setAttribute('position', new THREE.BufferAttribute(starPos, 3));
    this.starsMat = new THREE.PointsMaterial({
      color: 0xffffff,
      size: 1.8,
      transparent: true,
      opacity: 0.0,
      fog: false,
    });
    this.starsPoints = new THREE.Points(starGeo, this.starsMat);
    this.backdropGroup.add(this.starsPoints);

    // 4. Shimmering Aurora Borealis Curtain Ribbon
    const auroraGeo = new THREE.CylinderGeometry(280, 290, 80, 48, 8, true, -Math.PI / 2, Math.PI);
    const auroraTex = this.createAuroraTexture();
    this.auroraMat = new THREE.MeshBasicMaterial({
      map: auroraTex,
      transparent: true,
      opacity: 0.0,
      side: THREE.DoubleSide,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
      fog: false,
    });
    this.auroraMesh = new THREE.Mesh(auroraGeo, this.auroraMat);
    this.auroraMesh.position.set(0, 100, 100);
    this.backdropGroup.add(this.auroraMesh);

    // 5. Sun Corona & Volumetric Atmospheric God Rays
    const coronaGeo = new THREE.PlaneGeometry(55, 55);
    const coronaTex = this.createCoronaTexture();
    this.coronaMat = new THREE.MeshBasicMaterial({
      map: coronaTex,
      transparent: true,
      opacity: 0.65,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
      fog: false,
    });
    this.coronaMesh = new THREE.Mesh(coronaGeo, this.coronaMat);
    this.coronaMesh.position.copy(this.celestialMesh.position);
    this.backdropGroup.add(this.coronaMesh);

    this.godRays = [];
    for (let r = 0; r < 5; r++) {
      const rayGeo = new THREE.PlaneGeometry(45, 240);
      const rayMat = new THREE.MeshBasicMaterial({
        color: 0xffedd5,
        transparent: true,
        opacity: 0.12,
        side: THREE.DoubleSide,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
        fog: false,
      });
      const ray = new THREE.Mesh(rayGeo, rayMat);
      ray.position.set(120 + (r - 2) * 22, 70, 250);
      ray.rotation.z = -0.35 + (r - 2) * 0.08;
      this.godRays.push(ray);
      this.backdropGroup.add(ray);
    }

    // 6. Alpine Valley Low-Mist Clouds
    const mistTex = this.createMistTexture();
    this.mistMat = new THREE.MeshBasicMaterial({
      map: mistTex,
      transparent: true,
      opacity: 0.35,
      side: THREE.DoubleSide,
      depthWrite: false,
    });
    this.mistLayers = [];
    for (let m = 0; m < 8; m++) {
      const mistGeo = new THREE.PlaneGeometry(160, 60);
      mistGeo.rotateX(-Math.PI / 2);
      const mist = new THREE.Mesh(mistGeo, this.mistMat);
      const angle = (m / 8) * Math.PI * 2;
      mist.position.set(Math.cos(angle) * 190, 12 + (m % 3) * 8, Math.sin(angle) * 190);
      this.mistLayers.push(mist);
      this.backdropGroup.add(mist);
    }

    this.scene.add(this.root);
  }

  private coronaMesh: THREE.Mesh;
  private coronaMat: THREE.MeshBasicMaterial;
  private godRays: THREE.Mesh[];
  private mistMat: THREE.MeshBasicMaterial;
  private mistLayers: THREE.Mesh[];

  private createCoronaTexture(): THREE.CanvasTexture {
    const canvas = document.createElement('canvas');
    canvas.width = 256;
    canvas.height = 256;
    const ctx = canvas.getContext('2d')!;

    const grad = ctx.createRadialGradient(128, 128, 0, 128, 128, 128);
    grad.addColorStop(0, 'rgba(255, 255, 255, 1)');
    grad.addColorStop(0.2, 'rgba(254, 240, 138, 0.7)');
    grad.addColorStop(0.5, 'rgba(251, 146, 60, 0.25)');
    grad.addColorStop(1, 'rgba(255, 255, 255, 0)');

    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, 256, 256);

    const tex = new THREE.CanvasTexture(canvas);
    return tex;
  }

  private createMistTexture(): THREE.CanvasTexture {
    const canvas = document.createElement('canvas');
    canvas.width = 512;
    canvas.height = 256;
    const ctx = canvas.getContext('2d')!;

    const grad = ctx.createRadialGradient(256, 128, 0, 256, 128, 256);
    grad.addColorStop(0, 'rgba(241, 245, 249, 0.7)');
    grad.addColorStop(0.5, 'rgba(226, 232, 240, 0.35)');
    grad.addColorStop(0.8, 'rgba(203, 213, 225, 0.1)');
    grad.addColorStop(1, 'rgba(255, 255, 255, 0)');

    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, 512, 256);

    const tex = new THREE.CanvasTexture(canvas);
    return tex;
  }

  private createAuroraTexture(): THREE.CanvasTexture {
    const canvas = document.createElement('canvas');
    canvas.width = 512;
    canvas.height = 256;
    const ctx = canvas.getContext('2d')!;

    const grad = ctx.createLinearGradient(0, 256, 0, 0);
    grad.addColorStop(0, 'rgba(0, 0, 0, 0)');
    grad.addColorStop(0.3, 'rgba(16, 185, 129, 0.7)'); // Emerald
    grad.addColorStop(0.7, 'rgba(6, 182, 212, 0.85)'); // Cyan
    grad.addColorStop(1, 'rgba(139, 92, 246, 0.0)'); // Violet fade

    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, 512, 256);

    // Vertical curtain drapes
    ctx.fillStyle = 'rgba(255, 255, 255, 0.15)';
    for (let x = 0; x < 512; x += 16) {
      ctx.fillRect(x, 40, 8, 180);
    }

    const tex = new THREE.CanvasTexture(canvas);
    tex.wrapS = THREE.RepeatWrapping;
    tex.wrapT = THREE.ClampToEdgeWrapping;
    return tex;
  }

  /**
   * Generates a 360-degree perimeter ring of distant mountain ranges
   */
  private buildMountainVista() {
    const peakCount = 24;
    const radius = 320;
    const vistaMat = new THREE.MeshStandardMaterial({
      color: 0x475569,
      roughness: 0.9,
      metalness: 0.1,
      flatShading: true,
    });
    const snowCapMat = new THREE.MeshStandardMaterial({
      color: 0xf1f5f9,
      roughness: 0.95,
      metalness: 0.05,
      flatShading: true,
    });

    for (let i = 0; i < peakCount; i++) {
      const angle = (i / peakCount) * Math.PI * 2;
      const x = Math.cos(angle) * radius;
      const z = Math.sin(angle) * radius;
      const peakHeight = 85 + Math.random() * 70;
      const peakBase = 50 + Math.random() * 30;

      // Mountain Cone
      const mtnGeo = new THREE.ConeGeometry(peakBase, peakHeight, 6);
      const mtn = new THREE.Mesh(mtnGeo, vistaMat);
      mtn.position.set(x, peakHeight * 0.45 - 20, z);
      this.backdropGroup.add(mtn);

      // Snow Cap
      const capGeo = new THREE.ConeGeometry(peakBase * 0.5, peakHeight * 0.35, 6);
      const cap = new THREE.Mesh(capGeo, snowCapMat);
      cap.position.set(x, peakHeight * 0.72 - 20, z);
      this.backdropGroup.add(cap);
    }
  }

  public setWeather(type: WeatherType) {
    if (this.currentWeather === type && this.targetWeather === type) return;
    this.targetWeather = type;
    this.transitionProgress = 0;
  }

  public nextWeather() {
    this.weatherSequenceIdx = (this.weatherSequenceIdx + 1) % this.weatherSequence.length;
    this.setWeather(this.weatherSequence[this.weatherSequenceIdx]);
  }

  public update(dt: number, playerPos: THREE.Vector3) {
    // 1. Weather cycle timer
    this.cycleTimer += dt;
    if (this.cycleTimer >= this.cycleDuration) {
      this.cycleTimer = 0;
      this.nextWeather();
    }

    // 2. Interpolate weather transition
    if (this.transitionProgress < 1.0) {
      this.transitionProgress = Math.min(1.0, this.transitionProgress + dt * 0.35); // ~3s transition
      if (this.transitionProgress >= 1.0) {
        this.currentWeather = this.targetWeather;
      }
    }

    const configs = this.getConfigs();
    const fromCfg = configs[this.currentWeather];
    const toCfg = configs[this.targetWeather];
    const t = this.transitionProgress;

    // Lerp colors & intensities
    const cSky = new THREE.Color(fromCfg.skyColor).lerp(new THREE.Color(toCfg.skyColor), t);
    const cFog = new THREE.Color(fromCfg.fogColor).lerp(new THREE.Color(toCfg.fogColor), t);
    const cSun = new THREE.Color(fromCfg.sunColor).lerp(new THREE.Color(toCfg.sunColor), t);
    const cHemiSky = new THREE.Color(fromCfg.hemiSkyColor).lerp(new THREE.Color(toCfg.hemiSkyColor), t);
    const cHemiGnd = new THREE.Color(fromCfg.hemiGroundColor).lerp(new THREE.Color(toCfg.hemiGroundColor), t);

    const sunInt = THREE.MathUtils.lerp(fromCfg.sunIntensity, toCfg.sunIntensity, t);
    const hemiInt = THREE.MathUtils.lerp(fromCfg.hemiIntensity, toCfg.hemiIntensity, t);
    const fogDens = THREE.MathUtils.lerp(fromCfg.fogDensity, toCfg.fogDensity, t);
    const wind = THREE.MathUtils.lerp(fromCfg.windSpeed, toCfg.windSpeed, t);
    const frost = THREE.MathUtils.lerp(fromCfg.frostVignette, toCfg.frostVignette, t);
    const aurora = THREE.MathUtils.lerp(fromCfg.auroraOpacity, toCfg.auroraOpacity, t);
    const stars = THREE.MathUtils.lerp(fromCfg.starsOpacity, toCfg.starsOpacity, t);

    // Apply to scene
    this.scene.background = cSky;
    this.fog.color = cFog;
    this.fog.density = fogDens;

    this.sunLight.color = cSun;
    this.sunLight.intensity = sunInt;
    this.hemiLight.color = cHemiSky;
    this.hemiLight.groundColor = cHemiGnd;
    this.hemiLight.intensity = hemiInt;

    // Apply to sky elements
    this.celestialMat.color = cSun;
    this.starsMat.opacity = stars;
    this.auroraMat.opacity = aurora;

    // Atmospheric God Rays & Corona Opacity
    const now = performance.now() * 0.0006;
    const isSunnyOrSunset = this.targetWeather === 'clear_day' || this.targetWeather === 'sunset_glow';
    const godRayTargetOpacity = isSunnyOrSunset ? (this.targetWeather === 'sunset_glow' ? 0.22 : 0.14) * (1.0 - t * 0.2) : 0.0;
    this.godRays.forEach((ray, i) => {
      const mat = ray.material as THREE.MeshBasicMaterial;
      mat.opacity = THREE.MathUtils.lerp(mat.opacity, godRayTargetOpacity, 0.05);
      ray.rotation.z += Math.sin(now * 2 + i) * 0.0003;
    });

    this.coronaMat.opacity = isSunnyOrSunset ? 0.75 : 0.15;
    this.coronaMat.color = cSun;

    // Animate aurora waves
    if (aurora > 0.01) {
      this.auroraMesh.rotation.y = now * 0.2;
      this.auroraMesh.position.y = 90 + Math.sin(now * 3) * 12;
    }

    // Drifting Valley Mist
    this.mistLayers.forEach((m, idx) => {
      m.rotation.z += 0.0004 * (idx % 2 === 0 ? 1 : -1);
      m.position.x += wind * 0.1 * dt;
    });

    // Keep backdrop ring centered on player Z & Y so horizon never runs out
    this.backdropGroup.position.set(0, playerPos.y * 0.7, playerPos.z);

    // Store interpolated config for gameEngine & HUD
    this.currentConfig.type = this.targetWeather;
    this.currentConfig.name = toCfg.name;
    this.currentConfig.icon = toCfg.icon;
    this.currentConfig.windSpeed = wind;
    this.currentConfig.frostVignette = frost;
    this.currentConfig.snowDensity = THREE.MathUtils.lerp(fromCfg.snowDensity, toCfg.snowDensity, t);
  }

  public dispose() {
    this.backdropGroup.clear();
    this.starsMat.dispose();
    this.celestialMat.dispose();
    this.auroraMat.dispose();
    this.coronaMat.dispose();
    this.mistMat.dispose();
  }
}
