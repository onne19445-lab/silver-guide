import * as THREE from 'three';
import { CharacterDef, CharacterCustomization, MapTheme } from '../types/game';
import { 
  createJacketTexture, 
  createBoardTexture, 
  createBeachShirtTexture, 
  createSurfboardTexture 
} from './textures';

export interface CharacterRig {
  root: THREE.Group;
  bodyGroup: THREE.Group;
  headGroup: THREE.Group;
  torsoMesh: THREE.Mesh;
  jacketMaterial: THREE.MeshStandardMaterial;
  pantsMaterial: THREE.MeshStandardMaterial;
  helmetMaterial: THREE.MeshStandardMaterial;
  visorMaterial: THREE.MeshStandardMaterial;
  boardMaterial: THREE.MeshStandardMaterial;
  accentMaterial: THREE.MeshStandardMaterial;
  leftLeg: THREE.Group;
  rightLeg: THREE.Group;
  leftArm: THREE.Group;
  rightArm: THREE.Group;
  leftSki?: THREE.Group;
  rightSki?: THREE.Group;
  snowboard?: THREE.Group;
  surfboard?: THREE.Group;
  leftPole?: THREE.Group;
  rightPole?: THREE.Group;
  scarfMesh: THREE.Mesh;
  shieldMesh: THREE.Mesh;
  nitroThrusters: THREE.Mesh[];
  def: CharacterDef;
  customization: CharacterCustomization;
  mapTheme: MapTheme;
  setMapTheme: (theme: MapTheme) => void;
  updateCustomization: (custom: CharacterCustomization) => void;
  animate: (
    time: number,
    speedKmh: number,
    carveAngle: number,
    isAirborne: boolean,
    trickRotation: { pitch: number; yaw: number; roll: number },
    isTucking: boolean,
    hasShield: boolean,
    isBoosting: boolean
  ) => void;
  dispose: () => void;
}

/**
 * Builds a composite 10-14 part procedural character model in Three.js
 * Supports dynamic gear swapping between Alpine Snow and Ocean Water Surfing.
 */
export function createCharacterMesh(
  def: CharacterDef,
  customization: CharacterCustomization,
  initialTheme: MapTheme = 'snow'
): CharacterRig {
  let currentTheme: MapTheme = initialTheme;
  const root = new THREE.Group();
  root.name = `character_${def.id}`;

  // Shared textures & materials
  let jacketTex = currentTheme === 'beach'
    ? createBeachShirtTexture(customization.jacketColor, customization.accentColor)
    : createJacketTexture(customization.jacketColor, customization.jacketPattern, customization.accentColor);

  let boardTex = currentTheme === 'beach'
    ? createSurfboardTexture(customization.boardColor, customization.accentColor)
    : createBoardTexture(customization.boardColor, customization.accentColor, def.vehicleType);

  const jacketMaterial = new THREE.MeshStandardMaterial({
    map: jacketTex,
    roughness: 0.75,
    metalness: 0.1,
  });

  const pantsMaterial = new THREE.MeshStandardMaterial({
    color: customization.pantsColor,
    roughness: 0.85,
    metalness: 0.05,
  });

  const helmetMaterial = new THREE.MeshStandardMaterial({
    color: customization.helmetColor,
    roughness: 0.35,
    metalness: 0.45,
  });

  // Fast PBR sunglasses & visor (no slow transmission pass)
  const visorMaterial = new THREE.MeshStandardMaterial({
    color: currentTheme === 'beach' ? 0x111827 : customization.visorColor,
    roughness: 0.1,
    metalness: 0.9,
  });

  const boardMaterial = new THREE.MeshStandardMaterial({
    map: boardTex,
    roughness: 0.25,
    metalness: 0.3,
  });

  const accentMaterial = new THREE.MeshStandardMaterial({
    color: customization.accentColor,
    roughness: 0.4,
    metalness: 0.2,
  });

  const bootMaterial = new THREE.MeshStandardMaterial({
    color: 0x18181b,
    roughness: 0.4,
    metalness: 0.6,
  });

  const poleMaterial = new THREE.MeshStandardMaterial({
    color: 0x94a3b8,
    roughness: 0.2,
    metalness: 0.85,
  });

  const skinTone = def.id === 'yeti_rider' ? 0xe2e8f0 : 0xf5d0b5;
  const skinFurMaterial = new THREE.MeshStandardMaterial({
    color: skinTone,
    roughness: 0.85,
    metalness: 0.0,
  });

  const sandalMaterial = new THREE.MeshStandardMaterial({
    color: 0x78350f, // Tropical beach sandals / flip-flops
    roughness: 0.7,
    metalness: 0.1,
  });

  // Base Body Hierarchy
  const bodyGroup = new THREE.Group();
  bodyGroup.position.set(0, 0.45, 0);
  root.add(bodyGroup);

  // 1. Torso (Jacket in Snow, Hawaiian Floral Shirt in Beach)
  const isYeti = def.id === 'yeti_rider';
  const torsoGeo = new THREE.CylinderGeometry(
    isYeti ? 0.38 : 0.24,
    isYeti ? 0.32 : 0.19,
    isYeti ? 0.8 : 0.55,
    8
  );
  const torsoMesh = new THREE.Mesh(torsoGeo, jacketMaterial);
  torsoMesh.position.y = isYeti ? 0.4 : 0.28;
  torsoMesh.castShadow = true;
  torsoMesh.receiveShadow = true;
  bodyGroup.add(torsoMesh);

  // Backpack / Jetpack
  const backpackGeo = new THREE.BoxGeometry(0.24, 0.32, 0.14);
  const backpackMesh = new THREE.Mesh(backpackGeo, accentMaterial);
  backpackMesh.position.set(0, torsoMesh.position.y, -0.15);
  backpackMesh.castShadow = true;
  bodyGroup.add(backpackMesh);

  const nitroThrusters: THREE.Mesh[] = [];
  if (def.id === 'vortex_valkyrie') {
    const thrusterGeo = new THREE.ConeGeometry(0.06, 0.16, 8);
    thrusterGeo.rotateX(Math.PI / 2);
    const thrusterMat = new THREE.MeshStandardMaterial({ color: 0x334155, metalness: 0.9, roughness: 0.2 });
    
    const tL = new THREE.Mesh(thrusterGeo, thrusterMat);
    tL.position.set(-0.09, torsoMesh.position.y - 0.05, -0.22);
    backpackMesh.add(tL);
    nitroThrusters.push(tL);

    const tR = new THREE.Mesh(thrusterGeo, thrusterMat);
    tR.position.set(0.09, torsoMesh.position.y - 0.05, -0.22);
    backpackMesh.add(tR);
    nitroThrusters.push(tR);
  }

  // 2. Head, Helmet / Sun Visor, Visor / Shades, & Scarf
  const headGroup = new THREE.Group();
  headGroup.position.set(0, torsoMesh.position.y + (isYeti ? 0.45 : 0.35), 0);
  bodyGroup.add(headGroup);

  // Head sphere
  const headGeo = new THREE.SphereGeometry(isYeti ? 0.26 : 0.18, 12, 10);
  const headMesh = new THREE.Mesh(headGeo, currentTheme === 'beach' ? skinFurMaterial : helmetMaterial);
  headMesh.castShadow = true;
  headGroup.add(headMesh);

  // Sun Visor Cap for beach mode
  const visorCapGeo = new THREE.CylinderGeometry(0.2, 0.22, 0.06, 10);
  const visorCapMesh = new THREE.Mesh(visorCapGeo, accentMaterial);
  visorCapMesh.position.set(0, 0.12, 0);
  visorCapMesh.visible = currentTheme === 'beach';
  headGroup.add(visorCapMesh);

  const visorPeakGeo = new THREE.BoxGeometry(0.24, 0.02, 0.16);
  const visorPeakMesh = new THREE.Mesh(visorPeakGeo, accentMaterial);
  visorPeakMesh.position.set(0, 0.1, 0.14);
  visorPeakMesh.rotation.x = -0.15;
  visorCapMesh.add(visorPeakMesh);

  if (isYeti) {
    const hornGeo = new THREE.ConeGeometry(0.06, 0.22, 6);
    const hornL = new THREE.Mesh(hornGeo, accentMaterial);
    hornL.position.set(-0.16, 0.18, 0);
    hornL.rotation.z = 0.5;
    headGroup.add(hornL);

    const hornR = new THREE.Mesh(hornGeo, accentMaterial);
    hornR.position.set(0.16, 0.18, 0);
    hornR.rotation.z = -0.5;
    headGroup.add(hornR);
  }

  // Reflective Goggles / Sunglasses
  const visorGeo = new THREE.BoxGeometry(isYeti ? 0.28 : 0.22, 0.08, 0.1);
  const visorMesh = new THREE.Mesh(visorGeo, visorMaterial);
  visorMesh.position.set(0, 0.02, 0.14);
  headGroup.add(visorMesh);

  // Scarf (Neck warmer - visible in snow only)
  const scarfGeo = new THREE.TorusGeometry(isYeti ? 0.28 : 0.18, 0.06, 6, 12);
  scarfGeo.rotateX(Math.PI / 2);
  const scarfMesh = new THREE.Mesh(scarfGeo, accentMaterial);
  scarfMesh.position.set(0, -0.14, 0);
  scarfMesh.visible = currentTheme !== 'beach';
  headGroup.add(scarfMesh);

  // 3. Legs & Footwear (Board Shorts & Bare Feet / Sandals in beach mode)
  const legUpperGeo = new THREE.CylinderGeometry(0.07, 0.065, 0.22, 8);
  const legLowerGeo = new THREE.CylinderGeometry(0.06, 0.05, 0.22, 8);
  const bootGeo = new THREE.BoxGeometry(0.12, 0.12, 0.22);
  const sandalGeo = new THREE.BoxGeometry(0.11, 0.04, 0.22);

  // Left Leg
  const leftLeg = new THREE.Group();
  leftLeg.position.set(-0.14, -0.05, 0);

  const leftUpperLeg = new THREE.Mesh(legUpperGeo, pantsMaterial);
  leftUpperLeg.position.y = -0.11;
  leftUpperLeg.castShadow = true;
  leftLeg.add(leftUpperLeg);

  const leftLowerLeg = new THREE.Mesh(
    legLowerGeo, 
    currentTheme === 'beach' ? skinFurMaterial : pantsMaterial
  );
  leftLowerLeg.position.y = -0.31;
  leftLowerLeg.castShadow = true;
  leftLeg.add(leftLowerLeg);

  // Winter boot
  const leftBoot = new THREE.Mesh(bootGeo, bootMaterial);
  leftBoot.position.set(0, -0.42, 0.04);
  leftBoot.castShadow = true;
  leftBoot.visible = currentTheme !== 'beach';
  leftLeg.add(leftBoot);

  // Beach sandal / bare foot
  const leftSandal = new THREE.Mesh(sandalGeo, sandalMaterial);
  leftSandal.position.set(0, -0.42, 0.04);
  leftSandal.castShadow = true;
  leftSandal.visible = currentTheme === 'beach';
  leftLeg.add(leftSandal);

  bodyGroup.add(leftLeg);

  // Right Leg
  const rightLeg = new THREE.Group();
  rightLeg.position.set(0.14, -0.05, 0);

  const rightUpperLeg = new THREE.Mesh(legUpperGeo, pantsMaterial);
  rightUpperLeg.position.y = -0.11;
  rightUpperLeg.castShadow = true;
  rightLeg.add(rightUpperLeg);

  const rightLowerLeg = new THREE.Mesh(
    legLowerGeo, 
    currentTheme === 'beach' ? skinFurMaterial : pantsMaterial
  );
  rightLowerLeg.position.y = -0.31;
  rightLowerLeg.castShadow = true;
  rightLeg.add(rightLowerLeg);

  const rightBoot = new THREE.Mesh(bootGeo, bootMaterial);
  rightBoot.position.set(0, -0.42, 0.04);
  rightBoot.castShadow = true;
  rightBoot.visible = currentTheme !== 'beach';
  rightLeg.add(rightBoot);

  const rightSandal = new THREE.Mesh(sandalGeo, sandalMaterial);
  rightSandal.position.set(0, -0.42, 0.04);
  rightSandal.castShadow = true;
  rightSandal.visible = currentTheme === 'beach';
  rightLeg.add(rightSandal);

  // Ankle surf leash on right leg
  const leashGeo = new THREE.TorusGeometry(0.065, 0.015, 6, 12);
  leashGeo.rotateX(Math.PI / 2);
  const leashMesh = new THREE.Mesh(leashGeo, accentMaterial);
  leashMesh.position.set(0, -0.38, 0);
  leashMesh.visible = currentTheme === 'beach';
  rightLeg.add(leashMesh);

  bodyGroup.add(rightLeg);

  // 4. Arms & Hands (Short Sleeves & Bare Skin in Beach Mode)
  const armUpperGeo = new THREE.CylinderGeometry(0.058, 0.052, 0.2, 8);
  const armLowerGeo = new THREE.CylinderGeometry(0.05, 0.044, 0.2, 8);
  const handGeo = new THREE.SphereGeometry(0.055, 8, 8);

  // Left Arm
  const leftArm = new THREE.Group();
  leftArm.position.set(isYeti ? -0.38 : -0.26, torsoMesh.position.y + 0.18, 0);

  const leftUpperArm = new THREE.Mesh(armUpperGeo, jacketMaterial);
  leftUpperArm.position.y = -0.1;
  leftArm.add(leftUpperArm);

  const leftLowerArm = new THREE.Mesh(
    armLowerGeo, 
    currentTheme === 'beach' ? skinFurMaterial : jacketMaterial
  );
  leftLowerArm.position.y = -0.28;
  leftArm.add(leftLowerArm);

  const leftGlove = new THREE.Mesh(
    handGeo, 
    currentTheme === 'beach' ? skinFurMaterial : bootMaterial
  );
  leftGlove.position.y = -0.4;
  leftArm.add(leftGlove);
  bodyGroup.add(leftArm);

  // Right Arm
  const rightArm = new THREE.Group();
  rightArm.position.set(isYeti ? 0.38 : 0.26, torsoMesh.position.y + 0.18, 0);

  const rightUpperArm = new THREE.Mesh(armUpperGeo, jacketMaterial);
  rightUpperArm.position.y = -0.1;
  rightArm.add(rightUpperArm);

  const rightLowerArm = new THREE.Mesh(
    armLowerGeo, 
    currentTheme === 'beach' ? skinFurMaterial : jacketMaterial
  );
  rightLowerArm.position.y = -0.28;
  rightArm.add(rightLowerArm);

  const rightGlove = new THREE.Mesh(
    handGeo, 
    currentTheme === 'beach' ? skinFurMaterial : bootMaterial
  );
  rightGlove.position.y = -0.4;
  rightArm.add(rightGlove);
  bodyGroup.add(rightArm);

  // 5. Equipment: Skis, Snowboard & SURFBOARD
  let leftSki: THREE.Group | undefined;
  let rightSki: THREE.Group | undefined;
  let snowboard: THREE.Group | undefined;
  let leftPole: THREE.Group | undefined;
  let rightPole: THREE.Group | undefined;
  let surfboard: THREE.Group | undefined;

  // Build Snow Skis
  if (def.vehicleType === 'skis') {
    const buildSki = (offsetX: number) => {
      const skiGroup = new THREE.Group();
      skiGroup.position.set(offsetX, 0.03, 0);

      const skiGeo = new THREE.BoxGeometry(0.12, 0.03, 1.6);
      const skiMesh = new THREE.Mesh(skiGeo, boardMaterial);
      skiMesh.castShadow = true;
      skiMesh.receiveShadow = true;
      skiGroup.add(skiMesh);

      const tipGeo = new THREE.BoxGeometry(0.12, 0.03, 0.3);
      tipGeo.rotateX(-0.4);
      const tipMesh = new THREE.Mesh(tipGeo, boardMaterial);
      tipMesh.position.set(0, 0.06, 0.88);
      tipMesh.castShadow = true;
      skiGroup.add(tipMesh);

      const bindGeo = new THREE.BoxGeometry(0.14, 0.05, 0.24);
      const bindMesh = new THREE.Mesh(bindGeo, bootMaterial);
      bindMesh.position.set(0, 0.04, 0.02);
      skiGroup.add(bindMesh);

      skiGroup.visible = currentTheme !== 'beach';
      root.add(skiGroup);
      return skiGroup;
    };

    leftSki = buildSki(-0.16);
    rightSki = buildSki(0.16);

    const buildPole = () => {
      const poleGroup = new THREE.Group();
      const shaftGeo = new THREE.CylinderGeometry(0.012, 0.012, 0.9, 6);
      const shaft = new THREE.Mesh(shaftGeo, poleMaterial);
      shaft.position.y = -0.45;
      poleGroup.add(shaft);

      const ringGeo = new THREE.TorusGeometry(0.05, 0.01, 4, 8);
      ringGeo.rotateX(Math.PI / 2);
      const ring = new THREE.Mesh(ringGeo, accentMaterial);
      ring.position.y = -0.8;
      poleGroup.add(ring);

      poleGroup.visible = currentTheme !== 'beach';
      return poleGroup;
    };

    leftPole = buildPole();
    leftGlove.add(leftPole);
    leftPole.rotation.x = 0.4;

    rightPole = buildPole();
    rightGlove.add(rightPole);
    rightPole.rotation.x = 0.4;
  } else {
    // Build Snowboard
    snowboard = new THREE.Group();
    snowboard.position.set(0, 0.03, 0);

    const isSlab = def.vehicleType === 'yeti_stride';
    const boardWidth = isSlab ? 0.48 : 0.34;
    const boardLength = isSlab ? 1.9 : 1.65;

    const deckGeo = new THREE.BoxGeometry(boardWidth, 0.035, boardLength);
    const deckMesh = new THREE.Mesh(deckGeo, boardMaterial);
    deckMesh.castShadow = true;
    deckMesh.receiveShadow = true;
    snowboard.add(deckMesh);

    const noseGeo = new THREE.BoxGeometry(boardWidth * 0.95, 0.03, 0.24);
    noseGeo.rotateX(-0.35);
    const noseMesh = new THREE.Mesh(noseGeo, boardMaterial);
    noseMesh.position.set(0, 0.04, boardLength * 0.5 + 0.08);
    noseMesh.castShadow = true;
    snowboard.add(noseMesh);

    const tailGeo = new THREE.BoxGeometry(boardWidth * 0.95, 0.03, 0.24);
    tailGeo.rotateX(0.35);
    const tailMesh = new THREE.Mesh(tailGeo, boardMaterial);
    tailMesh.position.set(0, 0.04, -boardLength * 0.5 - 0.08);
    tailMesh.castShadow = true;
    snowboard.add(tailMesh);

    const bindGeo = new THREE.BoxGeometry(0.14, 0.05, 0.25);
    const bFront = new THREE.Mesh(bindGeo, bootMaterial);
    bFront.position.set(0, 0.04, 0.35);
    bFront.rotation.y = 0.35;
    snowboard.add(bFront);

    const bRear = new THREE.Mesh(bindGeo, bootMaterial);
    bRear.position.set(0, 0.04, -0.35);
    bRear.rotation.y = -0.2;
    snowboard.add(bRear);

    snowboard.visible = currentTheme !== 'beach';
    root.add(snowboard);
  }

  // Build Procedural SURFBOARD (Always equipped in Beach Mode!)
  surfboard = new THREE.Group();
  surfboard.position.set(0, 0.03, 0);

  // Hydrodynamic surfboard deck with tapered rails
  const surfDeckGeo = new THREE.BoxGeometry(0.38, 0.035, 1.85);
  const surfDeck = new THREE.Mesh(surfDeckGeo, boardMaterial);
  surfDeck.castShadow = true;
  surfDeck.receiveShadow = true;
  surfboard.add(surfDeck);

  // Surfboard rocker nose kicker
  const surfNoseGeo = new THREE.ConeGeometry(0.24, 0.45, 6);
  surfNoseGeo.rotateX(-Math.PI / 2);
  const surfNose = new THREE.Mesh(surfNoseGeo, boardMaterial);
  surfNose.scale.set(0.8, 0.15, 1.0);
  surfNose.position.set(0, 0.04, 1.85 * 0.5 + 0.12);
  surfNose.castShadow = true;
  surfboard.add(surfNose);

  // Swallowtail cut
  const surfTailGeo = new THREE.BoxGeometry(0.32, 0.03, 0.22);
  surfTailGeo.rotateX(0.25);
  const surfTail = new THREE.Mesh(surfTailGeo, boardMaterial);
  surfTail.position.set(0, 0.04, -1.85 * 0.5 - 0.08);
  surfTail.castShadow = true;
  surfboard.add(surfTail);

  // Triple thruster fins underneath
  const finGeo = new THREE.ConeGeometry(0.04, 0.14, 4);
  finGeo.rotateX(Math.PI / 2);
  const finMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, roughness: 0.3 });
  const centerFin = new THREE.Mesh(finGeo, finMat);
  centerFin.position.set(0, -0.07, -0.65);
  surfboard.add(centerFin);
  const leftFin = new THREE.Mesh(finGeo, finMat);
  leftFin.position.set(-0.12, -0.06, -0.55);
  surfboard.add(leftFin);
  const rightFin = new THREE.Mesh(finGeo, finMat);
  rightFin.position.set(0.12, -0.06, -0.55);
  surfboard.add(rightFin);

  // Surfboard tail grip stomp pad
  const stompGeo = new THREE.BoxGeometry(0.28, 0.015, 0.4);
  const stompMat = new THREE.MeshStandardMaterial({ color: 0x0f172a, roughness: 0.9 });
  const stompPad = new THREE.Mesh(stompGeo, stompMat);
  stompPad.position.set(0, 0.025, -0.5);
  surfboard.add(stompPad);

  surfboard.visible = currentTheme === 'beach';
  root.add(surfboard);

  // Set initial stance
  if (currentTheme === 'beach') {
    bodyGroup.rotation.y = Math.PI / 3.2; // Surfer side stance
    headGroup.rotation.y = -Math.PI / 3.4;
  } else if (def.vehicleType !== 'skis') {
    bodyGroup.rotation.y = Math.PI / 3.8;
    headGroup.rotation.y = -Math.PI / 4.2;
  }

  // 6. Shield Dome (Zero-lag PBR, no transmission pass)
  const shieldGeo = new THREE.IcosahedronGeometry(0.85, 2);
  const shieldMat = new THREE.MeshStandardMaterial({
    color: 0x38bdf8,
    opacity: 0.75,
    transparent: true,
    roughness: 0.1,
    metalness: 0.2,
    wireframe: true,
  });
  const shieldMesh = new THREE.Mesh(shieldGeo, shieldMat);
  shieldMesh.position.set(0, 0.6, 0);
  shieldMesh.visible = false;
  root.add(shieldMesh);

  // Texture & Outfit updater
  const applyTextures = (custom: CharacterCustomization) => {
    jacketTex.dispose();
    boardTex.dispose();

    if (currentTheme === 'beach') {
      jacketTex = createBeachShirtTexture(custom.jacketColor, custom.accentColor);
      boardTex = createSurfboardTexture(custom.boardColor, custom.accentColor);
      helmetMaterial.color.set('#fde047');
      visorMaterial.color.set('#111827'); // Polarized dark UV beach shades
      accentMaterial.color.set(custom.accentColor);
    } else {
      jacketTex = createJacketTexture(custom.jacketColor, custom.jacketPattern, custom.accentColor);
      boardTex = createBoardTexture(custom.boardColor, custom.accentColor, def.vehicleType);
      helmetMaterial.color.set(custom.helmetColor);
      visorMaterial.color.set(custom.visorColor);
      accentMaterial.color.set(custom.accentColor);
    }

    jacketMaterial.map = jacketTex;
    jacketMaterial.needsUpdate = true;

    boardMaterial.map = boardTex;
    boardMaterial.needsUpdate = true;

    pantsMaterial.color.set(custom.pantsColor);
  };

  const updateGearForTheme = (theme: MapTheme) => {
    currentTheme = theme;
    const isBeach = theme === 'beach';

    // Vehicles
    if (surfboard) surfboard.visible = isBeach;
    if (leftSki) leftSki.visible = !isBeach;
    if (rightSki) rightSki.visible = !isBeach;
    if (leftPole) leftPole.visible = !isBeach;
    if (rightPole) rightPole.visible = !isBeach;
    if (snowboard && def.vehicleType !== 'skis') snowboard.visible = !isBeach;

    // Headwear & Accessories
    scarfMesh.visible = !isBeach;
    visorCapMesh.visible = isBeach;
    headMesh.material = isBeach ? skinFurMaterial : helmetMaterial;

    // Limbs: Beach mode shows bare arms & legs with board shorts & sandals
    leftLowerArm.material = isBeach ? skinFurMaterial : jacketMaterial;
    rightLowerArm.material = isBeach ? skinFurMaterial : jacketMaterial;
    leftGlove.material = isBeach ? skinFurMaterial : bootMaterial;
    rightGlove.material = isBeach ? skinFurMaterial : bootMaterial;

    leftLowerLeg.material = isBeach ? skinFurMaterial : pantsMaterial;
    rightLowerLeg.material = isBeach ? skinFurMaterial : pantsMaterial;

    leftBoot.visible = !isBeach;
    rightBoot.visible = !isBeach;
    leftSandal.visible = isBeach;
    rightSandal.visible = isBeach;
    leashMesh.visible = isBeach;

    applyTextures(customization);
  };

  const updateCustomization = (newCustom: CharacterCustomization) => {
    customization = newCustom;
    applyTextures(newCustom);
  };

  const setMapTheme = (theme: MapTheme) => {
    updateGearForTheme(theme);
  };

  // Kinematic procedural animation
  const animate = (
    time: number,
    speedKmh: number,
    carveAngle: number,
    isAirborne: boolean,
    trickRotation: { pitch: number; yaw: number; roll: number },
    isTucking: boolean,
    hasShield: boolean,
    isBoosting: boolean
  ) => {
    // Shield animation
    shieldMesh.visible = hasShield;
    if (hasShield) {
      shieldMesh.rotation.y += 0.03;
      shieldMesh.rotation.x = Math.sin(time * 3) * 0.15;
    }

    const isBeach = currentTheme === 'beach';

    if (isAirborne) {
      // In air: wave aerial or jump trick
      bodyGroup.rotation.x = trickRotation.pitch;
      bodyGroup.rotation.y = trickRotation.yaw + (isBeach ? Math.PI / 3.2 : (def.vehicleType === 'skis' ? 0 : Math.PI / 3.8));
      bodyGroup.rotation.z = trickRotation.roll;

      leftLeg.position.y = 0.08;
      rightLeg.position.y = 0.08;
      leftArm.rotation.z = -0.7;
      rightArm.rotation.z = 0.7;
      leftArm.rotation.x = -0.5;
      rightArm.rotation.x = -0.5;

      if (surfboard && isBeach) {
        surfboard.rotation.x = trickRotation.pitch;
        surfboard.rotation.y = trickRotation.yaw;
        surfboard.rotation.z = trickRotation.roll;
        surfboard.position.y = 0.14;
      } else if (snowboard) {
        snowboard.rotation.x = trickRotation.pitch;
        snowboard.rotation.y = trickRotation.yaw;
        snowboard.rotation.z = trickRotation.roll;
        snowboard.position.y = 0.12;
      }
      if (leftSki && rightSki && !isBeach) {
        leftSki.rotation.x = trickRotation.pitch;
        leftSki.rotation.y = trickRotation.yaw + (Math.abs(trickRotation.roll) > 0.1 ? 0.25 : 0);
        leftSki.rotation.z = trickRotation.roll;
        rightSki.rotation.x = trickRotation.pitch;
        rightSki.rotation.y = trickRotation.yaw - (Math.abs(trickRotation.roll) > 0.1 ? 0.25 : 0);
        rightSki.rotation.z = trickRotation.roll;
      }
    } else {
      // On ground/water: carve banking and wave stance
      const rollTilt = -carveAngle * 0.38;
      const pitchTilt = isTucking ? 0.45 : (speedKmh / 140) * 0.25;

      bodyGroup.rotation.z = THREE.MathUtils.lerp(bodyGroup.rotation.z, rollTilt, 0.25);
      bodyGroup.rotation.x = THREE.MathUtils.lerp(bodyGroup.rotation.x, pitchTilt, 0.2);

      if (isBeach) {
        // AUTHENTIC SURFER STANCE: Side-facing athletic surf balance
        bodyGroup.rotation.y = THREE.MathUtils.lerp(bodyGroup.rotation.y, Math.PI / 3.2 + carveAngle * 0.22, 0.25);
        headGroup.rotation.y = THREE.MathUtils.lerp(headGroup.rotation.y, -Math.PI / 3.4, 0.25);

        // Arms outstretched to sides for wave balance
        leftArm.rotation.z = -0.75 - carveAngle * 0.45;
        rightArm.rotation.z = 0.75 - carveAngle * 0.45;
        leftArm.rotation.x = 0.22 + Math.sin(time * 3) * 0.08;
        rightArm.rotation.x = -0.22 - Math.sin(time * 3) * 0.08;

        // Surfboard carves the wave face with realistic water bobbing
        if (surfboard) {
          surfboard.rotation.z = THREE.MathUtils.lerp(surfboard.rotation.z, rollTilt * 1.1, 0.25);
          surfboard.rotation.y = THREE.MathUtils.lerp(surfboard.rotation.y, carveAngle * 0.45, 0.25);
          surfboard.rotation.x = THREE.MathUtils.lerp(surfboard.rotation.x, (speedKmh / 150) * 0.15, 0.2);
          surfboard.position.y = 0.035 + Math.sin(time * 6) * 0.015;
        }

      } else if (def.vehicleType === 'skis') {
        bodyGroup.rotation.y = THREE.MathUtils.lerp(bodyGroup.rotation.y, carveAngle * 0.35, 0.25);
        if (leftSki && rightSki) {
          leftSki.rotation.z = THREE.MathUtils.lerp(leftSki.rotation.z, rollTilt * 0.8, 0.25);
          rightSki.rotation.z = THREE.MathUtils.lerp(rightSki.rotation.z, rollTilt * 0.8, 0.25);
          leftSki.rotation.y = THREE.MathUtils.lerp(leftSki.rotation.y, carveAngle * 0.3, 0.25);
          rightSki.rotation.y = THREE.MathUtils.lerp(rightSki.rotation.y, carveAngle * 0.3, 0.25);
          leftSki.position.y = 0.03;
          rightSki.position.y = 0.03;
        }

        if (leftPole && rightPole) {
          if (isTucking) {
            leftArm.rotation.x = THREE.MathUtils.lerp(leftArm.rotation.x, 0.9, 0.2);
            rightArm.rotation.x = THREE.MathUtils.lerp(rightArm.rotation.x, 0.9, 0.2);
            leftPole.rotation.x = -1.2;
            rightPole.rotation.x = -1.2;
          } else {
            const plantFreq = speedKmh * 0.15;
            leftArm.rotation.x = Math.sin(time * plantFreq) * 0.4 + 0.1;
            rightArm.rotation.x = Math.cos(time * plantFreq) * 0.4 + 0.1;
            leftPole.rotation.x = 0.4;
            rightPole.rotation.x = 0.4;
          }
        }
      } else {
        if (snowboard) {
          snowboard.rotation.z = THREE.MathUtils.lerp(snowboard.rotation.z, rollTilt, 0.2);
          snowboard.rotation.y = THREE.MathUtils.lerp(snowboard.rotation.y, carveAngle * 0.45, 0.2);
          snowboard.position.y = 0.03;
        }
        leftArm.rotation.z = -0.4 - carveAngle * 0.5;
        rightArm.rotation.z = 0.4 - carveAngle * 0.5;
        leftArm.rotation.x = Math.sin(time * 4) * 0.1;
        rightArm.rotation.x = -Math.sin(time * 4) * 0.1;
      }

      leftLeg.position.y = -0.05;
      rightLeg.position.y = -0.05;
    }

    // Scarf fluttering in snow
    if (!isBeach) {
      const flutter = Math.sin(time * 22) * (speedKmh / 50) * 0.2;
      scarfMesh.rotation.z = flutter;
    }

    // Thruster glow if boosting
    if (nitroThrusters.length > 0) {
      nitroThrusters.forEach(t => {
        t.scale.setScalar(isBoosting ? 1.5 + Math.random() * 0.5 : 1.0);
      });
    }
  };

  const dispose = () => {
    jacketTex.dispose();
    boardTex.dispose();
    jacketMaterial.dispose();
    pantsMaterial.dispose();
    helmetMaterial.dispose();
    visorMaterial.dispose();
    boardMaterial.dispose();
    accentMaterial.dispose();
    bootMaterial.dispose();
    poleMaterial.dispose();
    skinFurMaterial.dispose();
    sandalMaterial.dispose();
  };

  return {
    root,
    bodyGroup,
    headGroup,
    torsoMesh,
    jacketMaterial,
    pantsMaterial,
    helmetMaterial,
    visorMaterial,
    boardMaterial,
    accentMaterial,
    leftLeg,
    rightLeg,
    leftArm,
    rightArm,
    leftSki,
    rightSki,
    snowboard,
    surfboard,
    leftPole,
    rightPole,
    scarfMesh,
    shieldMesh,
    nitroThrusters,
    def,
    customization,
    mapTheme: currentTheme,
    setMapTheme,
    updateCustomization,
    animate,
    dispose,
  };
}
