import * as THREE from 'three';
import { createPowderPuffTexture } from './textures';

const MAX_SNOW_PARTICLES = 350;
const MAX_FALLING_SNOW = 450;
const MAX_SPEED_LINES = 100;
const MAX_SPARKLES = 150;

export class ParticleSystem {
  public root: THREE.Group;

  // Snow Spray (Carving)
  private sprayGeometry: THREE.BufferGeometry;
  private sprayPositions: Float32Array;
  private sprayVelocities: Float32Array;
  private sprayLifetimes: Float32Array;
  private sprayPoints: THREE.Points;
  private sprayIndex: number = 0;

  // Ambient Blizzard Falling Snow
  private fallingGeometry: THREE.BufferGeometry;
  private fallingPositions: Float32Array;
  private fallingPoints: THREE.Points;

  // Speed Lines
  private linesGroup: THREE.Group;
  private lineMeshes: THREE.Line[];

  // Collectible Sparkles
  private sparkleGeometry: THREE.BufferGeometry;
  private sparklePositions: Float32Array;
  private sparkleColors: Float32Array;
  private sparkleLifetimes: Float32Array;
  private sparklePoints: THREE.Points;
  private sparkleIndex: number = 0;

  constructor() {
    this.root = new THREE.Group();
    this.root.name = 'particles_system';

    // 1. Setup Snow Spray (Carve Powder)
    this.sprayPositions = new Float32Array(MAX_SNOW_PARTICLES * 3);
    this.sprayVelocities = new Float32Array(MAX_SNOW_PARTICLES * 3);
    this.sprayLifetimes = new Float32Array(MAX_SNOW_PARTICLES); // 0 = inactive, >0 active

    this.sprayGeometry = new THREE.BufferGeometry();
    this.sprayGeometry.setAttribute('position', new THREE.BufferAttribute(this.sprayPositions, 3));

    const puffTex = createPowderPuffTexture();
    const sprayMat = new THREE.PointsMaterial({
      map: puffTex,
      color: 0xffffff,
      size: 0.55,
      transparent: true,
      opacity: 0.85,
      blending: THREE.NormalBlending,
      depthWrite: false,
    });
    this.sprayPoints = new THREE.Points(this.sprayGeometry, sprayMat);
    this.sprayPoints.frustumCulled = false;
    this.root.add(this.sprayPoints);

    // 2. Setup Ambient Falling Snow
    this.fallingPositions = new Float32Array(MAX_FALLING_SNOW * 3);
    for (let i = 0; i < MAX_FALLING_SNOW; i++) {
      this.fallingPositions[i * 3] = (Math.random() - 0.5) * 50;
      this.fallingPositions[i * 3 + 1] = Math.random() * 30;
      this.fallingPositions[i * 3 + 2] = (Math.random() - 0.5) * 50;
    }
    this.fallingGeometry = new THREE.BufferGeometry();
    this.fallingGeometry.setAttribute('position', new THREE.BufferAttribute(this.fallingPositions, 3));

    const fallingMat = new THREE.PointsMaterial({
      color: 0xf1f5f9,
      size: 0.16,
      transparent: true,
      opacity: 0.65,
      depthWrite: false,
    });
    this.fallingPoints = new THREE.Points(this.fallingGeometry, fallingMat);
    this.fallingPoints.frustumCulled = false;
    this.root.add(this.fallingPoints);

    // 3. Setup Speed Lines
    this.linesGroup = new THREE.Group();
    this.lineMeshes = [];
    const lineMat = new THREE.LineBasicMaterial({
      color: 0x38bdf8,
      transparent: true,
      opacity: 0.45,
    });

    for (let i = 0; i < MAX_SPEED_LINES; i++) {
      const geo = new THREE.BufferGeometry().setFromPoints([
        new THREE.Vector3(0, 0, 0),
        new THREE.Vector3(0, 0, 3 + Math.random() * 4),
      ]);
      const line = new THREE.Line(geo, lineMat);
      line.position.set(
        (Math.random() - 0.5) * 16,
        (Math.random() - 0.5) * 8 + 2,
        -10 - Math.random() * 30
      );
      line.visible = false;
      this.lineMeshes.push(line);
      this.linesGroup.add(line);
    }
    this.root.add(this.linesGroup);

    // 4. Setup Sparkle Points
    this.sparklePositions = new Float32Array(MAX_SPARKLES * 3);
    this.sparkleColors = new Float32Array(MAX_SPARKLES * 3);
    this.sparkleLifetimes = new Float32Array(MAX_SPARKLES);

    this.sparkleGeometry = new THREE.BufferGeometry();
    this.sparkleGeometry.setAttribute('position', new THREE.BufferAttribute(this.sparklePositions, 3));
    this.sparkleGeometry.setAttribute('color', new THREE.BufferAttribute(this.sparkleColors, 3));

    const sparkleMat = new THREE.PointsMaterial({
      vertexColors: true,
      size: 0.35,
      transparent: true,
      opacity: 0.9,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    });
    this.sparklePoints = new THREE.Points(this.sparkleGeometry, sparkleMat);
    this.sparklePoints.frustumCulled = false;
    this.root.add(this.sparklePoints);
  }

  /**
   * Emits snow rooster spray from ski or snowboard contacts
   */
  public emitSnowSpray(
    origin: THREE.Vector3,
    carveIntensity: number,
    forwardSpeed: number,
    count = 3
  ) {
    for (let c = 0; c < count; c++) {
      const idx = this.sprayIndex;
      this.sprayIndex = (this.sprayIndex + 1) % MAX_SNOW_PARTICLES;

      const pIdx = idx * 3;
      this.sprayPositions[pIdx] = origin.x + (Math.random() - 0.5) * 0.3;
      this.sprayPositions[pIdx + 1] = origin.y + 0.05;
      this.sprayPositions[pIdx + 2] = origin.z - 0.4;

      // Spray shoots outward opposite to carve and upward
      const sprayAngle = carveIntensity > 0 ? -1 : 1;
      this.sprayVelocities[pIdx] = sprayAngle * (1.5 + Math.random() * 3.5 * Math.abs(carveIntensity));
      this.sprayVelocities[pIdx + 1] = 1.0 + Math.random() * 2.2;
      this.sprayVelocities[pIdx + 2] = -forwardSpeed * 0.2 - Math.random() * 2;

      this.sprayLifetimes[idx] = 0.5 + Math.random() * 0.4;
    }
  }

  /**
   * Explosive burst on crash or snowman hit
   */
  public emitExplosion(origin: THREE.Vector3, count = 40) {
    for (let i = 0; i < count; i++) {
      const idx = this.sprayIndex;
      this.sprayIndex = (this.sprayIndex + 1) % MAX_SNOW_PARTICLES;

      const pIdx = idx * 3;
      this.sprayPositions[pIdx] = origin.x;
      this.sprayPositions[pIdx + 1] = origin.y + 0.3;
      this.sprayPositions[pIdx + 2] = origin.z;

      const angle = Math.random() * Math.PI * 2;
      const speed = 2 + Math.random() * 7;
      this.sprayVelocities[pIdx] = Math.cos(angle) * speed;
      this.sprayVelocities[pIdx + 1] = 2.5 + Math.random() * 5.0;
      this.sprayVelocities[pIdx + 2] = Math.sin(angle) * speed;

      this.sprayLifetimes[idx] = 0.8 + Math.random() * 0.5;
    }
  }

  /**
   * Sparkle burst for coins, gems, and power-ups
   */
  public emitSparkles(origin: THREE.Vector3, colorHex: number, count = 15) {
    const color = new THREE.Color(colorHex);
    for (let i = 0; i < count; i++) {
      const idx = this.sparkleIndex;
      this.sparkleIndex = (this.sparkleIndex + 1) % MAX_SPARKLES;

      const pIdx = idx * 3;
      this.sparklePositions[pIdx] = origin.x + (Math.random() - 0.5) * 0.4;
      this.sparklePositions[pIdx + 1] = origin.y + (Math.random() - 0.5) * 0.4;
      this.sparklePositions[pIdx + 2] = origin.z + (Math.random() - 0.5) * 0.4;

      this.sparkleColors[pIdx] = color.r;
      this.sparkleColors[pIdx + 1] = color.g;
      this.sparkleColors[pIdx + 2] = color.b;

      this.sparkleLifetimes[idx] = 0.6 + Math.random() * 0.5;
    }
  }

  public update(
    dt: number,
    playerPos: THREE.Vector3,
    speedKmh: number,
    isBoosting: boolean,
    windSpeed = 0,
    snowDensity = 0.3
  ) {
    // 1. Update Snow Spray
    let sprayDirty = false;
    for (let i = 0; i < MAX_SNOW_PARTICLES; i++) {
      if (this.sprayLifetimes[i] > 0) {
        this.sprayLifetimes[i] -= dt;
        const pIdx = i * 3;

        // Apply velocity + gravity + lateral wind
        this.sprayPositions[pIdx] += (this.sprayVelocities[pIdx] + windSpeed * 0.4) * dt;
        this.sprayPositions[pIdx + 1] += this.sprayVelocities[pIdx + 1] * dt;
        this.sprayPositions[pIdx + 2] += this.sprayVelocities[pIdx + 2] * dt;

        this.sprayVelocities[pIdx + 1] -= 9.8 * dt; // gravity

        sprayDirty = true;
      }
    }
    if (sprayDirty) {
      this.sprayGeometry.attributes.position.needsUpdate = true;
    }

    // 2. Update Ambient Falling Snow with dynamic weather storm drift
    const fallRate = (4.5 + windSpeed * 0.9) * dt;
    const lateralDrift = windSpeed * 3.5 * dt;

    for (let i = 0; i < MAX_FALLING_SNOW; i++) {
      const pIdx = i * 3;
      // Drift down and horizontally based on blizzard winds
      this.fallingPositions[pIdx + 1] -= fallRate;
      this.fallingPositions[pIdx] += Math.sin(this.fallingPositions[pIdx + 1] * 0.4) * dt * 1.5 + lateralDrift;

      // Wrap in box around player
      const dx = this.fallingPositions[pIdx] - playerPos.x;
      const dy = this.fallingPositions[pIdx + 1] - playerPos.y;
      const dz = this.fallingPositions[pIdx + 2] - playerPos.z;

      if (dx > 25) this.fallingPositions[pIdx] -= 50;
      if (dx < -25) this.fallingPositions[pIdx] += 50;

      if (dy < -5) this.fallingPositions[pIdx + 1] += 30;
      if (dy > 25) this.fallingPositions[pIdx + 1] -= 30;

      if (dz > 25) this.fallingPositions[pIdx + 2] -= 50;
      if (dz < -25) this.fallingPositions[pIdx + 2] += 50;
    }
    this.fallingGeometry.attributes.position.needsUpdate = true;

    // Adjust particle size & opacity for blizzards
    const mat = this.fallingPoints.material as THREE.PointsMaterial;
    mat.opacity = 0.5 + snowDensity * 0.45;
    mat.size = 0.16 + snowDensity * 0.14;

    // 3. Update Speed Lines
    const showSpeedLines = speedKmh > 75 || isBoosting;
    const activeCount = isBoosting ? MAX_SPEED_LINES : Math.floor(((speedKmh - 75) / 50) * MAX_SPEED_LINES);

    this.lineMeshes.forEach((line, idx) => {
      if (showSpeedLines && idx < activeCount) {
        line.visible = true;
        line.position.z += (speedKmh * 0.8 + (isBoosting ? 40 : 0)) * dt;
        if (line.position.z > playerPos.z + 10) {
          line.position.set(
            playerPos.x + (Math.random() - 0.5) * 18,
            playerPos.y + (Math.random() - 0.5) * 8 + 1.5,
            playerPos.z - 25 - Math.random() * 25
          );
        }
      } else {
        line.visible = false;
      }
    });

    // 4. Update Sparkles
    let sparkleDirty = false;
    for (let i = 0; i < MAX_SPARKLES; i++) {
      if (this.sparkleLifetimes[i] > 0) {
        this.sparkleLifetimes[i] -= dt;
        const pIdx = i * 3;
        this.sparklePositions[pIdx + 1] += dt * 1.8; // float up
        sparkleDirty = true;
      }
    }
    if (sparkleDirty) {
      this.sparkleGeometry.attributes.position.needsUpdate = true;
    }
  }

  public setTheme(theme: 'snow' | 'beach') {
    const sprayMat = this.sprayPoints.material as THREE.PointsMaterial;
    const fallingMat = this.fallingPoints.material as THREE.PointsMaterial;

    if (theme === 'beach') {
      sprayMat.color.set(0xe0f2fe);   // Frothy white water wave spray
      sprayMat.size = 0.65;
      sprayMat.opacity = 0.9;
      fallingMat.color.set(0xbae6fd); // Tropical sea mist / ocean spray
      fallingMat.opacity = 0.35;
      fallingMat.size = 0.14;
    } else {
      sprayMat.color.set(0xffffff);   // Crisp alpine snow powder
      sprayMat.size = 0.55;
      sprayMat.opacity = 0.85;
      fallingMat.color.set(0xf1f5f9); // Falling snowflakes
      fallingMat.opacity = 0.65;
      fallingMat.size = 0.16;
    }
  }

  public dispose() {
    this.sprayGeometry.dispose();
    this.fallingGeometry.dispose();
    this.sparkleGeometry.dispose();
  }
}
