import React, { useEffect } from 'react';
import { CharacterDef, PlayerProgress, MapTheme } from '../types/game';
import { Play, Sparkles, Volume2, VolumeX, Zap, Award, Calendar, Palmtree, Mountain } from 'lucide-react';

interface TitleScreenProps {
  progress: PlayerProgress;
  activeCharacter: CharacterDef;
  onStart: () => void;
  onOpenCustomizer: () => void;
  onToggleSound: () => void;
  onSelectMap: (theme: MapTheme) => void;
  onOpenDailyChallenges: () => void;
  unclaimedChallengesCount?: number;
}

export const TitleScreen: React.FC<TitleScreenProps> = ({
  progress,
  activeCharacter,
  onStart,
  onOpenCustomizer,
  onToggleSound,
  onSelectMap,
  onOpenDailyChallenges,
  unclaimedChallengesCount = 0,
}) => {
  const currentMap = progress.selectedMap || 'snow';

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.code === 'Space' || e.code === 'Enter') {
        e.preventDefault();
        onStart();
      } else if (e.code === 'KeyC') {
        onOpenCustomizer();
      } else if (e.code === 'KeyM') {
        onSelectMap(currentMap === 'snow' ? 'beach' : 'snow');
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onStart, onOpenCustomizer, onSelectMap, currentMap]);

  return (
    <div className="absolute inset-0 pointer-events-none flex flex-col justify-between p-4 sm:p-8 select-none overflow-y-auto">
      {/* Top Bar Status */}
      <div className="flex items-center justify-between pointer-events-auto gap-2">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 bg-slate-900/85 border border-slate-700/60 rounded-2xl px-4 py-2 backdrop-blur-md shadow-lg shadow-black/40">
            <span className="text-amber-400 text-lg">🪙</span>
            <span className="font-race text-xl text-amber-300 font-bold tabular-nums">
              {progress.coins.toLocaleString()}
            </span>
          </div>

          <div className="flex items-center gap-2 bg-slate-900/85 border border-slate-700/60 rounded-2xl px-4 py-2 backdrop-blur-md shadow-lg shadow-black/40">
            <span className="text-cyan-400 text-lg">💎</span>
            <span className="font-race text-xl text-cyan-300 font-bold tabular-nums">
              {progress.gems.toLocaleString()}
            </span>
          </div>

          {progress.highScore > 0 && (
            <div className="hidden sm:flex items-center gap-2 bg-slate-900/85 border border-slate-700/60 rounded-2xl px-4 py-2 backdrop-blur-md">
              <Award className="w-5 h-5 text-yellow-400" />
              <span className="text-xs text-slate-400 uppercase tracking-wider font-semibold">Best</span>
              <span className="font-race text-lg text-slate-200 font-bold tabular-nums">
                {progress.highScore.toLocaleString()}
              </span>
            </div>
          )}
        </div>

        <div className="flex items-center gap-2">
          {/* Daily Challenges Button */}
          <button
            onClick={onOpenDailyChallenges}
            className="relative px-3.5 py-2.5 bg-gradient-to-r from-amber-500/20 to-yellow-500/20 hover:from-amber-500/30 hover:to-yellow-500/30 border border-amber-500/50 rounded-2xl text-amber-200 hover:text-white transition-all shadow-lg flex items-center gap-2 cursor-pointer font-race font-bold text-xs"
            aria-label="Daily Challenges"
          >
            <Calendar className="w-4 h-4 text-amber-400" />
            <span className="hidden sm:inline">DAILY MISSIONS</span>
            {unclaimedChallengesCount > 0 && (
              <span className="w-5 h-5 rounded-full bg-amber-500 text-slate-950 font-black text-[11px] flex items-center justify-center animate-bounce shadow-md">
                {unclaimedChallengesCount}
              </span>
            )}
          </button>

          <button
            onClick={onToggleSound}
            className="p-3 bg-slate-900/85 hover:bg-slate-800 border border-slate-700/60 rounded-2xl text-slate-300 hover:text-white transition-all shadow-lg cursor-pointer"
            aria-label="Toggle Sound"
          >
            {progress.soundEnabled ? <Volume2 className="w-5 h-5 text-cyan-400" /> : <VolumeX className="w-5 h-5 text-slate-500" />}
          </button>
        </div>
      </div>

      {/* Center Hero Title Lockup with 30-40% Negative Space */}
      <div className="flex flex-col items-center justify-center text-center my-auto py-4">
        {/* Bespoke Mountain & Icy Title Lockup */}
        <div className="relative mb-4">
          <svg className="w-72 sm:w-96 md:w-[480px] h-24 sm:h-32 drop-shadow-[0_12px_24px_rgba(0,0,0,0.6)]" viewBox="0 0 500 130" fill="none">
            <defs>
              <linearGradient id="snowGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#ffffff" />
                <stop offset="45%" stopColor={currentMap === 'beach' ? '#fed7aa' : '#e0f2fe'} />
                <stop offset="100%" stopColor={currentMap === 'beach' ? '#f59e0b' : '#38bdf8'} />
              </linearGradient>
            </defs>

            {/* Alpine Mountain / Dune Silhouette */}
            {currentMap === 'beach' ? (
              <path d="M50,55 Q150,20 250,45 T450,30 L450,55 L50,55 Z" fill="rgba(245, 158, 11, 0.25)" />
            ) : (
              <polygon points="120,40 160,5 200,40 230,18 270,50 300,12 340,45 380,25 410,50 100,50" fill="rgba(56, 189, 248, 0.25)" />
            )}

            {/* Main Title Typography */}
            <text x="250" y="68" textAnchor="middle" className="font-race font-black tracking-widest text-5xl sm:text-6xl" fill="url(#snowGrad)">
              {currentMap === 'beach' ? 'OCEAN SURF' : 'ALPINE RUSH'}
            </text>
            <text x="250" y="105" textAnchor="middle" className="font-race font-bold tracking-[0.28em] text-xl sm:text-2xl" fill={currentMap === 'beach' ? '#38bdf8' : '#7dd3fc'}>
              {currentMap === 'beach' ? 'TROPICAL WATER RAPIDS' : 'MOUNTAIN DOWNHILL'}
            </text>
          </svg>
        </div>

        {/* Map Selection Segmented Switcher */}
        <div className="bg-slate-900/95 border border-slate-700/80 rounded-2xl p-1.5 flex items-center gap-1.5 shadow-xl backdrop-blur-md mb-6 pointer-events-auto">
          <button
            onClick={() => onSelectMap('snow')}
            className={`px-5 py-2.5 rounded-xl font-race font-bold text-xs sm:text-sm flex items-center gap-2 transition-all cursor-pointer ${
              currentMap === 'snow'
                ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-slate-950 shadow-md shadow-cyan-500/30'
                : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
            }`}
          >
            <Mountain className="w-4 h-4" />
            <span>🏔️ ALPINE SNOW</span>
          </button>

          <button
            onClick={() => onSelectMap('beach')}
            className={`px-5 py-2.5 rounded-xl font-race font-bold text-xs sm:text-sm flex items-center gap-2 transition-all cursor-pointer ${
              currentMap === 'beach'
                ? 'bg-gradient-to-r from-cyan-400 via-sky-500 to-blue-600 text-slate-950 shadow-md shadow-cyan-500/30'
                : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
            }`}
          >
            <Palmtree className="w-4 h-4" />
            <span>🌊 OCEAN SURF</span>
          </button>
        </div>

        {/* Selected Racer Info Pill (with Map Theme Awareness) */}
        <div className="bg-slate-900/90 border border-slate-700/80 rounded-2xl px-6 py-3 flex items-center gap-4 shadow-xl backdrop-blur-md mb-6 max-w-md pointer-events-auto">
          <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center text-white font-bold text-lg shadow-inner">
            {currentMap === 'beach' ? '🏄' : activeCharacter.vehicleType === 'skis' ? '⛷️' : activeCharacter.vehicleType === 'yeti_stride' ? '🐾' : '🏂'}
          </div>
          <div className="text-left">
            <div className="text-[10px] text-cyan-400 font-bold uppercase tracking-wider">
              {currentMap === 'beach' ? 'Surfboard & Hawaiian Beach Gear Active' : 'Winter Thermal Suit Active'}
            </div>
            <div className="text-white font-race text-lg font-bold">{activeCharacter.name}</div>
            <div className="text-xs text-slate-300 flex items-center gap-1">
              <Zap className="w-3.5 h-3.5 text-amber-400 inline" />
              <span>{activeCharacter.specialAbility.split(':')[0]}</span>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row items-center gap-4 pointer-events-auto">
          <button
            onClick={onStart}
            className={`group px-8 py-4 text-slate-950 font-race font-black text-xl tracking-wider rounded-2xl transition-all flex items-center gap-3 cursor-pointer hover:scale-105 active:scale-95 ${
              currentMap === 'beach'
                ? 'bg-gradient-to-r from-amber-400 via-yellow-400 to-orange-500 shadow-[0_0_30px_rgba(251,191,36,0.5)] hover:shadow-[0_0_45px_rgba(251,191,36,0.7)]'
                : 'bg-gradient-to-r from-cyan-500 via-sky-500 to-blue-600 shadow-[0_0_30px_rgba(56,189,248,0.4)] hover:shadow-[0_0_45px_rgba(56,189,248,0.65)]'
            }`}
          >
            <Play className="w-6 h-6 fill-current" />
            <span>DROP IN & RACE</span>
          </button>

          <button
            onClick={onOpenCustomizer}
            className="px-6 py-4 bg-slate-900/90 hover:bg-slate-800 text-slate-200 hover:text-white font-race font-bold text-lg rounded-2xl border border-slate-700/80 shadow-lg hover:scale-105 active:scale-95 transition-all flex items-center gap-3 pointer-events-auto cursor-pointer"
          >
            <Sparkles className="w-5 h-5 text-amber-400" />
            <span>RACER & OUTFIT WORKSHOP</span>
          </button>
        </div>
      </div>

      {/* Flat Control Hints Bar */}
      <div className="flex flex-col items-center gap-2 pointer-events-auto pb-2">
        <div className="bg-slate-950/85 border border-slate-800 rounded-full px-6 py-2 backdrop-blur-md text-xs sm:text-sm text-slate-400 font-medium tracking-wide">
          <span className="text-cyan-300 font-bold">A</span> Left &nbsp;·&nbsp;
          <span className="text-cyan-300 font-bold">D</span> Right &nbsp;·&nbsp;
          <span className="text-cyan-300 font-bold">W</span> Speed Boost &nbsp;·&nbsp;
          <span className="text-cyan-300 font-bold">Space</span> Jump & Aerial Tricks &nbsp;·&nbsp;
          <span className="text-amber-400 font-bold">⭐ Star</span> Super Magnet
        </div>
      </div>
    </div>
  );
};
