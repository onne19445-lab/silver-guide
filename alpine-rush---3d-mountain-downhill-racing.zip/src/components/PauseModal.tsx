import React from 'react';
import { Play, RotateCcw, Palette, Home, Volume2, VolumeX, ArrowLeftRight } from 'lucide-react';

interface PauseModalProps {
  soundEnabled: boolean;
  invertSteering: boolean;
  onResume: () => void;
  onRestart: () => void;
  onOpenCustomizer: () => void;
  onMainMenu: () => void;
  onToggleSound: () => void;
  onToggleInvertSteering: () => void;
}

export const PauseModal: React.FC<PauseModalProps> = ({
  soundEnabled,
  invertSteering,
  onResume,
  onRestart,
  onOpenCustomizer,
  onMainMenu,
  onToggleSound,
  onToggleInvertSteering,
}) => {
  return (
    <div className="absolute inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm select-none">
      <div className="w-full max-w-sm bg-slate-900 border border-slate-700/80 rounded-3xl p-6 shadow-2xl flex flex-col items-center text-center animate-in fade-in zoom-in-95 duration-150">
        <h2 className="text-2xl font-race font-bold text-white tracking-wide mb-1">
          RACE PAUSED
        </h2>
        <p className="text-xs text-slate-400 mb-6">Catch your breath on the slope</p>

        <div className="w-full flex flex-col gap-3">
          <button
            onClick={onResume}
            className="w-full py-3.5 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-race font-black text-base tracking-wider rounded-xl shadow-lg shadow-cyan-500/20 transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <Play className="w-5 h-5 fill-current" />
            <span>RESUME RACE</span>
          </button>

          <button
            onClick={onRestart}
            className="w-full py-3 bg-slate-800 hover:bg-slate-700 text-slate-200 font-race font-bold text-sm rounded-xl border border-slate-700 transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <RotateCcw className="w-4 h-4" />
            <span>RESTART RUN</span>
          </button>

          <button
            onClick={onOpenCustomizer}
            className="w-full py-3 bg-slate-800 hover:bg-slate-700 text-slate-200 font-race font-bold text-sm rounded-xl border border-slate-700 transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <Palette className="w-4 h-4 text-cyan-400" />
            <span>CUSTOMIZER LOCKER</span>
          </button>

          <button
            onClick={onMainMenu}
            className="w-full py-3 bg-slate-800 hover:bg-slate-700 text-slate-200 font-race font-bold text-sm rounded-xl border border-slate-700 transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <Home className="w-4 h-4 text-slate-400" />
            <span>MAIN MENU</span>
          </button>

          {/* Settings Bar */}
          <div className="pt-2 border-t border-slate-800 grid grid-cols-2 gap-2">
            <button
              onClick={onToggleInvertSteering}
              className={`py-2 px-3 text-xs font-race font-bold rounded-xl border flex items-center justify-center gap-1.5 cursor-pointer transition-all ${
                invertSteering
                  ? 'bg-amber-500/20 border-amber-500/60 text-amber-300'
                  : 'bg-slate-800/80 border-slate-700 text-slate-300 hover:text-white'
              }`}
            >
              <ArrowLeftRight className="w-3.5 h-3.5" />
              <span>{invertSteering ? 'STEER: INVERT' : 'STEER: NORMAL'}</span>
            </button>

            <button
              onClick={onToggleSound}
              className="py-2 px-3 bg-slate-800/80 hover:bg-slate-700 border border-slate-700 rounded-xl text-xs font-race font-bold text-slate-300 hover:text-white flex items-center justify-center gap-1.5 cursor-pointer"
            >
              {soundEnabled ? <Volume2 className="w-3.5 h-3.5 text-cyan-400" /> : <VolumeX className="w-3.5 h-3.5 text-slate-500" />}
              <span>{soundEnabled ? 'SOUND: ON' : 'MUTED'}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
