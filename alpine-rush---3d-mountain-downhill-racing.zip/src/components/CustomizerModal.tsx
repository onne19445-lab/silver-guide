import React, { useState } from 'react';
import { 
  CharacterDef, 
  CharacterCustomization, 
  CharacterId, 
  PlayerProgress,
  JacketPattern 
} from '../types/game';
import { CHARACTERS, PALETTES, PATTERNS } from '../game/charactersConfig';
import { 
  Check, 
  Lock, 
  Sparkles, 
  X, 
  Zap, 
  Gauge, 
  Wind, 
  Flame, 
  ShieldCheck,
  Palette
} from 'lucide-react';
import { sound } from '../game/audio';

interface CustomizerModalProps {
  progress: PlayerProgress;
  onClose: () => void;
  onSelectCharacter: (id: CharacterId) => void;
  onUpdateCustomization: (characterId: CharacterId, customization: CharacterCustomization) => void;
  onUnlockCharacter: (id: CharacterId, cost: number) => void;
}

export const CustomizerModal: React.FC<CustomizerModalProps> = ({
  progress,
  onClose,
  onSelectCharacter,
  onUpdateCustomization,
  onUnlockCharacter,
}) => {
  const [activeTab, setActiveTab] = useState<'racers' | 'outfit'>('racers');
  const [selectedCharId, setSelectedCharId] = useState<CharacterId>(progress.selectedCharacter);

  const selectedDef = CHARACTERS.find((c) => c.id === selectedCharId) || CHARACTERS[0];
  const isUnlocked = progress.unlockedCharacters.includes(selectedCharId);
  const currentCustom = progress.customizations[selectedCharId] || selectedDef.defaultCustomization;

  const [customDraft, setCustomDraft] = useState<CharacterCustomization>(currentCustom);

  const handleSelectChar = (char: CharacterDef) => {
    setSelectedCharId(char.id);
    setCustomDraft(progress.customizations[char.id] || char.defaultCustomization);
    if (progress.unlockedCharacters.includes(char.id)) {
      onSelectCharacter(char.id);
    }
  };

  const handleApplyCustom = (newCustom: Partial<CharacterCustomization>) => {
    const updated = { ...customDraft, ...newCustom };
    setCustomDraft(updated);
    onUpdateCustomization(selectedCharId, updated);
  };

  const handleUnlock = () => {
    if (progress.coins >= selectedDef.unlockCost) {
      sound.playGem();
      onUnlockCharacter(selectedDef.id, selectedDef.unlockCost);
      onSelectCharacter(selectedDef.id);
    }
  };

  return (
    <div className="absolute inset-0 z-40 flex flex-col justify-between pointer-events-none p-4 sm:p-8">
      {/* Top Header & Currencies */}
      <div className="flex items-center justify-between pointer-events-auto bg-slate-900/90 border border-slate-700/80 rounded-2xl p-4 backdrop-blur-md shadow-2xl">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-cyan-500/20 text-cyan-400 rounded-xl border border-cyan-500/30">
            <Palette className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-xl sm:text-2xl font-race font-bold text-white tracking-wide">
              ALPINESMITH WORKSHOP
            </h1>
            <p className="text-xs text-slate-400 hidden sm:block">
              Choose your downhill racer and customize livery, gear & outfit
            </p>
          </div>
        </div>

        {/* Currency Clusters */}
        <div className="flex items-center gap-3 sm:gap-6">
          <div className="flex items-center gap-2 bg-slate-950/70 border border-amber-500/30 px-3.5 py-1.5 rounded-xl">
            <span className="text-amber-400 text-lg">🪙</span>
            <span className="font-race text-lg text-amber-300 font-bold tabular-nums">
              {progress.coins.toLocaleString()}
            </span>
          </div>

          <div className="flex items-center gap-2 bg-slate-950/70 border border-cyan-500/30 px-3.5 py-1.5 rounded-xl">
            <span className="text-cyan-400 text-lg">💎</span>
            <span className="font-race text-lg text-cyan-300 font-bold tabular-nums">
              {progress.gems.toLocaleString()}
            </span>
          </div>

          <button
            onClick={onClose}
            className="p-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-xl transition-all cursor-pointer"
            aria-label="Close Customizer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Center 3D Viewport is unobstructed - 360 Turntable is active in background! */}

      {/* Sleek Ergonomic Bottom Dock (Zero Viewport Occlusion, satisfies Three.js guidelines) */}
      <div className="pointer-events-auto w-full max-w-4xl mx-auto bg-slate-900/95 border border-slate-700/80 rounded-3xl p-5 shadow-2xl backdrop-blur-md flex flex-col gap-4 mt-auto">
        {/* Navigation Tabs */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <button
              onClick={() => setActiveTab('racers')}
              className={`px-5 py-2 rounded-xl font-race font-bold text-sm tracking-wider transition-all cursor-pointer ${
                activeTab === 'racers'
                  ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/30'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              }`}
            >
              1. RACERS & ABILITIES
            </button>
            <button
              onClick={() => setActiveTab('outfit')}
              className={`px-5 py-2 rounded-xl font-race font-bold text-sm tracking-wider transition-all cursor-pointer ${
                activeTab === 'outfit'
                  ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/30'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              }`}
            >
              2. OUTFIT & PATTERNS
            </button>
          </div>

          {/* Quick Lock / Equip Status */}
          <div className="flex items-center gap-3">
            {isUnlocked ? (
              <span className="text-xs bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 px-3 py-1 rounded-full font-bold flex items-center gap-1">
                <Check className="w-3.5 h-3.5" /> EQUIPPED
              </span>
            ) : (
              <button
                onClick={handleUnlock}
                disabled={progress.coins < selectedDef.unlockCost}
                className={`px-4 py-1.5 rounded-xl font-race font-bold text-sm flex items-center gap-2 transition-all cursor-pointer ${
                  progress.coins >= selectedDef.unlockCost
                    ? 'bg-amber-400 hover:bg-amber-300 text-slate-950 shadow-lg shadow-amber-400/30'
                    : 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700'
                }`}
              >
                <Lock className="w-4 h-4" />
                <span>UNLOCK FOR {selectedDef.unlockCost} COINS</span>
              </button>
            )}
          </div>
        </div>

        {/* Tab 1: Racers & Stats */}
        {activeTab === 'racers' && (
          <div className="grid grid-cols-1 md:grid-cols-12 gap-5">
            {/* Racer Select Carousel */}
            <div className="md:col-span-6 flex gap-2.5 overflow-x-auto pb-2 scrollbar-none">
              {CHARACTERS.map((char) => {
                const unlocked = progress.unlockedCharacters.includes(char.id);
                const isSelected = selectedCharId === char.id;
                return (
                  <button
                    key={char.id}
                    onClick={() => handleSelectChar(char)}
                    className={`flex-shrink-0 w-28 sm:w-32 p-3 rounded-2xl border text-left transition-all cursor-pointer flex flex-col justify-between ${
                      isSelected
                        ? 'border-cyan-400 bg-cyan-950/40 shadow-lg shadow-cyan-500/20 ring-2 ring-cyan-500/40'
                        : 'border-slate-800 bg-slate-950/60 hover:bg-slate-800/80 text-slate-300'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-2xl">
                        {char.vehicleType === 'skis' ? '⛷️' : char.vehicleType === 'yeti_stride' ? '🐾' : '🏂'}
                      </span>
                      {!unlocked && <Lock className="w-4 h-4 text-amber-400" />}
                    </div>
                    <div>
                      <div className="font-race font-bold text-sm text-white truncate">{char.name}</div>
                      <div className="text-[10px] text-cyan-300/80 capitalize">{char.vehicleType.replace('_', ' ')}</div>
                    </div>
                  </button>
                );
              })}
            </div>

            {/* Selected Character Stats & Unique Ability */}
            <div className="md:col-span-6 flex flex-col justify-between bg-slate-950/60 border border-slate-800/80 rounded-2xl p-4">
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <span className="font-race text-lg font-bold text-white">{selectedDef.name}</span>
                  <span className="text-xs text-slate-400">{selectedDef.title}</span>
                </div>

                <div className="bg-cyan-950/30 border border-cyan-800/50 rounded-xl p-2.5 mb-3 flex items-start gap-2 text-xs text-cyan-200">
                  <Zap className="w-4 h-4 text-amber-400 flex-shrink-0 mt-0.5" />
                  <span>{selectedDef.specialAbility}</span>
                </div>
              </div>

              {/* Stat Meters */}
              <div className="space-y-1.5 text-xs">
                <div className="flex items-center justify-between">
                  <span className="text-slate-400 flex items-center gap-1"><Gauge className="w-3.5 h-3.5 text-sky-400" /> Speed</span>
                  <div className="w-36 bg-slate-800 h-2 rounded-full overflow-hidden">
                    <div className="bg-sky-400 h-full rounded-full" style={{ width: `${selectedDef.stats.speed * 10}%` }} />
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-400 flex items-center gap-1"><Wind className="w-3.5 h-3.5 text-emerald-400" /> Carving</span>
                  <div className="w-36 bg-slate-800 h-2 rounded-full overflow-hidden">
                    <div className="bg-emerald-400 h-full rounded-full" style={{ width: `${selectedDef.stats.carving * 10}%` }} />
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-400 flex items-center gap-1"><Sparkles className="w-3.5 h-3.5 text-purple-400" /> Airtime</span>
                  <div className="w-36 bg-slate-800 h-2 rounded-full overflow-hidden">
                    <div className="bg-purple-400 h-full rounded-full" style={{ width: `${selectedDef.stats.airtime * 10}%` }} />
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-400 flex items-center gap-1"><Flame className="w-3.5 h-3.5 text-amber-400" /> Nitro Boost</span>
                  <div className="w-36 bg-slate-800 h-2 rounded-full overflow-hidden">
                    <div className="bg-amber-400 h-full rounded-full" style={{ width: `${selectedDef.stats.boost * 10}%` }} />
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-400 flex items-center gap-1"><ShieldCheck className="w-3.5 h-3.5 text-rose-400" /> Resilience</span>
                  <div className="w-36 bg-slate-800 h-2 rounded-full overflow-hidden">
                    <div className="bg-rose-400 h-full rounded-full" style={{ width: `${selectedDef.stats.resilience * 10}%` }} />
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Tab 2: Outfit Customizer (Jackets, Patterns, Pants, Helmets, Visors, Board) */}
        {activeTab === 'outfit' && (
          <div className="grid grid-cols-1 md:grid-cols-12 gap-5">
            {/* Pattern Selector */}
            <div className="md:col-span-5 bg-slate-950/60 border border-slate-800/80 rounded-2xl p-4 flex flex-col justify-between">
              <div>
                <label className="text-xs font-race uppercase tracking-wider text-slate-400 block mb-2 font-bold">
                  Jacket Pattern
                </label>
                <div className="space-y-1.5">
                  {PATTERNS.map((pat) => (
                    <button
                      key={pat.id}
                      onClick={() => handleApplyCustom({ jacketPattern: pat.id })}
                      className={`w-full text-left px-3 py-2 rounded-xl text-xs font-semibold flex items-center justify-between transition-all cursor-pointer ${
                        customDraft.jacketPattern === pat.id
                          ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/50'
                          : 'bg-slate-900/60 text-slate-400 hover:bg-slate-800 hover:text-slate-200'
                      }`}
                    >
                      <div>
                        <div className="font-race font-bold">{pat.label}</div>
                        <div className="text-[10px] text-slate-500">{pat.desc}</div>
                      </div>
                      {customDraft.jacketPattern === pat.id && <Check className="w-4 h-4 text-cyan-400" />}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Color Palette Swatches for Elements */}
            <div className="md:col-span-7 bg-slate-950/60 border border-slate-800/80 rounded-2xl p-4 flex flex-col gap-3">
              {/* Jacket Color */}
              <div>
                <div className="text-xs font-race uppercase tracking-wider text-slate-400 mb-1.5 flex items-center justify-between">
                  <span>Jacket Fabric</span>
                  <span className="text-[10px] text-slate-500">{customDraft.jacketColor}</span>
                </div>
                <div className="flex gap-2">
                  {PALETTES.map((c) => (
                    <button
                      key={c.hex}
                      onClick={() => handleApplyCustom({ jacketColor: c.hex })}
                      style={{ backgroundColor: c.hex }}
                      className={`w-7 h-7 rounded-full border-2 transition-all cursor-pointer ${
                        customDraft.jacketColor === c.hex ? 'border-white scale-110 shadow-lg' : 'border-transparent opacity-80 hover:opacity-100'
                      }`}
                      title={c.name}
                    />
                  ))}
                </div>
              </div>

              {/* Pants Color */}
              <div>
                <div className="text-xs font-race uppercase tracking-wider text-slate-400 mb-1.5 flex items-center justify-between">
                  <span>Pants Fabric</span>
                  <span className="text-[10px] text-slate-500">{customDraft.pantsColor}</span>
                </div>
                <div className="flex gap-2">
                  {PALETTES.map((c) => (
                    <button
                      key={c.hex}
                      onClick={() => handleApplyCustom({ pantsColor: c.hex })}
                      style={{ backgroundColor: c.hex }}
                      className={`w-7 h-7 rounded-full border-2 transition-all cursor-pointer ${
                        customDraft.pantsColor === c.hex ? 'border-white scale-110 shadow-lg' : 'border-transparent opacity-80 hover:opacity-100'
                      }`}
                      title={c.name}
                    />
                  ))}
                </div>
              </div>

              {/* Helmet & Visor */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <div className="text-xs font-race uppercase tracking-wider text-slate-400 mb-1.5">Helmet Shell</div>
                  <div className="flex gap-1.5 flex-wrap">
                    {PALETTES.slice(0, 6).map((c) => (
                      <button
                        key={c.hex}
                        onClick={() => handleApplyCustom({ helmetColor: c.hex })}
                        style={{ backgroundColor: c.hex }}
                        className={`w-6 h-6 rounded-full border-2 transition-all cursor-pointer ${
                          customDraft.helmetColor === c.hex ? 'border-white scale-110' : 'border-transparent opacity-80'
                        }`}
                        title={c.name}
                      />
                    ))}
                  </div>
                </div>

                <div>
                  <div className="text-xs font-race uppercase tracking-wider text-slate-400 mb-1.5">Visor Goggles</div>
                  <div className="flex gap-1.5 flex-wrap">
                    {PALETTES.slice(2, 8).map((c) => (
                      <button
                        key={c.hex}
                        onClick={() => handleApplyCustom({ visorColor: c.hex })}
                        style={{ backgroundColor: c.hex }}
                        className={`w-6 h-6 rounded-full border-2 transition-all cursor-pointer ${
                          customDraft.visorColor === c.hex ? 'border-white scale-110' : 'border-transparent opacity-80'
                        }`}
                        title={c.name}
                      />
                    ))}
                  </div>
                </div>
              </div>

              {/* Board / Skis Graphics */}
              <div>
                <div className="text-xs font-race uppercase tracking-wider text-slate-400 mb-1.5">
                  {selectedDef.vehicleType === 'skis' ? 'Skis Top-Sheet Graphic' : 'Board Deck Graphics'}
                </div>
                <div className="flex gap-2">
                  {PALETTES.map((c) => (
                    <button
                      key={c.hex}
                      onClick={() => handleApplyCustom({ boardColor: c.hex })}
                      style={{ backgroundColor: c.hex }}
                      className={`w-7 h-7 rounded-full border-2 transition-all cursor-pointer ${
                        customDraft.boardColor === c.hex ? 'border-white scale-110 shadow-lg' : 'border-transparent opacity-80'
                      }`}
                      title={c.name}
                    />
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
