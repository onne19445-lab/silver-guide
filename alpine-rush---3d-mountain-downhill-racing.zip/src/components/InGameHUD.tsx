import React, { useState, useEffect } from 'react';
import { RunStats, ActivePowerUp, TrickEvent, WeatherInfo } from '../types/game';
import { 
  Pause, 
  Volume2, 
  VolumeX, 
  Zap, 
  Shield, 
  Flame, 
  Sparkles, 
  Compass, 
  Snowflake,
  ChevronLeft,
  ChevronRight,
  ArrowUp,
  CloudSun
} from 'lucide-react';

interface InGameHUDProps {
  stats: RunStats;
  weather: WeatherInfo | null;
  activePowerUps: ActivePowerUp[];
  recentTrick: TrickEvent | null;
  nearMissFlash: boolean;
  soundEnabled: boolean;
  onPause: () => void;
  onToggleSound: () => void;
  onCycleWeather: () => void;
  onSteerTouch: (val: number) => void;
  onJumpTouch: () => void;
  onBoostTouch: (active: boolean) => void;
}

export const InGameHUD: React.FC<InGameHUDProps> = ({
  stats,
  weather,
  activePowerUps,
  recentTrick,
  nearMissFlash,
  soundEnabled,
  onPause,
  onToggleSound,
  onCycleWeather,
  onSteerTouch,
  onJumpTouch,
  onBoostTouch,
}) => {
  const [showTrick, setShowTrick] = useState(false);
  const [displayedTrick, setDisplayedTrick] = useState<TrickEvent | null>(null);

  useEffect(() => {
    if (recentTrick) {
      setDisplayedTrick(recentTrick);
      setShowTrick(true);
      const timer = setTimeout(() => setShowTrick(false), 1600);
      return () => clearTimeout(timer);
    }
  }, [recentTrick]);

  // Icons for active powerups
  const getPowerUpIcon = (type: string) => {
    switch (type) {
      case 'star': return <Sparkles className="w-4 h-4 text-yellow-300 animate-spin" />;
      case 'nitro': return <Flame className="w-4 h-4 text-rose-400" />;
      case 'shield': return <Shield className="w-4 h-4 text-cyan-400" />;
      case 'multiplier': return <Sparkles className="w-4 h-4 text-amber-400" />;
      case 'magnet': return <Compass className="w-4 h-4 text-pink-400" />;
      case 'freeze': return <Snowflake className="w-4 h-4 text-sky-400" />;
      default: return <Zap className="w-4 h-4 text-yellow-400" />;
    }
  };

  return (
    <div className="absolute inset-0 pointer-events-none select-none flex flex-col justify-between p-4 sm:p-6 overflow-hidden">
      {/* 1. Dynamic Blizzard Frost Vignette (visceral whiteout ice edges) */}
      {weather && weather.frostVignette > 0.05 && (
        <div 
          className="absolute inset-0 pointer-events-none transition-opacity duration-500 z-0"
          style={{
            opacity: weather.frostVignette,
            background: 'radial-gradient(circle at 50% 50%, transparent 48%, rgba(186, 230, 253, 0.35) 80%, rgba(224, 242, 254, 0.75) 100%)',
            boxShadow: 'inset 0 0 100px rgba(186, 230, 253, 0.55)',
          }}
        />
      )}

      {/* Top Perimeter Status Cluster */}
      <div className="relative z-10 flex items-start justify-between">
        {/* Top-Left: Speed & Distance */}
        <div className="bg-slate-900/85 border border-slate-700/70 rounded-2xl px-5 py-3 shadow-xl flex items-center gap-6">
          <div>
            <div className="text-[10px] text-slate-400 font-race uppercase tracking-widest font-bold">Speed</div>
            <div className="flex items-baseline gap-1">
              <span className="font-race text-3xl sm:text-4xl font-extrabold text-white tabular-nums tracking-tight">
                {stats.speed}
              </span>
              <span className="text-xs font-race font-bold text-cyan-400">KM/H</span>
            </div>
          </div>

          <div className="h-8 w-[1px] bg-slate-700" />

          <div>
            <div className="text-[10px] text-slate-400 font-race uppercase tracking-widest font-bold">Slope Run</div>
            <div className="flex items-baseline gap-1">
              <span className="font-race text-2xl sm:text-3xl font-bold text-slate-100 tabular-nums">
                {stats.distance}
              </span>
              <span className="text-xs font-race font-semibold text-slate-400">M</span>
            </div>
          </div>
        </div>

        {/* Top-Center: Weather Status Pill & Trick Banners */}
        <div className="flex flex-col items-center gap-1.5">
          {/* Dynamic Weather & Atmosphere Badge */}
          {weather && (
            <button
              onClick={onCycleWeather}
              title="Click to cycle weather & atmosphere"
              className="bg-slate-900/90 hover:bg-slate-800 border border-slate-700/80 rounded-full px-4 py-1.5 shadow-lg flex items-center gap-2 pointer-events-auto cursor-pointer transition-all hover:scale-105 active:scale-95"
            >
              <span className="text-base">{weather.icon}</span>
              <span className="text-xs font-race font-bold text-slate-200 uppercase tracking-wide">
                {weather.name}
              </span>
              {weather.windSpeed > 1 && (
                <span className="text-[10px] font-race text-cyan-300 font-semibold bg-cyan-950/60 px-2 py-0.5 rounded-full border border-cyan-800/40">
                  💨 {weather.windSpeed.toFixed(1)} m/s
                </span>
              )}
            </button>
          )}

          {/* 2X Double Coins Banner */}
          {stats.isDoubleCoinsActive && (
            <div className="bg-gradient-to-r from-amber-400 to-yellow-500 text-slate-950 font-race font-black px-4 py-1 rounded-full shadow-[0_0_20px_rgba(251,191,36,0.6)] text-xs tracking-wider uppercase flex items-center gap-1.5 border border-white/50 animate-pulse">
              <span>⚡</span>
              <span>2X DOUBLE COINS ACTIVE!</span>
            </div>
          )}

          {/* Shining Star Active Banner */}
          {activePowerUps.some((p) => p.type === 'star') && (
            <div className="bg-gradient-to-r from-yellow-300 via-amber-400 to-yellow-400 text-slate-950 font-race font-black px-5 py-1.5 rounded-full shadow-[0_0_25px_rgba(250,204,21,0.8)] text-xs tracking-wider uppercase flex items-center gap-1.5 border border-white animate-bounce">
              <Sparkles className="w-4 h-4 fill-current text-slate-950" />
              <span>SHINING STAR: ALL COINS ARE RUSHING TO YOU!</span>
            </div>
          )}

          {showTrick && displayedTrick && (
            <div className="bg-gradient-to-r from-amber-500 via-rose-500 to-purple-600 text-white font-race font-black px-6 py-2 rounded-2xl shadow-[0_0_25px_rgba(244,63,94,0.6)] animate-bounce text-sm sm:text-base tracking-wider uppercase flex items-center gap-2 border border-white/30">
              <Sparkles className="w-5 h-5 text-yellow-200 fill-current" />
              <span>{displayedTrick.name}</span>
              <span className="text-yellow-200 tabular-nums">+{displayedTrick.points} PTS</span>
            </div>
          )}

          {nearMissFlash && !showTrick && (
            <div className="bg-cyan-500/90 text-slate-950 font-race font-extrabold px-5 py-1.5 rounded-full shadow-lg text-xs tracking-wider uppercase flex items-center gap-1.5 border border-cyan-300">
              <Zap className="w-4 h-4 fill-current text-slate-950" />
              <span>SLOPE NEAR MISS! +100</span>
            </div>
          )}

          {/* Slalom Gates counter */}
          {stats.gatesPassed > 0 && (
            <div className="text-xs text-sky-300 font-race font-bold tracking-wide bg-slate-900/80 px-3 py-1 rounded-full border border-sky-600/40">
              🏁 {stats.gatesPassed} GATES CLEARED
            </div>
          )}
        </div>

        {/* Top-Right: Score, Multiplier, Coins, Gems, Controls */}
        <div className="flex items-center gap-3">
          <div className="bg-slate-900/85 border border-slate-700/70 rounded-2xl px-5 py-3 shadow-xl flex items-center gap-5 text-right">
            <div>
              <div className="text-[10px] text-slate-400 font-race uppercase tracking-widest font-bold">Score</div>
              <div className="font-race text-2xl sm:text-3xl font-black text-amber-300 tabular-nums">
                {stats.score.toLocaleString()}
              </div>
            </div>

            {stats.multiplier > 1 && (
              <div className="bg-gradient-to-br from-amber-500 to-rose-600 text-white font-race font-black px-2.5 py-1 rounded-lg text-xs tabular-nums shadow-sm">
                x{stats.multiplier.toFixed(1)}
              </div>
            )}

            <div className="flex flex-col gap-1 text-xs">
              <div className="flex items-center gap-1.5 font-race font-bold text-amber-300 tabular-nums">
                <span>🪙</span>
                <span>{stats.coinsCollected}</span>
              </div>
              <div className="flex items-center gap-1.5 font-race font-bold text-cyan-300 tabular-nums">
                <span>💎</span>
                <span>{stats.gemsCollected}</span>
              </div>
            </div>
          </div>

          <button
            onClick={onToggleSound}
            className="p-3 bg-slate-900/85 hover:bg-slate-800 border border-slate-700/70 rounded-2xl text-slate-300 hover:text-white transition-all pointer-events-auto cursor-pointer shadow-lg"
            aria-label="Sound"
          >
            {soundEnabled ? <Volume2 className="w-5 h-5 text-cyan-400" /> : <VolumeX className="w-5 h-5 text-slate-500" />}
          </button>

          <button
            onClick={onPause}
            className="p-3 bg-slate-900/85 hover:bg-slate-800 border border-slate-700/70 rounded-2xl text-slate-300 hover:text-white transition-all pointer-events-auto cursor-pointer shadow-lg"
            aria-label="Pause Game"
          >
            <Pause className="w-5 h-5 text-slate-200" />
          </button>
        </div>
      </div>

      {/* Bottom Perimeter: Active Powerups & Mobile Virtual Controls */}
      <div className="flex flex-col items-center gap-3">
        {/* Active Power-Ups Badges */}
        {activePowerUps.length > 0 && (
          <div className="flex items-center gap-2">
            {activePowerUps.map((pu) => {
              const pct = (pu.duration / pu.maxDuration) * 100;
              return (
                <div
                  key={pu.type}
                  className="bg-slate-900/90 border border-slate-700 rounded-xl px-3 py-1.5 flex items-center gap-2 shadow-lg"
                >
                  {getPowerUpIcon(pu.type)}
                  <span className="font-race text-xs font-bold text-white uppercase">{pu.type}</span>
                  <div className="w-10 bg-slate-800 h-1.5 rounded-full overflow-hidden">
                    <div className="bg-cyan-400 h-full rounded-full" style={{ width: `${pct}%` }} />
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* Touch Screen Virtual Controls (Only visible/useful on touch screens) */}
        <div className="w-full flex items-center justify-between px-2 sm:px-8 pb-2 pointer-events-auto">
          {/* Steer Left / Right buttons */}
          <div className="flex items-center gap-3">
            <button
              onPointerDown={() => onSteerTouch(-1)}
              onPointerUp={() => onSteerTouch(0)}
              onPointerLeave={() => onSteerTouch(0)}
              className="w-16 h-16 sm:w-20 sm:h-20 bg-slate-900/80 active:bg-cyan-600/60 border border-slate-700 rounded-2xl flex items-center justify-center text-white active:scale-90 transition-all shadow-xl cursor-pointer"
              aria-label="Carve Left"
            >
              <ChevronLeft className="w-8 h-8" />
            </button>
            <button
              onPointerDown={() => onSteerTouch(1)}
              onPointerUp={() => onSteerTouch(0)}
              onPointerLeave={() => onSteerTouch(0)}
              className="w-16 h-16 sm:w-20 sm:h-20 bg-slate-900/80 active:bg-cyan-600/60 border border-slate-700 rounded-2xl flex items-center justify-center text-white active:scale-90 transition-all shadow-xl cursor-pointer"
              aria-label="Carve Right"
            >
              <ChevronRight className="w-8 h-8" />
            </button>
          </div>

          {/* Jump & Boost buttons */}
          <div className="flex items-center gap-3">
            <button
              onPointerDown={() => onBoostTouch(true)}
              onPointerUp={() => onBoostTouch(false)}
              onPointerLeave={() => onBoostTouch(false)}
              className="w-16 h-16 sm:w-20 sm:h-20 bg-amber-500/80 active:bg-amber-400 border border-amber-400/60 rounded-2xl flex flex-col items-center justify-center text-slate-950 font-race font-black text-xs active:scale-90 transition-all shadow-xl cursor-pointer"
              aria-label="Nitro Boost"
            >
              <Flame className="w-6 h-6 fill-current" />
              <span>BOOST</span>
            </button>

            <button
              onPointerDown={onJumpTouch}
              className="w-16 h-16 sm:w-20 sm:h-20 bg-cyan-500/80 active:bg-cyan-400 border border-cyan-400/60 rounded-2xl flex flex-col items-center justify-center text-slate-950 font-race font-black text-xs active:scale-90 transition-all shadow-xl cursor-pointer"
              aria-label="Jump & Trick"
            >
              <ArrowUp className="w-6 h-6 stroke-[3]" />
              <span>JUMP</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
