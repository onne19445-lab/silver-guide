import React, { useEffect } from 'react';
import { RunStats } from '../types/game';
import { RotateCcw, Palette, Home, Award, Zap, Compass, Flag } from 'lucide-react';

interface GameOverModalProps {
  stats: RunStats;
  isNewHighScore: boolean;
  onRestart: () => void;
  onOpenCustomizer: () => void;
  onMainMenu: () => void;
}

export const GameOverModal: React.FC<GameOverModalProps> = ({
  stats,
  isNewHighScore,
  onRestart,
  onOpenCustomizer,
  onMainMenu,
}) => {
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.code === 'Space' || e.code === 'Enter') {
        e.preventDefault();
        onRestart();
      } else if (e.code === 'KeyC') {
        onOpenCustomizer();
      } else if (e.code === 'Escape') {
        onMainMenu();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onRestart, onOpenCustomizer, onMainMenu]);

  return (
    <div className="absolute inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/75 backdrop-blur-sm select-none">
      <div className="w-full max-w-lg bg-slate-900 border border-slate-700/80 rounded-3xl p-6 sm:p-8 shadow-2xl flex flex-col items-center text-center animate-in fade-in zoom-in-95 duration-200">
        {/* Banner */}
        {isNewHighScore ? (
          <div className="bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-500 text-slate-950 font-race font-black px-6 py-2 rounded-full text-sm tracking-wider uppercase flex items-center gap-2 mb-4 shadow-lg shadow-amber-500/30">
            <Award className="w-5 h-5 fill-current" />
            <span>NEW MOUNTAIN RECORD!</span>
          </div>
        ) : (
          <div className="text-xs font-race font-bold text-rose-400 uppercase tracking-widest bg-rose-950/60 border border-rose-800/60 px-4 py-1.5 rounded-full mb-3">
            WIPEOUT ON THE SLOPE
          </div>
        )}

        <h2 className="text-3xl sm:text-4xl font-race font-black text-white tracking-wide mb-1">
          RUN COMPLETED
        </h2>
        <p className="text-xs text-slate-400 mb-6">You challenged the alpine peak!</p>

        {/* Big Score Box */}
        <div className="w-full bg-slate-950/80 border border-slate-800 rounded-2xl p-4 mb-5">
          <div className="text-xs font-race text-slate-400 uppercase tracking-wider font-semibold">Final Score</div>
          <div className="font-race text-4xl sm:text-5xl font-black text-amber-300 tabular-nums">
            {stats.score.toLocaleString()}
          </div>
        </div>

        {/* Stats Grid */}
        <div className="w-full grid grid-cols-2 gap-3 mb-6 text-left">
          <div className="bg-slate-950/60 border border-slate-800/80 rounded-xl p-3">
            <div className="text-[10px] text-slate-400 font-race uppercase font-semibold">Distance Down Peak</div>
            <div className="font-race text-xl font-bold text-white tabular-nums">
              {stats.distance} <span className="text-xs text-slate-400 font-normal">meters</span>
            </div>
          </div>

          <div className="bg-slate-950/60 border border-slate-800/80 rounded-xl p-3">
            <div className="text-[10px] text-slate-400 font-race uppercase font-semibold">Peak Speed</div>
            <div className="font-race text-xl font-bold text-cyan-400 tabular-nums">
              {stats.topSpeed} <span className="text-xs text-slate-400 font-normal">km/h</span>
            </div>
          </div>

          <div className="bg-slate-950/60 border border-slate-800/80 rounded-xl p-3 flex items-center justify-between">
            <div>
              <div className="text-[10px] text-slate-400 font-race uppercase font-semibold">Snow Coins</div>
              <div className="font-race text-lg font-bold text-amber-400 tabular-nums">
                +{stats.coinsCollected}
              </div>
            </div>
            <span className="text-2xl">🪙</span>
          </div>

          <div className="bg-slate-950/60 border border-slate-800/80 rounded-xl p-3 flex items-center justify-between">
            <div>
              <div className="text-[10px] text-slate-400 font-race uppercase font-semibold">Mountain Gems</div>
              <div className="font-race text-lg font-bold text-cyan-400 tabular-nums">
                +{stats.gemsCollected}
              </div>
            </div>
            <span className="text-2xl">💎</span>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="w-full flex flex-col gap-3">
          <button
            onClick={onRestart}
            className="w-full py-4 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-race font-black text-lg tracking-wider rounded-2xl shadow-lg shadow-cyan-500/30 hover:scale-[1.02] active:scale-95 transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <RotateCcw className="w-5 h-5 stroke-[2.5]" />
            <span>DROP IN AGAIN (SPACE)</span>
          </button>

          <div className="grid grid-cols-2 gap-3">
            <button
              onClick={onOpenCustomizer}
              className="py-3 bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white font-race font-bold text-sm rounded-xl border border-slate-700 transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              <Palette className="w-4 h-4 text-cyan-400" />
              <span>CUSTOMIZER (C)</span>
            </button>

            <button
              onClick={onMainMenu}
              className="py-3 bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white font-race font-bold text-sm rounded-xl border border-slate-700 transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              <Home className="w-4 h-4 text-slate-400" />
              <span>TITLE SCREEN</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
