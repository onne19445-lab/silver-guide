/**
 * Alpine Rush - Type Definitions
 */

export type CharacterId = 
  | 'alpine_blitz' 
  | 'frost_maverick' 
  | 'glacier_guardian' 
  | 'vortex_valkyrie' 
  | 'yeti_rider';

export type VehicleType = 'skis' | 'snowboard' | 'yeti_stride';

export type JacketPattern = 'solid' | 'stripes' | 'camo' | 'cyber' | 'chevron';

export interface CharacterCustomization {
  jacketColor: string;
  jacketPattern: JacketPattern;
  pantsColor: string;
  helmetColor: string;
  visorColor: string;
  boardColor: string;
  accentColor: string;
}

export interface CharacterDef {
  id: CharacterId;
  name: string;
  title: string;
  vehicleType: VehicleType;
  description: string;
  specialAbility: string;
  stats: {
    speed: number;       // 1 - 10
    carving: number;     // 1 - 10 (handling)
    airtime: number;     // 1 - 10 (jump height/trick window)
    boost: number;       // 1 - 10 (nitro duration/recharge)
    resilience: number;  // 1 - 10 (shield/bump recovery)
  };
  unlockCost: number;     // 0 for free
  unlockRequirement?: string;
  defaultCustomization: CharacterCustomization;
}

export type GameStatus = 'title' | 'customize' | 'playing' | 'paused' | 'gameover';

export type PowerUpType = 'nitro' | 'shield' | 'magnet' | 'multiplier' | 'freeze' | 'star';

export interface ActivePowerUp {
  type: PowerUpType;
  duration: number;
  maxDuration: number;
}

export interface TrickEvent {
  name: string;
  points: number;
  rotationName?: string;
  timestamp: number;
}

export type WeatherType = 'clear_day' | 'sunset_glow' | 'heavy_blizzard' | 'aurora_night';

export interface WeatherInfo {
  type: WeatherType;
  name: string;
  icon: string;
  frostVignette: number;
  windSpeed: number;
}

export interface RunStats {
  distance: number;       // meters
  speed: number;          // current km/h
  topSpeed: number;       // km/h
  score: number;
  multiplier: number;
  coinsCollected: number;
  gemsCollected: number;
  gatesPassed: number;
  tricksLanded: number;
  airtimeTotal: number;
  nearMisses: number;
  isDoubleCoinsActive?: boolean;
}

export type MapTheme = 'snow' | 'beach';

export interface PlayerProgress {
  coins: number;
  gems: number;
  highScore: number;
  maxDistance: number;
  unlockedCharacters: CharacterId[];
  selectedCharacter: CharacterId;
  selectedMap: MapTheme;
  customizations: Record<CharacterId, CharacterCustomization>;
  soundEnabled: boolean;
  musicEnabled: boolean;
}
