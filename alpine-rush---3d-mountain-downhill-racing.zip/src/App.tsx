import React, { useEffect, useRef, useState, useCallback } from 'react';
import { 
  GameStatus, 
  PlayerProgress, 
  CharacterId, 
  CharacterCustomization, 
  RunStats, 
  ActivePowerUp, 
  TrickEvent,
  WeatherInfo,
  MapTheme
} from './types/game';
import { CHARACTERS, getInitialProgress, saveProgress } from './game/charactersConfig';
import { GameEngine } from './game/gameEngine';
import { sound } from './game/audio';
import { TitleScreen } from './components/TitleScreen';
import { CustomizerModal } from './components/CustomizerModal';
import { InGameHUD } from './components/InGameHUD';
import { GameOverModal } from './components/GameOverModal';
import { PauseModal } from './components/PauseModal';
import { DailyChallengesModal } from './components/DailyChallengesModal';
import { loadDailyChallenges } from './game/dailyChallenges';

export default function App() {
  const canvasMountRef = useRef<HTMLDivElement>(null);
  const engineRef = useRef<GameEngine | null>(null);

  // Persistent Player Progress State
  const [progress, setProgress] = useState<PlayerProgress>(getInitialProgress);

  // Daily challenges UI state
  const [showDailyChallenges, setShowDailyChallenges] = useState(false);
  const [unclaimedChallengesCount, setUnclaimedChallengesCount] = useState(0);
  const [invertSteering, setInvertSteering] = useState(false);

  const handleToggleInvertSteering = useCallback(() => {
    setInvertSteering((prev) => {
      const next = !prev;
      if (engineRef.current) {
        engineRef.current.setInvertSteering(next);
      }
      return next;
    });
  }, []);

  // Active Game State
  const [gameStatus, setGameStatus] = useState<GameStatus>('title');
  const [stats, setStats] = useState<RunStats>({
    distance: 0,
    speed: 0,
    topSpeed: 0,
    score: 0,
    multiplier: 1,
    coinsCollected: 0,
    gemsCollected: 0,
    gatesPassed: 0,
    tricksLanded: 0,
    airtimeTotal: 0,
    nearMisses: 0,
    isDoubleCoinsActive: false,
  });

  const [weather, setWeather] = useState<WeatherInfo | null>(null);
  const [activePowerUps, setActivePowerUps] = useState<ActivePowerUp[]>([]);
  const [recentTrick, setRecentTrick] = useState<TrickEvent | null>(null);
  const [nearMissFlash, setNearMissFlash] = useState(false);
  const [isNewHighScore, setIsNewHighScore] = useState(false);

  // Active character reference
  const activeCharDef = CHARACTERS.find((c) => c.id === progress.selectedCharacter) || CHARACTERS[0];
  const activeCustomization = progress.customizations[activeCharDef.id] || activeCharDef.defaultCustomization;

  const refreshUnclaimedCount = useCallback(() => {
    try {
      const challenges = loadDailyChallenges();
      const ready = challenges.filter(c => c.completed && !c.claimed).length;
      setUnclaimedChallengesCount(ready);
    } catch {
      // fallback
    }
  }, []);

  useEffect(() => {
    refreshUnclaimedCount();
  }, [refreshUnclaimedCount]);

  // Refs for callbacks so stable WebGL loop doesn't re-mount
  const callbacksRef = useRef({
    onStatsUpdate: (newStats: RunStats) => {
      setStats({ ...newStats });
    },
    onWeatherUpdate: (w: WeatherInfo) => {
      setWeather(w);
    },
    onPowerUpsUpdate: (powerUps: ActivePowerUp[]) => {
      setActivePowerUps([...powerUps]);
    },
    onTrick: (trick: TrickEvent) => {
      setRecentTrick(trick);
    },
    onNearMiss: () => {
      setNearMissFlash(true);
      setTimeout(() => setNearMissFlash(false), 900);
    },
    onGatePassed: () => {
      // Triggered on slalom gate
    },
    onShieldLost: () => {
      // Triggered when shield absorbs hit
    },
    onGameOver: (finalStats: RunStats) => {
      setGameStatus('gameover');

      // Update persistent progress
      setProgress((prev) => {
        const isHigh = finalStats.score > prev.highScore;
        setIsNewHighScore(isHigh);

        const updated: PlayerProgress = {
          ...prev,
          coins: prev.coins + finalStats.coinsCollected,
          gems: prev.gems + finalStats.gemsCollected,
          highScore: Math.max(prev.highScore, finalStats.score),
          maxDistance: Math.max(prev.maxDistance, finalStats.distance),
        };
        saveProgress(updated);
        return updated;
      });

      refreshUnclaimedCount();
    },
  });

  // Initialize Three.js Game Engine once on mount
  useEffect(() => {
    if (!canvasMountRef.current) return;

    sound.setMuted(!progress.soundEnabled);

    const engine = new GameEngine(
      canvasMountRef.current,
      activeCharDef,
      activeCustomization,
      {
        onStatsUpdate: (s) => callbacksRef.current.onStatsUpdate(s),
        onWeatherUpdate: (w) => callbacksRef.current.onWeatherUpdate(w),
        onPowerUpsUpdate: (p) => callbacksRef.current.onPowerUpsUpdate(p),
        onTrick: (t) => callbacksRef.current.onTrick(t),
        onNearMiss: () => callbacksRef.current.onNearMiss(),
        onGatePassed: () => callbacksRef.current.onGatePassed(),
        onShieldLost: () => callbacksRef.current.onShieldLost(),
        onGameOver: (f) => callbacksRef.current.onGameOver(f),
      },
      progress.selectedMap || 'snow'
    );

    engineRef.current = engine;

    return () => {
      engine.dispose();
      engineRef.current = null;
    };
  }, []); // Run once!

  // Map theme selection (Snowy Alpine vs Sandy Beach)
  const handleSelectMap = useCallback((theme: MapTheme) => {
    setProgress((prev) => {
      const updated: PlayerProgress = { ...prev, selectedMap: theme };
      saveProgress(updated);
      return updated;
    });

    if (engineRef.current) {
      engineRef.current.setMapTheme(theme);
    }
  }, []);

  // Handle Game State Transitions
  const handleStartGame = useCallback(() => {
    if (engineRef.current) {
      engineRef.current.startGame();
      setGameStatus('playing');
    }
  }, []);

  const handlePauseGame = useCallback(() => {
    if (engineRef.current) {
      engineRef.current.pauseGame();
      setGameStatus('paused');
    }
  }, []);

  const handleResumeGame = useCallback(() => {
    if (engineRef.current) {
      engineRef.current.resumeGame();
      setGameStatus('playing');
    }
  }, []);

  const handleRestartGame = useCallback(() => {
    if (engineRef.current) {
      engineRef.current.startGame();
      setGameStatus('playing');
    }
  }, []);

  const handleOpenCustomizer = useCallback(() => {
    if (engineRef.current) {
      engineRef.current.setStatus('customize');
    }
    setGameStatus('customize');
  }, []);

  const handleCloseCustomizer = useCallback(() => {
    if (engineRef.current) {
      engineRef.current.setStatus('title');
    }
    setGameStatus('title');
  }, []);

  const handleSelectCharacter = useCallback((id: CharacterId) => {
    const char = CHARACTERS.find((c) => c.id === id);
    if (!char) return;

    const custom = progress.customizations[id] || char.defaultCustomization;

    setProgress((prev) => {
      const updated = { ...prev, selectedCharacter: id };
      saveProgress(updated);
      return updated;
    });

    if (engineRef.current) {
      engineRef.current.loadCharacter(char, custom, progress.selectedMap);
    }
  }, [progress.customizations, progress.selectedMap]);

  const handleUpdateCustomization = useCallback((charId: CharacterId, newCustom: CharacterCustomization) => {
    setProgress((prev) => {
      const updated = {
        ...prev,
        customizations: {
          ...prev.customizations,
          [charId]: newCustom,
        },
      };
      saveProgress(updated);
      return updated;
    });

    if (engineRef.current) {
      engineRef.current.updateCustomization(newCustom);
    }
  }, []);

  const handleUnlockCharacter = useCallback((charId: CharacterId, cost: number) => {
    setProgress((prev) => {
      if (prev.coins < cost) return prev;
      const updated: PlayerProgress = {
        ...prev,
        coins: prev.coins - cost,
        unlockedCharacters: [...prev.unlockedCharacters, charId],
        selectedCharacter: charId,
      };
      saveProgress(updated);
      return updated;
    });

    const char = CHARACTERS.find((c) => c.id === charId);
    if (char && engineRef.current) {
      engineRef.current.loadCharacter(char, char.defaultCustomization, progress.selectedMap);
    }
  }, [progress.selectedMap]);

  const handleClaimChallengeReward = useCallback((rewardCoins: number) => {
    setProgress((prev) => {
      const updated: PlayerProgress = {
        ...prev,
        coins: prev.coins + rewardCoins,
      };
      saveProgress(updated);
      return updated;
    });
    refreshUnclaimedCount();
  }, [refreshUnclaimedCount]);

  const handleToggleSound = useCallback(() => {
    const isMuted = sound.toggleMute();
    setProgress((prev) => {
      const updated = { ...prev, soundEnabled: !isMuted };
      saveProgress(updated);
      return updated;
    });
  }, []);

  // Keyboard shortcut for pausing during active play
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.code === 'Escape') {
        if (showDailyChallenges) {
          setShowDailyChallenges(false);
        } else if (gameStatus === 'playing') {
          handlePauseGame();
        } else if (gameStatus === 'paused') {
          handleResumeGame();
        }
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [gameStatus, showDailyChallenges, handlePauseGame, handleResumeGame]);

  const handleCycleWeather = useCallback(() => {
    if (engineRef.current) engineRef.current.cycleWeather();
  }, []);

  // Touch handlers for mobile
  const handleSteerTouch = (val: number) => {
    if (engineRef.current) engineRef.current.setVirtualSteer(val);
  };
  const handleJumpTouch = () => {
    if (engineRef.current) engineRef.current.triggerVirtualJump();
  };
  const handleBoostTouch = (active: boolean) => {
    if (engineRef.current) engineRef.current.setVirtualBoost(active);
  };

  return (
    <div className="relative w-screen h-screen overflow-hidden bg-slate-950 font-sans">
      {/* 1. Isolated WebGL Canvas Mount Container */}
      <div 
        ref={canvasMountRef} 
        className="absolute inset-0 w-full h-full z-0 cursor-grab active:cursor-grabbing" 
      />

      {/* 2. UI Overlays (Full Viewport Game Shell) */}
      {gameStatus === 'title' && (
        <TitleScreen
          progress={progress}
          activeCharacter={activeCharDef}
          onStart={handleStartGame}
          onOpenCustomizer={handleOpenCustomizer}
          onToggleSound={handleToggleSound}
          onSelectMap={handleSelectMap}
          onOpenDailyChallenges={() => setShowDailyChallenges(true)}
          unclaimedChallengesCount={unclaimedChallengesCount}
        />
      )}

      {gameStatus === 'customize' && (
        <CustomizerModal
          progress={progress}
          onClose={handleCloseCustomizer}
          onSelectCharacter={handleSelectCharacter}
          onUpdateCustomization={handleUpdateCustomization}
          onUnlockCharacter={handleUnlockCharacter}
        />
      )}

      {gameStatus === 'playing' && (
        <InGameHUD
          stats={stats}
          weather={weather}
          activePowerUps={activePowerUps}
          recentTrick={recentTrick}
          nearMissFlash={nearMissFlash}
          soundEnabled={progress.soundEnabled}
          onPause={handlePauseGame}
          onToggleSound={handleToggleSound}
          onCycleWeather={handleCycleWeather}
          onSteerTouch={handleSteerTouch}
          onJumpTouch={handleJumpTouch}
          onBoostTouch={handleBoostTouch}
        />
      )}

      {gameStatus === 'paused' && (
        <PauseModal
          soundEnabled={progress.soundEnabled}
          invertSteering={invertSteering}
          onResume={handleResumeGame}
          onRestart={handleRestartGame}
          onOpenCustomizer={handleOpenCustomizer}
          onMainMenu={handleCloseCustomizer}
          onToggleSound={handleToggleSound}
          onToggleInvertSteering={handleToggleInvertSteering}
        />
      )}

      {gameStatus === 'gameover' && (
        <GameOverModal
          stats={stats}
          isNewHighScore={isNewHighScore}
          onRestart={handleRestartGame}
          onOpenCustomizer={handleOpenCustomizer}
          onMainMenu={handleCloseCustomizer}
        />
      )}

      {/* 3. Daily Challenges Modal */}
      {showDailyChallenges && (
        <DailyChallengesModal
          onClose={() => {
            setShowDailyChallenges(false);
            refreshUnclaimedCount();
          }}
          onRewardClaimed={handleClaimChallengeReward}
        />
      )}
    </div>
  );
}
